import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import bcrypt from 'bcryptjs';
import JSZip from 'jszip';
import { createServer as createViteServer } from 'vite';
import { db, initDatabase, generateId } from './server/db.ts';
import {
  signToken,
  setAuthCookie,
  clearAuthCookie,
  requireAuth,
  requireSuperAdmin,
  requireLabOwner,
  logAudit,
  type AuthRequest,
} from './server/auth.ts';
import {
  getSetting,
  getEffectiveSmtpConfig,
  getEffectiveWhatsAppConfig,
  renderTemplate,
  sendRealEmail,
  sendRealWhatsApp,
  verifySmtpConnection,
  type NotificationTemplates,
} from './server/notifications.ts';

initDatabase();

const app = express();
app.use(express.json({ limit: '5mb' }));

function getBaseUrl(req: express.Request): string {
  if (process.env.APP_URL && !process.env.APP_URL.includes('MY_APP_URL')) {
    return process.env.APP_URL.replace(/\/$/, '');
  }
  const proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'http';
  const host = req.headers['x-forwarded-host'] || req.get('host') || 'localhost:3000';
  return `${proto}://${host}`;
}

function maskSecret(val: string | undefined): string {
  if (!val) return '';
  if (val.length <= 4) return '••••';
  return '••••••••' + val.slice(-4);
}

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
}

function generateBookingCode(slug: string): string {
  const prefix = slug.replace(/[^a-zA-Z0-9]/g, '').slice(0, 4).toUpperCase() || 'LAB';
  const num = crypto.randomInt(10000, 99999);
  return `MG-${prefix}-${num}`;
}

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, timestamp: new Date().toISOString() });
});

// ==================== AUTH ROUTES ====================

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body as { email?: string; password?: string };
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = db
    .prepare('SELECT id, email, password_hash, name, role, lab_id, permissions, is_active FROM users WHERE LOWER(email) = LOWER(?)')
    .get(email.trim()) as
    | {
        id: string;
        email: string;
        password_hash: string;
        name: string;
        role: 'super_admin' | 'lab_owner';
        lab_id: string | null;
        permissions: string;
        is_active: number;
      }
    | undefined;

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  if (!user.is_active) {
    return res.status(403).json({ error: 'Your user account has been disabled.' });
  }

  let lab = null;
  if (user.lab_id) {
    lab = db.prepare('SELECT id, slug, name, website_name, status FROM labs WHERE id = ?').get(user.lab_id) as
      | { id: string; slug: string; name: string; website_name: string; status: string }
      | undefined;
    if (lab?.status === 'deactivated') {
      return res.status(403).json({ error: 'This laboratory account has been deactivated. Contact platform support.' });
    }
  }

  const permissions = JSON.parse(user.permissions || '[]') as string[];
  const token = signToken({
    uid: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    labId: user.lab_id,
    permissions,
  });

  setAuthCookie(res, token);
  logAudit({
    actorId: user.id,
    actorEmail: user.email,
    actorRole: user.role,
    labId: user.lab_id,
    action: 'user_login',
    details: `Logged in as ${user.role}`,
    ipAddress: req.ip,
  });

  res.json({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      labId: user.lab_id,
      permissions,
    },
    lab,
  });
});

app.post('/api/auth/logout', (req: AuthRequest, res) => {
  clearAuthCookie(res);
  res.json({ ok: true });
});

app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
  let lab = null;
  if (req.auth?.labId) {
    lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(req.auth.labId);
  }
  res.json({ user: req.auth, lab });
});

app.get('/api/auth/invite/:token', (req, res) => {
  const { token } = req.params;
  const user = db
    .prepare('SELECT id, email, name, lab_id, invite_expires_at FROM users WHERE invite_token = ?')
    .get(token) as
    | { id: string; email: string; name: string; lab_id: string | null; invite_expires_at: string | null }
    | undefined;

  if (!user) {
    return res.status(404).json({ error: 'Invitation link is invalid or has already been used.' });
  }
  if (user.invite_expires_at && new Date(user.invite_expires_at) < new Date()) {
    return res.status(410).json({ error: 'Invitation link has expired. Ask Super Admin to resend invitation.' });
  }
  const lab = user.lab_id
    ? db.prepare('SELECT id, slug, name, website_name, city FROM labs WHERE id = ?').get(user.lab_id)
    : null;

  res.json({
    email: user.email,
    name: user.name,
    lab,
  });
});

app.post('/api/auth/accept-invite', (req, res) => {
  const { token, password } = req.body as { token?: string; password?: string };
  if (!token || !password || password.length < 8) {
    return res.status(400).json({ error: 'Valid token and a password of at least 8 characters are required.' });
  }

  const user = db
    .prepare('SELECT id, email, name, role, lab_id, permissions, invite_expires_at FROM users WHERE invite_token = ?')
    .get(token) as
    | {
        id: string;
        email: string;
        name: string;
        role: 'super_admin' | 'lab_owner';
        lab_id: string | null;
        permissions: string;
        invite_expires_at: string | null;
      }
    | undefined;

  if (!user) {
    return res.status(404).json({ error: 'Invalid or already claimed invitation token.' });
  }
  if (user.invite_expires_at && new Date(user.invite_expires_at) < new Date()) {
    return res.status(410).json({ error: 'Invitation link has expired.' });
  }

  const hash = bcrypt.hashSync(password, 10);
  db.prepare(`
    UPDATE users
    SET password_hash = ?, invite_token = NULL, invite_expires_at = NULL, must_change_password = 0, is_active = 1
    WHERE id = ?
  `).run(hash, user.id);

  const permissions = JSON.parse(user.permissions || '[]') as string[];
  const jwt = signToken({
    uid: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    labId: user.lab_id,
    permissions,
  });
  setAuthCookie(res, jwt);

  logAudit({
    actorId: user.id,
    actorEmail: user.email,
    actorRole: user.role,
    labId: user.lab_id,
    action: 'invite_accepted',
    details: 'Lab owner activated credentials via secure invite link',
    ipAddress: req.ip,
  });

  res.json({
    ok: true,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      labId: user.lab_id,
      permissions,
    },
  });
});

// ==================== SUPER ADMIN ROUTES ====================

app.get('/api/super-admin/overview', requireSuperAdmin, (_req, res) => {
  const labs = db.prepare('SELECT * FROM labs ORDER BY created_at DESC').all() as Array<Record<string, unknown>>;
  const bookings = db.prepare('SELECT id, lab_id, price, status, is_demo, created_at, booking_date FROM bookings').all() as Array<{
    id: string;
    lab_id: string;
    price: number;
    status: string;
    is_demo: number;
    created_at: string;
    booking_date: string;
  }>;
  const payments = db.prepare('SELECT * FROM lab_payments ORDER BY created_at DESC').all() as Array<{
    id: string;
    amount: number;
    status: string;
    created_at: string;
  }>;
  const recentNotifications = db
    .prepare('SELECT * FROM notification_logs ORDER BY created_at DESC LIMIT 12')
    .all();

  const totalLabsSold = labs.length;
  const activeLabs = labs.filter((l) => l.status === 'active').length;
  const suspendedLabs = labs.filter((l) => l.status === 'suspended').length;
  const totalRevenue = labs.reduce((acc, l) => acc + Number(l.amount_paid || 0), 0);
  const pendingPayments = labs.reduce((acc, l) => acc + Number(l.pending_amount || 0), 0);
  const totalContractValue = labs.reduce((acc, l) => acc + Number(l.selling_price || 0), 0);

  // Monthly revenue grouping
  const monthlyMap = new Map<string, number>();
  for (const p of payments) {
    const monthKey = String(p.created_at).slice(0, 7);
    monthlyMap.set(monthKey, (monthlyMap.get(monthKey) || 0) + Number(p.amount || 0));
  }
  const monthlyRevenue = Array.from(monthlyMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, revenue]) => ({ month, revenue }));

  res.json({
    metrics: {
      totalLabsSold,
      activeLabs,
      suspendedLabs,
      totalRevenue,
      pendingPayments,
      totalContractValue,
      totalBookings: bookings.length,
      liveBookings: bookings.filter((b) => b.is_demo === 0).length,
      demoBookings: bookings.filter((b) => b.is_demo === 1).length,
    },
    monthlyRevenue,
    recentNotifications,
  });
});

app.get('/api/super-admin/labs', requireSuperAdmin, (_req, res) => {
  const labs = db.prepare('SELECT * FROM labs ORDER BY created_at DESC').all() as Array<Record<string, unknown>>;
  const enriched = labs.map((lab) => {
    const owner = db
      .prepare('SELECT id, email, name, permissions, invite_token, is_active FROM users WHERE lab_id = ? AND role = ?')
      .get(lab.id as string, 'lab_owner') as
      | { id: string; email: string; name: string; permissions: string; invite_token: string | null; is_active: number }
      | undefined;
    const testCount = (
      db.prepare('SELECT COUNT(*) as c FROM diagnostic_tests WHERE lab_id = ?').get(lab.id as string) as { c: number }
    ).c;
    const bookingCount = (
      db.prepare('SELECT COUNT(*) as c FROM bookings WHERE lab_id = ?').get(lab.id as string) as { c: number }
    ).c;
    return {
      ...lab,
      owner_user_id: owner?.id || null,
      permissions: owner ? JSON.parse(owner.permissions || '[]') : [],
      invite_pending: Boolean(owner?.invite_token),
      invite_token: owner?.invite_token || null,
      test_count: testCount,
      booking_count: bookingCount,
    };
  });
  res.json({ labs: enriched });
});

app.post('/api/super-admin/labs', requireSuperAdmin, async (req: AuthRequest, res) => {
  const body = req.body as {
    name?: string;
    website_name?: string;
    slug?: string;
    custom_domain?: string;
    logo_url?: string;
    address?: string;
    city?: string;
    contact_number?: string;
    whatsapp_number?: string;
    owner_name?: string;
    owner_email?: string;
    theme_color?: string;
    tagline?: string;
    subscription_plan?: string;
    selling_price?: number;
    amount_paid?: number;
    subscription_start?: string;
    subscription_expiry?: string;
    auto_suspend_on_expiry?: boolean;
    permissions?: string[];
  };

  if (!body.name || !body.owner_name || !body.owner_email || !body.whatsapp_number || !body.address || !body.contact_number) {
    return res.status(400).json({ error: 'Lab name, address, contact number, owner name, email, and WhatsApp number are required.' });
  }

  const finalSlug = slugify(body.slug || body.website_name || body.name);
  if (!finalSlug) {
    return res.status(400).json({ error: 'A valid unique URL slug is required.' });
  }

  const existingSlug = db.prepare('SELECT id FROM labs WHERE slug = ?').get(finalSlug);
  if (existingSlug) {
    return res.status(409).json({ error: `The URL slug "/lab/${finalSlug}" is already assigned to another laboratory.` });
  }

  const existingEmail = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?)').get(body.owner_email.trim());
  if (existingEmail) {
    return res.status(409).json({ error: `The owner email "${body.owner_email}" already has an account.` });
  }

  const labId = generateId('lab');
  const userId = generateId('usr');
  const now = new Date().toISOString();
  const today = now.slice(0, 10);
  const nextYear = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);

  const sellingPrice = Number(body.selling_price || 0);
  const amountPaid = Math.min(sellingPrice, Math.max(0, Number(body.amount_paid || 0)));
  const pendingAmount = Math.max(0, sellingPrice - amountPaid);

  const tempPassword = `Lab${crypto.randomBytes(4).toString('hex')}!`;
  const inviteToken = crypto.randomBytes(20).toString('hex');
  const inviteExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  const permissions = body.permissions && body.permissions.length > 0
    ? body.permissions
    : ['manage_tests', 'manage_bookings', 'manage_profile', 'export_reports', 'manage_packages'];

  db.prepare(`
    INSERT INTO labs (
      id, slug, name, website_name, custom_domain, logo_url, banner_url,
      address, city, contact_number, whatsapp_number, owner_name, owner_email,
      theme_color, tagline, status, subscription_plan, selling_price,
      amount_paid, pending_amount, subscription_start, subscription_expiry,
      auto_suspend_on_expiry, is_demo, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?, ?, 0, ?)
  `).run(
    labId,
    finalSlug,
    body.name.trim(),
    (body.website_name || body.name).trim(),
    (body.custom_domain || '').trim(),
    body.logo_url || '',
    '/src/assets/images/hero_diagnostic_lab_1794644019030.jpg',
    body.address.trim(),
    (body.city || 'India').trim(),
    body.contact_number.trim(),
    body.whatsapp_number.trim(),
    body.owner_name.trim(),
    body.owner_email.trim().toLowerCase(),
    body.theme_color || '#1D4ED8',
    body.tagline || 'Accurate clinical diagnostics, digital reporting & doorstep home sample collection.',
    body.subscription_plan || 'Growth Annual',
    sellingPrice,
    amountPaid,
    pendingAmount,
    body.subscription_start || today,
    body.subscription_expiry || nextYear,
    body.auto_suspend_on_expiry === false ? 0 : 1,
    now
  );

  db.prepare(`
    INSERT INTO users (
      id, email, password_hash, name, role, lab_id, permissions,
      invite_token, invite_expires_at, must_change_password, is_active, created_at
    ) VALUES (?, ?, ?, ?, 'lab_owner', ?, ?, ?, ?, 1, 1, ?)
  `).run(
    userId,
    body.owner_email.trim().toLowerCase(),
    bcrypt.hashSync(tempPassword, 10),
    body.owner_name.trim(),
    labId,
    JSON.stringify(permissions),
    inviteToken,
    inviteExpiresAt,
    now
  );

  // Create default categories for the new lab
  const defaultCats = [
    { name: 'Blood & Hematology', name_hi: 'रक्त जांच' },
    { name: 'Diabetes & Thyroid', name_hi: 'मधुमेह एवं थायरॉइड' },
    { name: 'Health Packages', name_hi: 'स्वास्थ्य पैकेज' },
  ];
  defaultCats.forEach((c, idx) => {
    db.prepare('INSERT INTO test_categories (id, lab_id, name, name_hi, description, sort_order) VALUES (?, ?, ?, ?, ?, ?)').run(
      generateId('cat'),
      labId,
      c.name,
      c.name_hi,
      '',
      idx
    );
  });

  if (amountPaid > 0 || sellingPrice > 0) {
    db.prepare(`
      INSERT INTO lab_payments (id, lab_id, invoice_number, amount, payment_type, payment_method, status, notes, paid_at, created_at)
      VALUES (?, ?, ?, ?, 'website_sale', 'Bank Transfer / UPI', ?, ?, ?, ?)
    `).run(
      generateId('pay'),
      labId,
      `INV-${new Date().getFullYear()}-${crypto.randomInt(1000, 9999)}`,
      amountPaid,
      pendingAmount === 0 ? 'paid' : amountPaid > 0 ? 'partial' : 'pending',
      `Website sale: ${body.subscription_plan || 'Growth Annual'}`,
      amountPaid > 0 ? now : null,
      now
    );
  }

  const baseUrl = getBaseUrl(req);
  const labUrl = `${baseUrl}/lab/${finalSlug}`;
  const adminUrl = `${baseUrl}/lab-admin`;
  const inviteLink = `${baseUrl}/invite/${inviteToken}`;

  const templates = getSetting<NotificationTemplates>('notification_templates', {});
  const vars = {
    owner_name: body.owner_name.trim(),
    owner_email: body.owner_email.trim().toLowerCase(),
    website_name: (body.website_name || body.name).trim(),
    lab_url: labUrl,
    admin_url: adminUrl,
    invite_link: inviteLink,
    temp_password: tempPassword,
  };

  const emailResult = await sendRealEmail({
    to: body.owner_email.trim(),
    subject: renderTemplate(templates.lab_welcome_email_subject || 'Welcome to {{website_name}}', vars),
    text: renderTemplate(templates.lab_welcome_email_body || 'Your lab URL: {{lab_url}}\nInvite: {{invite_link}}', vars),
    labId,
    eventType: 'lab_welcome',
  });

  const whatsappResult = await sendRealWhatsApp({
    to: body.whatsapp_number.trim(),
    message: renderTemplate(templates.lab_welcome_whatsapp || 'Welcome {{owner_name}}, your lab website {{website_name}} is live at {{lab_url}}. Activate here: {{invite_link}}', vars),
    labId,
    eventType: 'lab_welcome',
  });

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId,
    action: 'create_lab',
    details: `Created lab ${body.name} (/lab/${finalSlug})`,
    ipAddress: req.ip,
  });

  const createdLab = db.prepare('SELECT * FROM labs WHERE id = ?').get(labId);
  res.status(201).json({
    lab: createdLab,
    credentials: {
      email: body.owner_email.trim().toLowerCase(),
      tempPassword,
      inviteLink,
      labUrl,
    },
    notifications: {
      email: emailResult,
      whatsapp: whatsappResult,
    },
  });
});

app.patch('/api/super-admin/labs/:id', requireSuperAdmin, (req: AuthRequest, res) => {
  const { id } = req.params;
  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(id) as Record<string, unknown> | undefined;
  if (!lab) {
    return res.status(404).json({ error: 'Laboratory not found.' });
  }

  const b = req.body as {
    name?: string;
    website_name?: string;
    slug?: string;
    custom_domain?: string;
    logo_url?: string;
    tagline?: string;
    address?: string;
    city?: string;
    contact_number?: string;
    whatsapp_number?: string;
    owner_name?: string;
    owner_email?: string;
    status?: string;
    subscription_plan?: string;
    selling_price?: number;
    subscription_expiry?: string;
    auto_suspend_on_expiry?: boolean;
    permissions?: string[];
  };

  const nextSlug = b.slug ? slugify(b.slug) : (lab.slug as string);
  if (nextSlug !== lab.slug) {
    const taken = db.prepare('SELECT id FROM labs WHERE slug = ? AND id != ?').get(nextSlug, id);
    if (taken) {
      return res.status(409).json({ error: `Slug "/lab/${nextSlug}" is already in use.` });
    }
  }

  const nextSellingPrice = b.selling_price !== undefined ? Number(b.selling_price) : Number(lab.selling_price);
  const paid = Number(lab.amount_paid || 0);
  const nextPending = Math.max(0, nextSellingPrice - paid);

  db.prepare(`
    UPDATE labs SET
      name = ?, website_name = ?, slug = ?, custom_domain = ?,
      logo_url = ?, tagline = ?,
      address = ?, city = ?, contact_number = ?, whatsapp_number = ?,
      owner_name = ?, owner_email = ?, status = ?, subscription_plan = ?,
      selling_price = ?, pending_amount = ?, subscription_expiry = ?,
      auto_suspend_on_expiry = ?
    WHERE id = ?
  `).run(
    String(b.name ?? lab.name),
    String(b.website_name ?? lab.website_name),
    nextSlug,
    String(b.custom_domain ?? lab.custom_domain ?? ''),
    String(b.logo_url ?? lab.logo_url ?? ''),
    String(b.tagline ?? lab.tagline ?? ''),
    String(b.address ?? lab.address),
    String(b.city ?? lab.city),
    String(b.contact_number ?? lab.contact_number),
    String(b.whatsapp_number ?? lab.whatsapp_number),
    String(b.owner_name ?? lab.owner_name),
    String(b.owner_email ?? lab.owner_email),
    String(b.status ?? lab.status),
    String(b.subscription_plan ?? lab.subscription_plan),
    nextSellingPrice,
    nextPending,
    String(b.subscription_expiry ?? lab.subscription_expiry),
    b.auto_suspend_on_expiry !== undefined ? (b.auto_suspend_on_expiry ? 1 : 0) : Number(lab.auto_suspend_on_expiry),
    id
  );

  if (b.permissions || b.owner_email || b.owner_name) {
    const owner = db.prepare('SELECT id, email, name, permissions FROM users WHERE lab_id = ? AND role = ?').get(id, 'lab_owner') as
      | { id: string; email: string; name: string; permissions: string }
      | undefined;
    if (owner) {
      db.prepare('UPDATE users SET email = ?, name = ?, permissions = ? WHERE id = ?').run(
        b.owner_email ? b.owner_email.trim().toLowerCase() : owner.email,
        b.owner_name ?? owner.name,
        b.permissions ? JSON.stringify(b.permissions) : owner.permissions,
        owner.id
      );
    }
  }

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId: id,
    action: 'update_lab',
    details: `Updated lab ${b.name ?? lab.name} (status: ${b.status ?? lab.status})`,
    ipAddress: req.ip,
  });

  const updated = db.prepare('SELECT * FROM labs WHERE id = ?').get(id);
  res.json({ lab: updated });
});

app.delete('/api/super-admin/labs/:id', requireSuperAdmin, (req: AuthRequest, res) => {
  const { id } = req.params;
  const lab = db.prepare('SELECT name FROM labs WHERE id = ?').get(id) as { name: string } | undefined;
  if (!lab) {
    return res.status(404).json({ error: 'Laboratory not found.' });
  }
  db.prepare('DELETE FROM labs WHERE id = ?').run(id);
  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId: null,
    action: 'delete_lab',
    details: `Deleted laboratory ${lab.name} (${id})`,
    ipAddress: req.ip,
  });
  res.json({ ok: true });
});

app.post('/api/super-admin/labs/:id/resend-invite', requireSuperAdmin, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(id) as Record<string, string> | undefined;
  const owner = db.prepare('SELECT * FROM users WHERE lab_id = ? AND role = ?').get(id, 'lab_owner') as Record<string, string> | undefined;
  if (!lab || !owner) {
    return res.status(404).json({ error: 'Laboratory or owner user not found.' });
  }

  const inviteToken = crypto.randomBytes(20).toString('hex');
  const inviteExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
  db.prepare('UPDATE users SET invite_token = ?, invite_expires_at = ? WHERE id = ?').run(inviteToken, inviteExpiresAt, owner.id);

  const baseUrl = getBaseUrl(req);
  const inviteLink = `${baseUrl}/invite/${inviteToken}`;
  const labUrl = `${baseUrl}/lab/${lab.slug}`;
  const adminUrl = `${baseUrl}/lab-admin`;
  const templates = getSetting<NotificationTemplates>('notification_templates', {});
  const vars = {
    owner_name: lab.owner_name,
    owner_email: lab.owner_email,
    website_name: lab.website_name,
    lab_url: labUrl,
    admin_url: adminUrl,
    invite_link: inviteLink,
  };

  const emailResult = await sendRealEmail({
    to: lab.owner_email,
    subject: renderTemplate(templates.lab_welcome_email_subject || 'Activate {{website_name}}', vars),
    text: renderTemplate(templates.lab_welcome_email_body || 'Activate link: {{invite_link}}', vars),
    labId: id,
    eventType: 'lab_welcome',
  });

  const whatsappResult = await sendRealWhatsApp({
    to: lab.whatsapp_number,
    message: renderTemplate(templates.lab_welcome_whatsapp || 'Activate {{website_name}}: {{invite_link}}', vars),
    labId: id,
    eventType: 'lab_welcome',
  });

  res.json({ inviteLink, notifications: { email: emailResult, whatsapp: whatsappResult } });
});

app.post('/api/super-admin/labs/:id/payments', requireSuperAdmin, (req: AuthRequest, res) => {
  const { id } = req.params;
  const { amount, payment_type, payment_method, notes, extend_months } = req.body as {
    amount?: number;
    payment_type?: string;
    payment_method?: string;
    notes?: string;
    extend_months?: number;
  };

  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(id) as
    | { id: string; name: string; selling_price: number; amount_paid: number; pending_amount: number; subscription_expiry: string; status: string }
    | undefined;
  if (!lab) {
    return res.status(404).json({ error: 'Laboratory not found.' });
  }

  const paidNow = Math.max(0, Number(amount || 0));
  if (paidNow <= 0) {
    return res.status(400).json({ error: 'Payment amount must be greater than zero.' });
  }

  const now = new Date().toISOString();
  const invoiceNumber = `INV-${new Date().getFullYear()}-${crypto.randomInt(10000, 99999)}`;
  db.prepare(`
    INSERT INTO lab_payments (id, lab_id, invoice_number, amount, payment_type, payment_method, status, notes, paid_at, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 'paid', ?, ?, ?)
  `).run(
    generateId('pay'),
    id,
    invoiceNumber,
    paidNow,
    payment_type || 'partial_payment',
    payment_method || 'UPI / Bank Transfer',
    notes || '',
    now,
    now
  );

  const newAmountPaid = Number(lab.amount_paid || 0) + paidNow;
  const newSellingPrice = payment_type === 'subscription_renewal' ? Number(lab.selling_price || 0) + paidNow : Number(lab.selling_price || 0);
  const newPending = Math.max(0, newSellingPrice - newAmountPaid);

  let nextExpiry = lab.subscription_expiry;
  if (extend_months && Number(extend_months) > 0) {
    const baseDate = new Date(lab.subscription_expiry) > new Date() ? new Date(lab.subscription_expiry) : new Date();
    baseDate.setMonth(baseDate.getMonth() + Number(extend_months));
    nextExpiry = baseDate.toISOString().slice(0, 10);
  }

  db.prepare(`
    UPDATE labs SET selling_price = ?, amount_paid = ?, pending_amount = ?, subscription_expiry = ?, status = 'active'
    WHERE id = ?
  `).run(newSellingPrice, newAmountPaid, newPending, nextExpiry, id);

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId: id,
    action: 'record_payment',
    details: `Recorded INR ${paidNow} (${invoiceNumber}) for ${lab.name}`,
    ipAddress: req.ip,
  });

  res.status(201).json({ invoiceNumber, amountPaid: newAmountPaid, pendingAmount: newPending, subscriptionExpiry: nextExpiry });
});

app.post('/api/super-admin/labs/:id/send-renewal-reminder', requireSuperAdmin, async (req: AuthRequest, res) => {
  const { id } = req.params;
  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(id) as Record<string, string | number> | undefined;
  if (!lab) return res.status(404).json({ error: 'Laboratory not found.' });

  const templates = getSetting<NotificationTemplates>('notification_templates', {});
  const vars = {
    owner_name: lab.owner_name,
    website_name: lab.website_name,
    subscription_plan: lab.subscription_plan,
    subscription_expiry: lab.subscription_expiry,
    pending_amount: lab.pending_amount,
  };

  const emailResult = await sendRealEmail({
    to: String(lab.owner_email),
    subject: renderTemplate(templates.renewal_reminder_email_subject || 'Renewal Reminder — {{website_name}}', vars),
    text: renderTemplate(templates.renewal_reminder_email_body || 'Your plan expires on {{subscription_expiry}}.', vars),
    labId: id,
    eventType: 'renewal_reminder',
  });

  const whatsappResult = await sendRealWhatsApp({
    to: String(lab.whatsapp_number),
    message: `Hello ${lab.owner_name}, reminder that ${lab.website_name} (${lab.subscription_plan}) expires on ${lab.subscription_expiry}. Pending balance: INR ${lab.pending_amount}.`,
    labId: id,
    eventType: 'renewal_reminder',
  });

  res.json({ notifications: { email: emailResult, whatsapp: whatsappResult } });
});

app.post('/api/super-admin/enforce-subscriptions', requireSuperAdmin, (req: AuthRequest, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const expired = db
    .prepare(`SELECT id, name, subscription_expiry FROM labs WHERE status = 'active' AND auto_suspend_on_expiry = 1 AND subscription_expiry < ?`)
    .all(today) as Array<{ id: string; name: string; subscription_expiry: string }>;

  for (const lab of expired) {
    db.prepare(`UPDATE labs SET status = 'suspended' WHERE id = ?`).run(lab.id);
    logAudit({
      actorId: req.auth?.uid,
      actorEmail: req.auth?.email,
      actorRole: req.auth?.role,
      labId: lab.id,
      action: 'auto_suspend_expired',
      details: `Auto-suspended ${lab.name} (expired ${lab.subscription_expiry})`,
      ipAddress: req.ip,
    });
  }

  res.json({ suspendedCount: expired.length, suspendedLabs: expired });
});

app.get('/api/super-admin/bookings', requireSuperAdmin, (_req, res) => {
  const bookings = db
    .prepare(`
      SELECT b.*, l.name as lab_name, l.slug as lab_slug, l.website_name
      FROM bookings b
      JOIN labs l ON l.id = b.lab_id
      ORDER BY b.created_at DESC
    `)
    .all();
  res.json({ bookings });
});

app.get('/api/super-admin/payments', requireSuperAdmin, (_req, res) => {
  const payments = db
    .prepare(`
      SELECT p.*, l.name as lab_name, l.owner_name, l.owner_email, l.city, l.subscription_plan
      FROM lab_payments p
      JOIN labs l ON l.id = p.lab_id
      ORDER BY p.created_at DESC
    `)
    .all();
  res.json({ payments });
});

app.get('/api/super-admin/notifications', requireSuperAdmin, (_req, res) => {
  const logs = db
    .prepare(`
      SELECT n.*, l.website_name as lab_name
      FROM notification_logs n
      LEFT JOIN labs l ON l.id = n.lab_id
      ORDER BY n.created_at DESC
      LIMIT 100
    `)
    .all();
  res.json({ logs });
});

app.get('/api/super-admin/settings', requireSuperAdmin, (_req, res) => {
  const smtp = getEffectiveSmtpConfig();
  const whatsapp = getEffectiveWhatsAppConfig();
  const templates = getSetting<NotificationTemplates>('notification_templates', {});

  res.json({
    smtp: {
      ...smtp,
      pass_masked: maskSecret(smtp.pass),
      has_pass: Boolean(smtp.pass),
      pass: '',
    },
    whatsapp: {
      ...whatsapp,
      access_token_masked: maskSecret(whatsapp.access_token),
      has_access_token: Boolean(whatsapp.access_token),
      access_token: '',
      twilio_token_masked: maskSecret(whatsapp.twilio_token),
      has_twilio_token: Boolean(whatsapp.twilio_token),
      twilio_token: '',
    },
    templates,
  });
});

app.put('/api/super-admin/settings', requireSuperAdmin, (req: AuthRequest, res) => {
  const { smtp, whatsapp, templates } = req.body as {
    smtp?: Record<string, unknown>;
    whatsapp?: Record<string, unknown>;
    templates?: NotificationTemplates;
  };

  if (smtp) {
    const existing = getSetting<Record<string, unknown>>('smtp_config', {});
    const merged = {
      host: smtp.host ?? existing.host ?? '',
      port: Number(smtp.port ?? existing.port ?? 587),
      secure: Boolean(smtp.secure ?? existing.secure ?? false),
      user: smtp.user ?? existing.user ?? '',
      pass: smtp.pass && String(smtp.pass).trim() !== '' ? smtp.pass : existing.pass ?? '',
      from_name: smtp.from_name ?? existing.from_name ?? 'MedGrid Diagnostics',
      from_email: smtp.from_email ?? existing.from_email ?? '',
    };
    db.prepare('INSERT OR REPLACE INTO platform_settings (key, value) VALUES (?, ?)').run('smtp_config', JSON.stringify(merged));
  }

  if (whatsapp) {
    const existing = getSetting<Record<string, unknown>>('whatsapp_config', {});
    const merged = {
      provider: whatsapp.provider ?? existing.provider ?? 'meta_cloud_api',
      phone_number_id: whatsapp.phone_number_id ?? existing.phone_number_id ?? '',
      access_token:
        whatsapp.access_token && String(whatsapp.access_token).trim() !== '' ? whatsapp.access_token : existing.access_token ?? '',
      business_account_id: whatsapp.business_account_id ?? existing.business_account_id ?? '',
      api_version: whatsapp.api_version ?? existing.api_version ?? 'v21.0',
      twilio_sid: whatsapp.twilio_sid ?? existing.twilio_sid ?? '',
      twilio_token:
        whatsapp.twilio_token && String(whatsapp.twilio_token).trim() !== '' ? whatsapp.twilio_token : existing.twilio_token ?? '',
      twilio_from: whatsapp.twilio_from ?? existing.twilio_from ?? '',
    };
    db.prepare('INSERT OR REPLACE INTO platform_settings (key, value) VALUES (?, ?)').run('whatsapp_config', JSON.stringify(merged));
  }

  if (templates) {
    db.prepare('INSERT OR REPLACE INTO platform_settings (key, value) VALUES (?, ?)').run(
      'notification_templates',
      JSON.stringify(templates)
    );
  }

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    action: 'update_notification_settings',
    details: 'Updated SMTP/WhatsApp provider settings or templates',
    ipAddress: req.ip,
  });

  res.json({ ok: true });
});

app.post('/api/super-admin/settings/verify-smtp', requireSuperAdmin, async (_req, res) => {
  const result = await verifySmtpConnection();
  res.json(result);
});

app.post('/api/super-admin/settings/test-notification', requireSuperAdmin, async (req, res) => {
  const { channel, recipient } = req.body as { channel?: 'email' | 'whatsapp'; recipient?: string };
  if (!channel || !recipient) {
    return res.status(400).json({ error: 'Channel and recipient are required.' });
  }
  if (channel === 'email') {
    const result = await sendRealEmail({
      to: recipient,
      subject: 'MedGrid Platform — SMTP Delivery Test',
      text: 'This is a live SMTP verification email sent from your MedGrid Multi-Lab Platform.',
      eventType: 'provider_test',
    });
    return res.json(result);
  }
  const result = await sendRealWhatsApp({
    to: recipient,
    message: 'MedGrid Platform: Live WhatsApp API verification message.',
    eventType: 'provider_test',
  });
  return res.json(result);
});

app.get('/api/super-admin/audit-logs', requireSuperAdmin, (_req, res) => {
  const logs = db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100').all();
  res.json({ logs });
});

app.get('/api/super-admin/backup', requireSuperAdmin, (req: AuthRequest, res) => {
  const snapshot = {
    exported_at: new Date().toISOString(),
    labs: db.prepare('SELECT * FROM labs').all(),
    lab_payments: db.prepare('SELECT * FROM lab_payments').all(),
    test_categories: db.prepare('SELECT * FROM test_categories').all(),
    diagnostic_tests: db.prepare('SELECT * FROM diagnostic_tests').all(),
    bookings: db.prepare('SELECT * FROM bookings').all(),
    notification_logs: db.prepare('SELECT * FROM notification_logs').all(),
    audit_logs: db.prepare('SELECT * FROM audit_logs').all(),
  };
  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    action: 'download_backup',
    details: 'Exported platform database backup snapshot',
    ipAddress: req.ip,
  });
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename="medgrid-backup-${new Date().toISOString().slice(0, 10)}.json"`);
  res.send(JSON.stringify(snapshot, null, 2));
});

async function buildProjectZipBuffer(): Promise<Buffer> {
  const zip = new JSZip();
  const rootDir = process.cwd();
  const excludedDirs = new Set(['node_modules', 'dist', 'data', '.git', '.aistudio', '.vite']);
  const excludedFiles = new Set(['.env', 'medgrid-platform-source.zip']);

  const addDirectoryToZip = (currentDir: string, zipFolder: JSZip) => {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (excludedDirs.has(entry.name)) continue;
        const nextFolder = zipFolder.folder(entry.name);
        if (nextFolder) {
          addDirectoryToZip(path.join(currentDir, entry.name), nextFolder);
        }
      } else if (entry.isFile()) {
        if (
          excludedFiles.has(entry.name) ||
          entry.name.endsWith('.zip') ||
          entry.name.endsWith('.sqlite') ||
          entry.name.endsWith('.sqlite-wal') ||
          entry.name.endsWith('.sqlite-shm')
        ) {
          continue;
        }
        const fullPath = path.join(currentDir, entry.name);
        zipFolder.file(entry.name, fs.readFileSync(fullPath));
      }
    }
  };

  addDirectoryToZip(rootDir, zip);
  return zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 6 } });
}

app.get('/api/super-admin/export-project-zip', requireSuperAdmin, async (req: AuthRequest, res) => {
  try {
    const buffer = await buildProjectZipBuffer();

    logAudit({
      actorId: req.auth?.uid,
      actorEmail: req.auth?.email,
      actorRole: req.auth?.role,
      action: 'export_project_zip',
      details: `Exported complete platform source archive (${Math.round(buffer.length / 1024)} KB)`,
      ipAddress: req.ip,
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="medgrid-platform-source.zip"');
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to package project ZIP.' });
  }
});

// ==================== LAB OWNER ADMIN ROUTES (STRICT TENANT ISOLATION) ====================

app.get('/api/lab-admin/dashboard', requireLabOwner(), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const lab = db.prepare('SELECT * FROM labs WHERE id = ?').get(labId);
  const bookings = db.prepare('SELECT * FROM bookings WHERE lab_id = ? ORDER BY created_at DESC').all() as Array<{
    id: string;
    price: number;
    status: string;
    booking_date: string;
    created_at: string;
    is_demo: number;
  }>;
  const tests = db.prepare('SELECT id, is_package, is_active FROM diagnostic_tests WHERE lab_id = ?').all(labId) as Array<{
    id: string;
    is_package: number;
    is_active: number;
  }>;

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const weekAgoStr = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const monthPrefix = todayStr.slice(0, 7);

  const dailyBookings = bookings.filter((b) => b.booking_date === todayStr).length;
  const weeklyBookings = bookings.filter((b) => b.booking_date >= weekAgoStr).length;
  const monthlyBookings = bookings.filter((b) => b.booking_date.startsWith(monthPrefix)).length;
  const totalRevenue = bookings
    .filter((b) => !['cancelled', 'rejected'].includes(b.status))
    .reduce((acc, b) => acc + Number(b.price || 0), 0);

  res.json({
    lab,
    stats: {
      dailyBookings,
      weeklyBookings,
      monthlyBookings,
      totalBookings: bookings.length,
      pendingBookings: bookings.filter((b) => b.status === 'pending').length,
      activeTests: tests.filter((t) => t.is_active === 1).length,
      packagesCount: tests.filter((t) => t.is_package === 1).length,
      totalRevenue,
    },
    recentBookings: bookings.slice(0, 8),
  });
});

app.put('/api/lab-admin/profile', requireLabOwner('manage_profile'), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const current = db.prepare('SELECT * FROM labs WHERE id = ?').get(labId) as Record<string, unknown> | undefined;
  if (!current) return res.status(404).json({ error: 'Laboratory not found.' });

  const b = req.body as {
    name?: string;
    website_name?: string;
    tagline?: string;
    address?: string;
    city?: string;
    contact_number?: string;
    whatsapp_number?: string;
    owner_email?: string;
    logo_url?: string;
    banner_url?: string;
    theme_color?: string;
    custom_domain?: string;
  };

  db.prepare(`
    UPDATE labs SET
      name = ?, website_name = ?, tagline = ?, address = ?, city = ?,
      contact_number = ?, whatsapp_number = ?, owner_email = ?,
      logo_url = ?, banner_url = ?, theme_color = ?, custom_domain = ?
    WHERE id = ?
  `).run(
    String(b.name ?? current.name),
    String(b.website_name ?? current.website_name),
    String(b.tagline ?? current.tagline ?? ''),
    String(b.address ?? current.address),
    String(b.city ?? current.city),
    String(b.contact_number ?? current.contact_number),
    String(b.whatsapp_number ?? current.whatsapp_number),
    String(b.owner_email ?? current.owner_email),
    String(b.logo_url ?? current.logo_url ?? ''),
    String(b.banner_url ?? current.banner_url ?? ''),
    String(b.theme_color ?? current.theme_color ?? '#1D4ED8'),
    String(b.custom_domain ?? current.custom_domain ?? ''),
    labId
  );

  if (b.owner_email && b.owner_email !== current.owner_email) {
    db.prepare('UPDATE users SET email = ? WHERE id = ?').run(b.owner_email.trim().toLowerCase(), req.auth!.uid);
  }

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId,
    action: 'lab_profile_updated',
    details: 'Updated laboratory profile and contact settings',
    ipAddress: req.ip,
  });

  const updated = db.prepare('SELECT * FROM labs WHERE id = ?').get(labId);
  res.json({ lab: updated });
});

app.get('/api/lab-admin/categories', requireLabOwner(), (req: AuthRequest, res) => {
  const categories = db
    .prepare('SELECT * FROM test_categories WHERE lab_id = ? ORDER BY sort_order ASC, name ASC')
    .all(req.auth!.labId!);
  res.json({ categories });
});

app.post('/api/lab-admin/categories', requireLabOwner('manage_tests'), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const { name, name_hi, description } = req.body as { name?: string; name_hi?: string; description?: string };
  if (!name?.trim()) {
    return res.status(400).json({ error: 'Category name is required.' });
  }
  const id = generateId('cat');
  db.prepare('INSERT INTO test_categories (id, lab_id, name, name_hi, description, sort_order) VALUES (?, ?, ?, ?, ?, 0)').run(
    id,
    labId,
    name.trim(),
    (name_hi || '').trim(),
    (description || '').trim()
  );
  const category = db.prepare('SELECT * FROM test_categories WHERE id = ?').get(id);
  res.status(201).json({ category });
});

app.delete('/api/lab-admin/categories/:id', requireLabOwner('manage_tests'), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const result = db.prepare('DELETE FROM test_categories WHERE id = ? AND lab_id = ?').run(req.params.id, labId);
  if (result.changes === 0) return res.status(404).json({ error: 'Category not found in your lab.' });
  res.json({ ok: true });
});

app.get('/api/lab-admin/tests', requireLabOwner(), (req: AuthRequest, res) => {
  const tests = db
    .prepare(`
      SELECT t.*, c.name as category_name
      FROM diagnostic_tests t
      LEFT JOIN test_categories c ON c.id = t.category_id
      WHERE t.lab_id = ?
      ORDER BY t.is_package DESC, t.created_at DESC
    `)
    .all(req.auth!.labId!) as Array<Record<string, unknown>>;

  res.json({
    tests: tests.map((t) => ({
      ...t,
      package_items: JSON.parse((t.package_items as string) || '[]'),
    })),
  });
});

app.post('/api/lab-admin/tests', requireLabOwner('manage_tests'), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const b = req.body as {
    category_id?: string;
    name?: string;
    name_hi?: string;
    code?: string;
    price?: number;
    discounted_price?: number | null;
    description?: string;
    preparation?: string;
    sample_type?: string;
    reporting_time?: string;
    is_package?: boolean;
    package_items?: string[];
    home_collection_available?: boolean;
  };

  if (!b.name || b.price === undefined || Number(b.price) < 0) {
    return res.status(400).json({ error: 'Test name and valid price are required.' });
  }

  // Ensure category belongs to this lab if provided
  if (b.category_id) {
    const cat = db.prepare('SELECT id FROM test_categories WHERE id = ? AND lab_id = ?').get(b.category_id, labId);
    if (!cat) return res.status(400).json({ error: 'Invalid category for your laboratory.' });
  }

  const id = generateId('tst');
  const now = new Date().toISOString();
  db.prepare(`
    INSERT INTO diagnostic_tests (
      id, lab_id, category_id, name, name_hi, code, price, discounted_price,
      description, preparation, sample_type, reporting_time, is_package,
      package_items, home_collection_available, is_active, is_demo, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 0, ?)
  `).run(
    id,
    labId,
    b.category_id || null,
    b.name.trim(),
    (b.name_hi || '').trim(),
    (b.code || '').trim(),
    Number(b.price),
    b.discounted_price ? Number(b.discounted_price) : null,
    (b.description || 'Clinical diagnostic laboratory test.').trim(),
    (b.preparation || 'No special preparation required unless advised by your physician.').trim(),
    b.sample_type || 'Blood',
    b.reporting_time || '12 Hours',
    b.is_package ? 1 : 0,
    JSON.stringify(b.package_items || []),
    b.home_collection_available === false ? 0 : 1,
    now
  );

  const test = db.prepare('SELECT * FROM diagnostic_tests WHERE id = ?').get(id) as Record<string, unknown>;
  res.status(201).json({
    test: { ...test, package_items: JSON.parse((test.package_items as string) || '[]') },
  });
});

app.put('/api/lab-admin/tests/:id', requireLabOwner('manage_tests'), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const existing = db.prepare('SELECT * FROM diagnostic_tests WHERE id = ? AND lab_id = ?').get(req.params.id, labId) as
    | Record<string, unknown>
    | undefined;
  if (!existing) return res.status(404).json({ error: 'Test not found in your laboratory.' });

  const b = req.body as Record<string, unknown>;
  db.prepare(`
    UPDATE diagnostic_tests SET
      category_id = ?, name = ?, name_hi = ?, code = ?, price = ?, discounted_price = ?,
      description = ?, preparation = ?, sample_type = ?, reporting_time = ?,
      is_package = ?, package_items = ?, home_collection_available = ?, is_active = ?
    WHERE id = ? AND lab_id = ?
  `).run(
    (b.category_id !== undefined ? b.category_id : existing.category_id) as string | null,
    String(b.name ?? existing.name),
    String(b.name_hi ?? existing.name_hi ?? ''),
    String(b.code ?? existing.code ?? ''),
    b.price !== undefined ? Number(b.price) : Number(existing.price),
    (b.discounted_price !== undefined
      ? b.discounted_price
        ? Number(b.discounted_price)
        : null
      : existing.discounted_price) as number | null,
    String(b.description ?? existing.description),
    String(b.preparation ?? existing.preparation),
    String(b.sample_type ?? existing.sample_type),
    String(b.reporting_time ?? existing.reporting_time),
    b.is_package !== undefined ? (b.is_package ? 1 : 0) : Number(existing.is_package),
    b.package_items !== undefined ? JSON.stringify(b.package_items) : String(existing.package_items || '[]'),
    b.home_collection_available !== undefined ? (b.home_collection_available ? 1 : 0) : Number(existing.home_collection_available),
    b.is_active !== undefined ? (b.is_active ? 1 : 0) : Number(existing.is_active),
    req.params.id,
    labId
  );

  const updated = db.prepare('SELECT * FROM diagnostic_tests WHERE id = ?').get(req.params.id) as Record<string, unknown>;
  res.json({ test: { ...updated, package_items: JSON.parse((updated.package_items as string) || '[]') } });
});

app.delete('/api/lab-admin/tests/:id', requireLabOwner('manage_tests'), (req: AuthRequest, res) => {
  const result = db.prepare('DELETE FROM diagnostic_tests WHERE id = ? AND lab_id = ?').run(req.params.id, req.auth!.labId!);
  if (result.changes === 0) return res.status(404).json({ error: 'Test not found in your laboratory.' });
  res.json({ ok: true });
});

app.get('/api/lab-admin/bookings', requireLabOwner(), (req: AuthRequest, res) => {
  const bookings = db
    .prepare('SELECT * FROM bookings WHERE lab_id = ? ORDER BY created_at DESC')
    .all(req.auth!.labId!);
  res.json({ bookings });
});

app.patch('/api/lab-admin/bookings/:id/status', requireLabOwner('manage_bookings'), async (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const { status, notes } = req.body as { status?: string; notes?: string };
  const allowed = ['pending', 'confirmed', 'sample_collected', 'report_ready', 'completed', 'cancelled', 'rejected'];
  if (!status || !allowed.includes(status)) {
    return res.status(400).json({ error: 'Invalid booking status.' });
  }

  const booking = db.prepare('SELECT * FROM bookings WHERE id = ? AND lab_id = ?').get(req.params.id, labId) as
    | Record<string, string | number>
    | undefined;
  if (!booking) return res.status(404).json({ error: 'Booking not found in your laboratory.' });

  const now = new Date().toISOString();
  db.prepare('UPDATE bookings SET status = ?, notes = ?, updated_at = ? WHERE id = ? AND lab_id = ?').run(
    status,
    notes !== undefined ? notes : booking.notes,
    now,
    req.params.id,
    labId
  );

  const lab = db.prepare('SELECT website_name, whatsapp_number FROM labs WHERE id = ?').get(labId) as {
    website_name: string;
    whatsapp_number: string;
  };

  let notificationResult = null;
  if (booking.patient_email && ['confirmed', 'report_ready', 'rejected', 'cancelled'].includes(status)) {
    notificationResult = await sendRealEmail({
      to: String(booking.patient_email),
      subject: `Booking ${booking.booking_code} Status Update: ${status.replace('_', ' ').toUpperCase()}`,
      text: `Dear ${booking.patient_name},\n\nYour booking ${booking.booking_code} at ${lab.website_name} for ${booking.test_name} is now: ${status.replace('_', ' ').toUpperCase()}.\n${notes ? `Lab Note: ${notes}` : ''}`,
      labId,
      bookingId: String(booking.id),
      eventType: 'booking_status_update',
    });
  }

  logAudit({
    actorId: req.auth?.uid,
    actorEmail: req.auth?.email,
    actorRole: req.auth?.role,
    labId,
    action: 'update_booking_status',
    details: `Booking ${booking.booking_code} changed to ${status}`,
    ipAddress: req.ip,
  });

  const updated = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  res.json({ booking: updated, notificationResult });
});

app.get('/api/lab-admin/patients', requireLabOwner(), (req: AuthRequest, res) => {
  const labId = req.auth!.labId!;
  const patients = db
    .prepare(`
      SELECT
        patient_name,
        patient_mobile,
        MAX(patient_email) as patient_email,
        MAX(patient_age) as patient_age,
        MAX(patient_gender) as patient_gender,
        MAX(collection_address) as last_address,
        COUNT(*) as total_bookings,
        SUM(CASE WHEN status NOT IN ('cancelled', 'rejected') THEN price ELSE 0 END) as total_spent,
        MAX(booking_date) as last_visit,
        MIN(is_demo) as is_demo
      FROM bookings
      WHERE lab_id = ?
      GROUP BY patient_mobile, patient_name
      ORDER BY MAX(created_at) DESC
    `)
    .all(labId);
  res.json({ patients });
});

app.get('/api/lab-admin/notifications', requireLabOwner(), (req: AuthRequest, res) => {
  const logs = db
    .prepare('SELECT * FROM notification_logs WHERE lab_id = ? ORDER BY created_at DESC LIMIT 50')
    .all(req.auth!.labId!);
  res.json({ logs });
});

// ==================== PUBLIC MULTI-TENANT PATIENT BOOKING ROUTES ====================

app.get('/api/public/resolve-host', (req, res) => {
  const host = String(req.query.host || req.hostname || '')
    .trim()
    .toLowerCase()
    .replace(/:\d+$/, '');
  if (!host || host === 'localhost' || host === '127.0.0.1' || host === '0.0.0.0') {
    return res.json({ slug: null });
  }
  const row = db
    .prepare(`SELECT slug FROM labs WHERE LOWER(TRIM(custom_domain)) = ? AND custom_domain != ''`)
    .get(host) as { slug: string } | undefined;
  res.json({ slug: row?.slug || null });
});

app.get('/api/public/labs', (_req, res) => {
  const labs = db
    .prepare(`
      SELECT id, slug, name, website_name, custom_domain, logo_url, banner_url, address, city,
             contact_number, whatsapp_number, theme_color, tagline, status, is_demo
      FROM labs
      WHERE status = 'active'
      ORDER BY is_demo ASC, created_at DESC
    `)
    .all();

  const withCounts = (labs as Array<Record<string, unknown>>).map((l) => {
    const c = db.prepare('SELECT COUNT(*) as count FROM diagnostic_tests WHERE lab_id = ? AND is_active = 1').get(l.id as string) as {
      count: number;
    };
    return { ...l, test_count: c.count };
  });
  res.json({ labs: withCounts });
});

app.get('/api/public/search', (req, res) => {
  const rawQ = String(req.query.q || '').trim();
  if (!rawQ) {
    return res.json({ labs: [], tests: [] });
  }
  const like = `%${rawQ}%`;
  const matchedLabs = db
    .prepare(`
      SELECT id, slug, name, website_name, custom_domain, logo_url, banner_url, address, city,
             contact_number, whatsapp_number, theme_color, tagline, status, is_demo
      FROM labs
      WHERE status = 'active'
        AND (
          LOWER(website_name) LIKE LOWER(?)
          OR LOWER(name) LIKE LOWER(?)
          OR LOWER(city) LIKE LOWER(?)
          OR LOWER(slug) LIKE LOWER(?)
          OR LOWER(tagline) LIKE LOWER(?)
        )
      ORDER BY is_demo ASC, created_at DESC
      LIMIT 12
    `)
    .all(like, like, like, like, like);

  const matchedTests = db
    .prepare(`
      SELECT t.id, t.lab_id, t.name, t.name_hi, t.code, t.price, t.discounted_price,
             t.sample_type, t.reporting_time, t.is_package, t.home_collection_available,
             l.slug as lab_slug, l.website_name as lab_name, l.city as lab_city, l.whatsapp_number as lab_whatsapp
      FROM diagnostic_tests t
      JOIN labs l ON l.id = t.lab_id
      WHERE l.status = 'active' AND t.is_active = 1
        AND (
          LOWER(t.name) LIKE LOWER(?)
          OR LOWER(t.name_hi) LIKE LOWER(?)
          OR LOWER(t.code) LIKE LOWER(?)
          OR LOWER(t.description) LIKE LOWER(?)
          OR LOWER(t.sample_type) LIKE LOWER(?)
        )
      ORDER BY t.is_package DESC, t.price ASC
      LIMIT 24
    `)
    .all(like, like, like, like, like);

  res.json({ labs: matchedLabs, tests: matchedTests });
});

app.get('/api/public/labs/:slug', (req, res) => {
  const lab = db
    .prepare(`
      SELECT id, slug, name, website_name, custom_domain, logo_url, banner_url, address, city,
             contact_number, whatsapp_number, owner_name, theme_color, tagline, status, is_demo
      FROM labs
      WHERE slug = ? OR custom_domain = ?
    `)
    .get(req.params.slug, req.params.slug) as Record<string, unknown> | undefined;

  if (!lab) {
    return res.status(404).json({ error: 'Diagnostic laboratory website not found.' });
  }
  if (lab.status !== 'active') {
    return res.status(403).json({
      error: lab.status === 'suspended' ? 'This laboratory portal is temporarily suspended.' : 'This laboratory website is currently deactivated.',
      status: lab.status,
      labName: lab.website_name,
    });
  }

  const categories = db
    .prepare('SELECT * FROM test_categories WHERE lab_id = ? ORDER BY sort_order ASC, name ASC')
    .all(lab.id as string);

  const tests = db
    .prepare(`
      SELECT t.*, c.name as category_name, c.name_hi as category_name_hi
      FROM diagnostic_tests t
      LEFT JOIN test_categories c ON c.id = t.category_id
      WHERE t.lab_id = ? AND t.is_active = 1
      ORDER BY t.is_package DESC, t.name ASC
    `)
    .all(lab.id as string) as Array<Record<string, unknown>>;

  res.json({
    lab,
    categories,
    tests: tests.map((t) => ({
      ...t,
      package_items: JSON.parse((t.package_items as string) || '[]'),
    })),
  });
});

app.post('/api/public/labs/:slug/bookings', async (req, res) => {
  const lab = db.prepare('SELECT * FROM labs WHERE slug = ? AND status = ?').get(req.params.slug, 'active') as
    | Record<string, string>
    | undefined;
  if (!lab) {
    return res.status(404).json({ error: 'Laboratory not found or currently inactive.' });
  }

  const b = req.body as {
    test_id?: string;
    patient_name?: string;
    patient_mobile?: string;
    patient_email?: string;
    patient_age?: number;
    patient_gender?: string;
    collection_type?: 'home_collection' | 'lab_visit';
    collection_address?: string;
    booking_date?: string;
    time_slot?: string;
  };

  if (!b.test_id || !b.patient_name?.trim() || !b.patient_mobile?.trim() || !b.patient_age || !b.patient_gender || !b.booking_date || !b.time_slot) {
    return res.status(400).json({ error: 'Please complete all required patient and appointment fields.' });
  }

  if (b.collection_type === 'home_collection' && !b.collection_address?.trim()) {
    return res.status(400).json({ error: 'Home sample collection address is required.' });
  }

  const test = db.prepare('SELECT * FROM diagnostic_tests WHERE id = ? AND lab_id = ? AND is_active = 1').get(b.test_id, lab.id) as
    | { id: string; name: string; price: number; discounted_price: number | null; home_collection_available: number }
    | undefined;

  if (!test) {
    return res.status(404).json({ error: 'Selected diagnostic test is unavailable at this laboratory.' });
  }

  const finalPrice = test.discounted_price ?? test.price;
  const bookingId = generateId('bkg');
  const bookingCode = generateBookingCode(lab.slug);
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO bookings (
      id, booking_code, lab_id, test_id, test_name, price,
      patient_name, patient_mobile, patient_email, patient_age, patient_gender,
      collection_type, collection_address, booking_date, time_slot,
      status, notes, is_demo, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', '', 0, ?, ?)
  `).run(
    bookingId,
    bookingCode,
    lab.id,
    test.id,
    test.name,
    finalPrice,
    b.patient_name.trim(),
    b.patient_mobile.trim(),
    (b.patient_email || '').trim(),
    Number(b.patient_age),
    b.patient_gender,
    b.collection_type || 'lab_visit',
    (b.collection_address || '').trim(),
    b.booking_date,
    b.time_slot,
    now,
    now
  );

  const templates = getSetting<NotificationTemplates>('notification_templates', {});
  const labUrl = `${getBaseUrl(req)}/lab/${lab.slug}`;
  const vars = {
    booking_code: bookingCode,
    website_name: lab.website_name,
    patient_name: b.patient_name.trim(),
    patient_mobile: b.patient_mobile.trim(),
    test_name: test.name,
    price: finalPrice,
    booking_date: b.booking_date,
    time_slot: b.time_slot,
    collection_type: b.collection_type === 'home_collection' ? 'Home Sample Collection' : 'Lab Visit',
    collection_address: b.collection_address?.trim() || lab.address,
    lab_url: labUrl,
  };

  // Real notifications (patient + lab owner)
  const ownerEmailRes = await sendRealEmail({
    to: lab.owner_email,
    subject: renderTemplate(templates.booking_owner_email_subject || 'New Booking {{booking_code}}', vars),
    text: renderTemplate(templates.booking_owner_email_body || 'New booking {{booking_code}} for {{test_name}}', vars),
    labId: lab.id,
    bookingId,
    eventType: 'booking_owner_alert',
  });

  const ownerWaRes = await sendRealWhatsApp({
    to: lab.whatsapp_number,
    message: renderTemplate(templates.booking_owner_whatsapp || 'New Booking {{booking_code}}: {{patient_name}} booked {{test_name}}', vars),
    labId: lab.id,
    bookingId,
    eventType: 'booking_owner_alert',
  });

  let patientEmailRes = null;
  if (b.patient_email?.trim()) {
    patientEmailRes = await sendRealEmail({
      to: b.patient_email.trim(),
      subject: renderTemplate(templates.booking_patient_email_subject || 'Booking Confirmed: {{booking_code}}', vars),
      text: renderTemplate(templates.booking_patient_email_body || 'Booking {{booking_code}} confirmed.', vars),
      labId: lab.id,
      bookingId,
      eventType: 'booking_confirmation',
    });
  }

  const patientWaRes = await sendRealWhatsApp({
    to: b.patient_mobile.trim(),
    message: renderTemplate(templates.booking_patient_whatsapp || 'Booking {{booking_code}} at {{website_name}} confirmed.', vars),
    labId: lab.id,
    bookingId,
    eventType: 'booking_confirmation',
  });

  const created = db.prepare('SELECT * FROM bookings WHERE id = ?').get(bookingId);
  res.status(201).json({
    booking: created,
    notifications: {
      ownerEmail: ownerEmailRes,
      ownerWhatsApp: ownerWaRes,
      patientEmail: patientEmailRes,
      patientWhatsApp: patientWaRes,
    },
  });
});

app.get('/api/public/bookings/track', (req, res) => {
  const code = String(req.query.code || '').trim().toUpperCase();
  const mobile = String(req.query.mobile || '').replace(/[^\d]/g, '');

  if (!code) {
    return res.status(400).json({ error: 'Booking ID is required.' });
  }

  const row = db
    .prepare(`
      SELECT b.*, l.name as lab_name, l.website_name, l.slug as lab_slug, l.address as lab_address,
             l.contact_number as lab_contact, l.whatsapp_number as lab_whatsapp
      FROM bookings b
      JOIN labs l ON l.id = b.lab_id
      WHERE UPPER(b.booking_code) = ?
    `)
    .get(code) as Record<string, unknown> | undefined;

  if (!row) {
    return res.status(404).json({ error: 'No booking found with that Booking ID.' });
  }

  if (mobile) {
    const storedDigits = String(row.patient_mobile || '').replace(/[^\d]/g, '');
    if (!storedDigits.endsWith(mobile.slice(-6))) {
      return res.status(403).json({ error: 'Mobile number does not match this Booking ID.' });
    }
  }

  res.json({ booking: row });
});

app.post('/api/public/labs/:slug/bookings/:bookingCode/cancel', async (req, res) => {
  const { slug, bookingCode } = req.params;
  const { mobile } = req.body as { mobile?: string };

  const lab = db.prepare('SELECT * FROM labs WHERE slug = ?').get(slug) as Record<string, string> | undefined;
  if (!lab) return res.status(404).json({ error: 'Laboratory not found.' });

  const booking = db
    .prepare('SELECT * FROM bookings WHERE UPPER(booking_code) = ? AND lab_id = ?')
    .get(bookingCode.toUpperCase(), lab.id) as Record<string, string | number> | undefined;

  if (!booking) return res.status(404).json({ error: 'Booking not found.' });

  if (mobile) {
    const provided = mobile.replace(/[^\d]/g, '');
    const stored = String(booking.patient_mobile).replace(/[^\d]/g, '');
    if (!stored.endsWith(provided.slice(-6))) {
      return res.status(403).json({ error: 'Mobile number verification failed.' });
    }
  }

  if (['completed', 'cancelled'].includes(String(booking.status))) {
    return res.status(400).json({ error: `Cannot cancel a booking that is already ${booking.status}.` });
  }

  db.prepare(`UPDATE bookings SET status = 'cancelled', updated_at = ? WHERE id = ?`).run(new Date().toISOString(), booking.id);

  const templates = getSetting<NotificationTemplates>('notification_templates', {});
  const vars = {
    booking_code: booking.booking_code,
    website_name: lab.website_name,
    patient_name: booking.patient_name,
    test_name: booking.test_name,
    booking_date: booking.booking_date,
  };

  const ownerWa = await sendRealWhatsApp({
    to: lab.whatsapp_number,
    message: renderTemplate(templates.booking_cancel_owner_whatsapp || 'Booking Cancelled ({{booking_code}}): {{patient_name}} cancelled {{test_name}}.', vars),
    labId: lab.id,
    bookingId: String(booking.id),
    eventType: 'booking_cancellation',
  });

  const ownerEmail = await sendRealEmail({
    to: lab.owner_email,
    subject: `Booking Cancelled: ${booking.booking_code} — ${lab.website_name}`,
    text: `Patient ${booking.patient_name} cancelled booking ${booking.booking_code} (${booking.test_name}) scheduled for ${booking.booking_date}.`,
    labId: lab.id,
    bookingId: String(booking.id),
    eventType: 'booking_cancellation',
  });

  res.json({ ok: true, notifications: { ownerWa, ownerEmail } });
});

app.get('/download/medgrid-platform-source.zip', async (_req, res) => {
  try {
    const buffer = await buildProjectZipBuffer();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="medgrid-platform-source.zip"');
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to package project ZIP.' });
  }
});

// ==================== SEO: ROBOTS.TXT & DYNAMIC SITEMAP ====================

app.get('/robots.txt', (req, res) => {
  const baseUrl = getBaseUrl(req);
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.send(
    [
      'User-agent: *',
      'Allow: /',
      'Allow: /lab/',
      'Disallow: /super-admin',
      'Disallow: /lab-admin',
      'Disallow: /invite/',
      'Disallow: /api/',
      `Sitemap: ${baseUrl}/sitemap.xml`,
    ].join('\n')
  );
});

app.get('/sitemap.xml', (req, res) => {
  const baseUrl = getBaseUrl(req);
  const activeLabs = db
    .prepare(`SELECT slug, created_at FROM labs WHERE status = 'active' ORDER BY created_at DESC`)
    .all() as Array<{ slug: string; created_at: string }>;

  const escapeXml = (str: string) =>
    str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  const urls = [
    `  <url>\n    <loc>${escapeXml(baseUrl)}/</loc>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>`,
    ...activeLabs.map(
      (l) =>
        `  <url>\n    <loc>${escapeXml(`${baseUrl}/lab/${l.slug}`)}</loc>\n    <lastmod>${escapeXml(
          (l.created_at || new Date().toISOString()).slice(0, 10)
        )}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>0.9</priority>\n  </url>`
    ),
  ].join('\n');

  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>`);
});

// ==================== VITE / STATIC SERVING ====================

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  const port = Number(process.env.PORT || 3000);

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`MedGrid server running on http://0.0.0.0:${port}`);
  });
}

startServer();
