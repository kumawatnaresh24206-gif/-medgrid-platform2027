import React, { useCallback, useEffect, useState } from 'react';
import { apiFetch, type UserProfile } from './lib/api';
import { AppSettingsProvider } from './lib/i18n';
import { PublicPlatformHome } from './components/PublicPlatformHome';
import { PublicLabWebsite } from './components/PublicLabWebsite';
import { InviteAcceptPage, LoginPage } from './components/AuthPages';
import { SuperAdminDashboard } from './components/SuperAdminDashboard';
import { LabOwnerDashboard } from './components/LabOwnerDashboard';

function AppRoutes() {
  const [path, setPath] = useState<string>(() => window.location.pathname || '/');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [customDomainSlug, setCustomDomainSlug] = useState<string | null>(null);

  const navigate = useCallback((nextPath: string) => {
    if (nextPath !== window.location.pathname + window.location.search) {
      window.history.pushState({}, '', nextPath);
    }
    setPath(nextPath.split('?')[0] || '/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onPopState = () => setPath(window.location.pathname || '/');
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    const checkAuth = apiFetch<{ user: UserProfile }>('/api/auth/me')
      .then((res) => setUser(res.user))
      .catch(() => setUser(null));

    const checkHost =
      window.location.pathname === '/' && window.location.hostname
        ? apiFetch<{ slug: string | null }>(`/api/public/resolve-host?host=${encodeURIComponent(window.location.hostname)}`)
            .then((res) => setCustomDomainSlug(res.slug))
            .catch(() => setCustomDomainSlug(null))
        : Promise.resolve();

    Promise.all([checkAuth, checkHost]).finally(() => setAuthChecked(true));
  }, []);

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setUser(null);
    navigate('/');
  };

  if (!authChecked) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white dark:bg-slate-950">
        <div className="text-sm text-slate-500">Initializing MedGrid Platform...</div>
      </div>
    );
  }

  // Match /invite/:token
  const inviteMatch = path.match(/^\/invite\/([^/]+)\/?$/);
  if (inviteMatch) {
    return (
      <InviteAcceptPage
        token={inviteMatch[1]}
        onSuccess={(loggedInUser) => {
          setUser(loggedInUser);
          navigate('/lab-admin');
        }}
        onNavigate={navigate}
      />
    );
  }

  // Match /super-admin
  if (path.startsWith('/super-admin')) {
    if (!user || user.role !== 'super_admin') {
      return (
        <LoginPage
          portalType="super_admin"
          onLoginSuccess={(loggedInUser) => {
            setUser(loggedInUser);
            if (loggedInUser.role === 'lab_owner') {
              navigate('/lab-admin');
            }
          }}
          onNavigate={navigate}
        />
      );
    }
    return <SuperAdminDashboard user={user} onLogout={handleLogout} onNavigate={navigate} />;
  }

  // Match /lab-admin or /lab/:slug/admin
  if (path.startsWith('/lab-admin') || /^\/lab\/[^/]+\/admin\/?$/.test(path)) {
    if (!user || user.role !== 'lab_owner') {
      return (
        <LoginPage
          portalType="lab_owner"
          onLoginSuccess={(loggedInUser) => {
            setUser(loggedInUser);
            if (loggedInUser.role === 'super_admin') {
              navigate('/super-admin');
            }
          }}
          onNavigate={navigate}
        />
      );
    }
    return <LabOwnerDashboard user={user} onLogout={handleLogout} onNavigate={navigate} />;
  }

  // Match /lab/:slug
  const labMatch = path.match(/^\/lab\/([^/]+)\/?$/);
  if (labMatch) {
    return <PublicLabWebsite slug={labMatch[1]} onNavigate={navigate} />;
  }

  // Mapped custom domain root routing
  if (path === '/' && customDomainSlug) {
    return <PublicLabWebsite slug={customDomainSlug} onNavigate={navigate} />;
  }

  // Default Platform Home / Directory
  return <PublicPlatformHome onNavigate={navigate} />;
}

export default function App() {
  return (
    <AppSettingsProvider>
      <AppRoutes />
    </AppSettingsProvider>
  );
}
