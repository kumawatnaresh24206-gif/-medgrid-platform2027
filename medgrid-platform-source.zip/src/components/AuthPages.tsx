import React, { useEffect, useState } from 'react';
import { ArrowLeft, KeyRound, Lock, ShieldCheck } from 'lucide-react';
import { apiFetch, type UserProfile } from '../lib/api';
import { ThemeLangToolbar } from './ThemeLangToolbar';

interface LoginPageProps {
  portalType: 'super_admin' | 'lab_owner';
  onLoginSuccess: (user: UserProfile) => void;
  onNavigate: (path: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ portalType, onLoginSuccess, onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await apiFetch<{ user: UserProfile }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      });
      onLoginSuccess(res.user);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const quickFillDemo = (demoEmail: string, demoPassword: string) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
  };

  return (
    <div className="flex min-h-screen flex-col justify-between bg-slate-50 px-6 py-8 dark:bg-slate-950">
      <div className="mx-auto flex w-full max-w-5xl items-center justify-between">
        <button
          type="button"
          onClick={() => onNavigate('/')}
          className="inline-flex items-center gap-2 text-sm font-medium text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Platform</span>
        </button>
        <ThemeLangToolbar />
      </div>

      <div className="mx-auto my-8 w-full max-w-md rounded-xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2.5 text-blue-700 dark:text-blue-400">
          {portalType === 'super_admin' ? <ShieldCheck className="h-6 w-6" /> : <Lock className="h-6 w-6" />}
          <span className="font-display text-sm font-semibold">
            {portalType === 'super_admin' ? 'Super Admin Console' : 'Lab Owner Admin Portal'}
          </span>
        </div>

        <h1 className="mt-3 font-display text-2xl font-bold text-slate-900 dark:text-white">
          {portalType === 'super_admin' ? 'Platform Owner Sign In' : 'Sign in to your Laboratory'}
        </h1>
        <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
          {portalType === 'super_admin'
            ? 'Manage all diagnostic labs, sales, subscriptions, and notification gateways.'
            : 'Manage your tests, prices, patient bookings, and laboratory website.'}
        </p>

        {error && (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@domain.com"
              className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
          <div>
            <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-blue-700 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-800 disabled:opacity-60"
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        {/* Demo Quick-Fill Credentials for Evaluation */}
        <div className="mt-6 border-t border-slate-200 pt-5 dark:border-slate-800">
          <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Demo Demonstration Credentials</div>
          <div className="mt-2.5 flex flex-wrap gap-2">
            {portalType === 'super_admin' ? (
              <button
                type="button"
                onClick={() => quickFillDemo('admin@medgrid.io', 'SuperAdmin@2026!')}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                Fill Super Admin (admin@medgrid.io)
              </button>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => quickFillDemo('rajesh@healthcare-demo.in', 'LabOwner@2026!')}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  HealthCare Demo Lab
                </button>
                <button
                  type="button"
                  onClick={() => quickFillDemo('anita@modern-demo.in', 'LabOwner@2026!')}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
                >
                  Modern Diagnostics Demo
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="text-center text-xs text-slate-500">MedGrid Multi-Tenant Diagnostic Platform</div>
    </div>
  );
};

interface InviteAcceptPageProps {
  token: string;
  onSuccess: (user: UserProfile) => void;
  onNavigate: (path: string) => void;
}

export const InviteAcceptPage: React.FC<InviteAcceptPageProps> = ({ token, onSuccess, onNavigate }) => {
  const [inviteInfo, setInviteInfo] = useState<{
    email: string;
    name: string;
    lab?: { name: string; website_name: string; slug: string; city: string } | null;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    apiFetch<{
      email: string;
      name: string;
      lab?: { name: string; website_name: string; slug: string; city: string } | null;
    }>(`/api/auth/invite/${token}`)
      .then(setInviteInfo)
      .catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false));
  }, [token]);

  const handleActivate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      setError('Password must be at least 8 characters.');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match.');
      return;
    }
    setSubmitting(true);
    setError('');
    try {
      const res = await apiFetch<{ user: UserProfile }>('/api/auth/accept-invite', {
        method: 'POST',
        body: JSON.stringify({ token, password }),
      });
      onSuccess(res.user);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Activation failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-6 dark:bg-slate-950">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center gap-2 text-blue-700 dark:text-blue-400">
          <KeyRound className="h-5 w-5" />
          <span className="font-display text-sm font-semibold">Laboratory Owner Invitation</span>
        </div>

        {loading ? (
          <p className="mt-4 text-sm text-slate-500">Verifying secure invitation link...</p>
        ) : error && !inviteInfo ? (
          <div className="mt-4 space-y-4">
            <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
              {error}
            </div>
            <button
              type="button"
              onClick={() => onNavigate('/lab-admin')}
              className="w-full rounded-lg bg-blue-700 py-2.5 text-sm font-semibold text-white"
            >
              Go to Lab Owner Sign In
            </button>
          </div>
        ) : (
          <form onSubmit={handleActivate} className="mt-4 space-y-4">
            <h1 className="font-display text-xl font-bold text-slate-900 dark:text-white">
              Activate {inviteInfo?.lab?.website_name || 'Your Laboratory'}
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              Welcome {inviteInfo?.name}. Set a secure password for <span className="font-mono">{inviteInfo?.email}</span> to access your Lab Owner Dashboard.
            </p>

            {error && (
              <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>
            )}

            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">New Password (min 8 chars)</label>
              <input
                type="password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm dark:border-slate-700 dark:bg-slate-950"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">Confirm Password</label>
              <input
                type="password"
                required
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm dark:border-slate-700 dark:bg-slate-950"
              />
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full rounded-lg bg-blue-700 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
            >
              {submitting ? 'Activating Account...' : 'Activate & Open Dashboard'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
