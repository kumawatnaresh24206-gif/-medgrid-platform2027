import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  Check,
  Download,
  Edit3,
  ExternalLink,
  FileSpreadsheet,
  FlaskConical,
  LogOut,
  MessageCircle,
  Plus,
  QrCode,
  Settings,
  Trash2,
  Users,
  X,
} from 'lucide-react';
import {
  apiFetch,
  formatCurrency,
  type BookingRecord,
  type DiagnosticTest,
  type LabRecord,
  type NotificationLogRecord,
  type TestCategory,
  type UserProfile,
} from '../lib/api';
import {
  downloadBookingReceiptPdf,
  exportBookingsToExcel,
  exportPatientsToExcel,
  exportTestsToExcel,
} from '../lib/exports';
import { useAppSettings } from '../lib/i18n';
import { QrCodeModal } from './QrCodeModal';
import { StatusIndicator } from './StatusBadge';
import { ThemeLangToolbar } from './ThemeLangToolbar';

interface LabOwnerDashboardProps {
  user: UserProfile;
  onLogout: () => void;
  onNavigate: (path: string) => void;
}

type LabTab = 'overview' | 'tests' | 'bookings' | 'patients' | 'profile' | 'logs';

export const LabOwnerDashboard: React.FC<LabOwnerDashboardProps> = ({ user, onLogout, onNavigate }) => {
  const { t } = useAppSettings();
  const [tab, setTab] = useState<LabTab>('overview');
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [lab, setLab] = useState<LabRecord | null>(null);
  const [stats, setStats] = useState({
    dailyBookings: 0,
    weeklyBookings: 0,
    monthlyBookings: 0,
    totalBookings: 0,
    pendingBookings: 0,
    activeTests: 0,
    packagesCount: 0,
    totalRevenue: 0,
  });
  const [categories, setCategories] = useState<TestCategory[]>([]);
  const [tests, setTests] = useState<DiagnosticTest[]>([]);
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [patients, setPatients] = useState<Array<Record<string, unknown>>>([]);
  const [logs, setLogs] = useState<NotificationLogRecord[]>([]);

  // Filters
  const [datasetFilter, setDatasetFilter] = useState<'all' | 'live' | 'demo'>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [collectionFilter, setCollectionFilter] = useState<'all' | 'home_collection' | 'lab_visit'>('all');
  const [selectedPatientMobile, setSelectedPatientMobile] = useState<string | null>(null);

  // QR Modal
  const [qrOpen, setQrOpen] = useState(false);

  // Category Form
  const [newCatName, setNewCatName] = useState('');
  const [newCatNameHi, setNewCatNameHi] = useState('');

  // Test Modal
  const [testModalOpen, setTestModalOpen] = useState(false);
  const [editingTest, setEditingTest] = useState<DiagnosticTest | null>(null);
  const [testForm, setTestForm] = useState({
    category_id: '',
    name: '',
    name_hi: '',
    code: '',
    price: '',
    discounted_price: '',
    description: '',
    preparation: '',
    sample_type: 'Blood',
    reporting_time: '12 Hours',
    is_package: false,
    package_items_text: '',
    home_collection_available: true,
  });

  // Profile Form
  const [profileForm, setProfileForm] = useState({
    name: '',
    website_name: '',
    tagline: '',
    address: '',
    city: '',
    contact_number: '',
    whatsapp_number: '',
    owner_email: '',
    logo_url: '',
    banner_url: '',
    custom_domain: '',
  });

  const loadData = useCallback(async () => {
    setError('');
    try {
      const [dash, cats, tsts, bks, pts, nts] = await Promise.all([
        apiFetch<{ lab: LabRecord; stats: typeof stats }>('/api/lab-admin/dashboard'),
        apiFetch<{ categories: TestCategory[] }>('/api/lab-admin/categories'),
        apiFetch<{ tests: DiagnosticTest[] }>('/api/lab-admin/tests'),
        apiFetch<{ bookings: BookingRecord[] }>('/api/lab-admin/bookings'),
        apiFetch<{ patients: Array<Record<string, unknown>> }>('/api/lab-admin/patients'),
        apiFetch<{ logs: NotificationLogRecord[] }>('/api/lab-admin/notifications'),
      ]);
      setLab(dash.lab);
      setStats(dash.stats);
      setCategories(cats.categories || []);
      setTests(tsts.tests || []);
      setBookings(bks.bookings || []);
      setPatients(pts.patients || []);
      setLogs(nts.logs || []);
      if (dash.lab) {
        setProfileForm({
          name: dash.lab.name,
          website_name: dash.lab.website_name,
          tagline: dash.lab.tagline || '',
          address: dash.lab.address,
          city: dash.lab.city,
          contact_number: dash.lab.contact_number,
          whatsapp_number: dash.lab.whatsapp_number,
          owner_email: dash.lab.owner_email,
          logo_url: dash.lab.logo_url || '',
          banner_url: dash.lab.banner_url || '',
          custom_domain: dash.lab.custom_domain || '',
        });
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load laboratory data');
    }
  }, []);

  useEffect(() => {
    loadData();
    const timer = setInterval(() => {
      apiFetch<{ stats: typeof stats; bookings?: BookingRecord[] }>('/api/lab-admin/dashboard')
        .then((res) => {
          setStats((prev) => {
            if (prev.totalBookings > 0 && res.stats.totalBookings > prev.totalBookings) {
              setNotice(`New patient test booking received! Total bookings: ${res.stats.totalBookings}.`);
              loadData();
            }
            return res.stats;
          });
        })
        .catch(() => {});
    }, 15000);
    return () => clearInterval(timer);
  }, [loadData]);

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      await apiFetch('/api/lab-admin/categories', {
        method: 'POST',
        body: JSON.stringify({ name: newCatName, name_hi: newCatNameHi }),
      });
      setNewCatName('');
      setNewCatNameHi('');
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to add category');
    }
  };

  const handleDeleteCategory = async (id: string) => {
    try {
      await apiFetch(`/api/lab-admin/categories/${id}`, { method: 'DELETE' });
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to delete category');
    }
  };

  const openAddTest = () => {
    setEditingTest(null);
    setTestForm({
      category_id: categories[0]?.id || '',
      name: '',
      name_hi: '',
      code: '',
      price: '',
      discounted_price: '',
      description: '',
      preparation: 'No special fasting required unless advised by physician.',
      sample_type: 'Blood',
      reporting_time: '12 Hours',
      is_package: false,
      package_items_text: '',
      home_collection_available: true,
    });
    setTestModalOpen(true);
  };

  const openEditTest = (item: DiagnosticTest) => {
    setEditingTest(item);
    setTestForm({
      category_id: item.category_id || '',
      name: item.name,
      name_hi: item.name_hi || '',
      code: item.code || '',
      price: String(item.price),
      discounted_price: item.discounted_price ? String(item.discounted_price) : '',
      description: item.description,
      preparation: item.preparation,
      sample_type: item.sample_type,
      reporting_time: item.reporting_time,
      is_package: Boolean(item.is_package),
      package_items_text: (item.package_items || []).join(', '),
      home_collection_available: Boolean(item.home_collection_available),
    });
    setTestModalOpen(true);
  };

  const handleSaveTest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = {
        category_id: testForm.category_id || null,
        name: testForm.name,
        name_hi: testForm.name_hi,
        code: testForm.code,
        price: Number(testForm.price),
        discounted_price: testForm.discounted_price ? Number(testForm.discounted_price) : null,
        description: testForm.description,
        preparation: testForm.preparation,
        sample_type: testForm.sample_type,
        reporting_time: testForm.reporting_time,
        is_package: testForm.is_package,
        package_items: testForm.is_package
          ? testForm.package_items_text
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean)
          : [],
        home_collection_available: testForm.home_collection_available,
      };
      if (editingTest) {
        await apiFetch(`/api/lab-admin/tests/${editingTest.id}`, {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
      } else {
        await apiFetch('/api/lab-admin/tests', {
          method: 'POST',
          body: JSON.stringify(payload),
        });
      }
      setTestModalOpen(false);
      setNotice(editingTest ? 'Diagnostic test updated.' : 'New diagnostic test published to your lab website.');
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save test');
    }
  };

  const handleDeleteTest = async (id: string) => {
    try {
      await apiFetch(`/api/lab-admin/tests/${id}`, { method: 'DELETE' });
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to delete test');
    }
  };

  const handleUpdateBookingStatus = async (bookingId: string, status: string) => {
    try {
      await apiFetch(`/api/lab-admin/bookings/${bookingId}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      setNotice(`Booking status updated to ${status.replace('_', ' ')}.`);
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update booking status');
    }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      setError('Logo image must be under 1 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProfileForm((prev) => ({ ...prev, logo_url: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1500 * 1024) {
      setError('Banner image must be under 1.5 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProfileForm((prev) => ({ ...prev, banner_url: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/lab-admin/profile', {
        method: 'PUT',
        body: JSON.stringify(profileForm),
      });
      setNotice('Laboratory profile and website details updated.');
      await loadData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to update profile');
    }
  };

  const filteredBookings = bookings.filter((b) => {
    if (datasetFilter === 'live' && b.is_demo === 1) return false;
    if (datasetFilter === 'demo' && b.is_demo === 0) return false;
    if (statusFilter !== 'all' && b.status !== statusFilter) return false;
    if (collectionFilter !== 'all' && b.collection_type !== collectionFilter) return false;
    return true;
  });

  const liveSiteUrl = lab ? `${window.location.origin}/lab/${lab.slug}` : '';

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col justify-between border-r border-slate-200 bg-white p-5 lg:flex dark:border-slate-800 dark:bg-slate-900">
        <div>
          <div className="border-b border-slate-200 pb-4 dark:border-slate-800">
            <div className="truncate font-display text-base font-bold text-blue-700 dark:text-blue-400">
              {lab?.website_name || 'Lab Admin'}
            </div>
            <div className="mt-0.5 truncate font-mono text-xs text-slate-500">
              {lab ? `/lab/${lab.slug}` : user.email}
            </div>
          </div>

          <nav className="mt-5 space-y-1">
            {(
              [
                ['overview', t('overview'), Activity],
                ['tests', t('testsPackages'), FlaskConical],
                ['bookings', t('bookings'), Check],
                ['patients', t('patients'), Users],
                ['profile', t('labProfile'), Settings],
                ['logs', t('deliveryLogs'), MessageCircle],
              ] as const
            ).map(([key, label, Icon]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors ${
                  tab === key
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="space-y-3 border-t border-slate-200 pt-4 dark:border-slate-800">
          <ThemeLangToolbar compact />
          {lab && (
            <button
              type="button"
              onClick={() => setQrOpen(true)}
              className="flex w-full items-center justify-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 py-2 text-xs font-semibold text-blue-700 hover:bg-blue-100 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-300"
            >
              <QrCode className="h-3.5 w-3.5" />
              <span>Share Lab QR</span>
            </button>
          )}
          <button
            type="button"
            onClick={onLogout}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>{t('signOut')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 py-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <h1 className="font-display text-lg font-bold">
              {lab?.website_name || 'Laboratory'} / <span className="capitalize">{tab}</span>
            </h1>
            {lab?.status === 'suspended' && (
              <StatusIndicator status="suspended" />
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={tab}
              onChange={(e) => setTab(e.target.value as LabTab)}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs lg:hidden dark:border-slate-700 dark:bg-slate-950"
            >
              <option value="overview">Overview</option>
              <option value="tests">Tests & Packages</option>
              <option value="bookings">Bookings</option>
              <option value="patients">Patients</option>
              <option value="profile">Profile & QR</option>
              <option value="logs">Delivery Logs</option>
            </select>
            {lab && (
              <button
                type="button"
                onClick={() => onNavigate(`/lab/${lab.slug}`)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>View Public Site</span>
              </button>
            )}
            <button
              type="button"
              onClick={openAddTest}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white hover:bg-blue-800"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{t('addTest')}</span>
            </button>
          </div>
        </header>

        <main className="flex-1 space-y-6 p-6">
          {lab?.status === 'suspended' && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-300">
              Your laboratory subscription is currently suspended. Read-only access is active; contact the platform owner to renew.
            </div>
          )}

          {error && (
            <div className="flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
              <span>{error}</span>
              <button type="button" onClick={() => setError('')}>
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
          {notice && (
            <div className="flex items-center justify-between rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-200">
              <span>{notice}</span>
              <button type="button" onClick={() => setNotice('')}>
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* OVERVIEW */}
          {tab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Bookings (Today / Week / Month)</div>
                  <div className="mt-2 font-mono text-2xl font-bold tabular-nums">
                    {stats.dailyBookings} / {stats.weeklyBookings} / {stats.monthlyBookings}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">{stats.pendingBookings} pending confirmation</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Total Test Revenue</div>
                  <div className="mt-2 font-mono text-2xl font-bold text-emerald-700 tabular-nums dark:text-emerald-400">
                    {formatCurrency(stats.totalRevenue)}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">{stats.totalBookings} total appointments</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Active Diagnostic Catalog</div>
                  <div className="mt-2 font-mono text-2xl font-bold tabular-nums">{stats.activeTests}</div>
                  <div className="mt-1 text-xs text-slate-500">{stats.packagesCount} health packages</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Lab Website & QR</div>
                  <div className="mt-2 truncate font-mono text-xs text-blue-700 dark:text-blue-400">{liveSiteUrl}</div>
                  <button
                    type="button"
                    onClick={() => setQrOpen(true)}
                    className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-slate-700 hover:underline dark:text-slate-300"
                  >
                    <QrCode className="h-3.5 w-3.5" />
                    <span>Download QR Poster</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
                  <h2 className="font-display text-sm font-semibold">Recent Patient Bookings</h2>
                  <button type="button" onClick={() => setTab('bookings')} className="text-xs font-medium text-blue-700 dark:text-blue-400">
                    Manage All
                  </button>
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Booking ID</th>
                      <th className="px-4 py-3">Patient</th>
                      <th className="px-4 py-3">Test</th>
                      <th className="px-4 py-3">Date & Slot</th>
                      <th className="px-4 py-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {bookings.slice(0, 6).map((b) => (
                      <tr key={b.id}>
                        <td className="px-4 py-3 font-mono font-semibold">{b.booking_code}</td>
                        <td className="px-4 py-3">
                          {b.patient_name} · <span className="font-mono text-slate-500">{b.patient_mobile}</span>
                        </td>
                        <td className="px-4 py-3">{b.test_name}</td>
                        <td className="px-4 py-3 font-mono tabular-nums">
                          {b.booking_date} · {b.time_slot}
                        </td>
                        <td className="px-4 py-3">
                          <StatusIndicator status={b.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TESTS & CATEGORIES */}
          {tab === 'tests' && (
            <div className="space-y-6">
              {/* Categories Manager */}
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="font-display text-sm font-semibold">Test Categories (English & Hindi)</h2>
                <form onSubmit={handleAddCategory} className="mt-3 flex flex-wrap gap-2">
                  <input
                    type="text"
                    required
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="Category name (e.g. Cardiac Markers)"
                    className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                  />
                  <input
                    type="text"
                    value={newCatNameHi}
                    onChange={(e) => setNewCatNameHi(e.target.value)}
                    placeholder="Hindi name (optional)"
                    className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                  />
                  <button type="submit" className="rounded-lg bg-slate-900 px-4 py-2 text-xs font-semibold text-white dark:bg-blue-700">
                    Add Category
                  </button>
                </form>

                <div className="mt-4 flex flex-wrap gap-2">
                  {categories.map((cat) => (
                    <div
                      key={cat.id}
                      className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs dark:border-slate-800 dark:bg-slate-950"
                    >
                      <span className="font-medium">{cat.name}</span>
                      {cat.name_hi && <span className="text-slate-500">({cat.name_hi})</span>}
                      <button type="button" onClick={() => handleDeleteCategory(cat.id)} className="text-slate-400 hover:text-red-600">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tests Table */}
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
                  <h2 className="font-display text-sm font-semibold">Diagnostic Tests & Health Packages ({tests.length})</h2>
                  <button
                    type="button"
                    onClick={() => exportTestsToExcel(tests, `${lab?.slug || 'lab'}-tests.xlsx`)}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium dark:border-slate-700"
                  >
                    <FileSpreadsheet className="h-3.5 w-3.5" />
                    <span>{t('exportExcel')}</span>
                  </button>
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Test / Package</th>
                      <th className="px-4 py-3">Category</th>
                      <th className="px-4 py-3">Sample & TAT</th>
                      <th className="px-4 py-3 text-right">Price</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {tests.map((item) => (
                      <tr key={item.id}>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-900 dark:text-white">{item.name}</div>
                          <div className="text-slate-500">
                            {item.code ? `${item.code} · ` : ''}
                            {item.is_package ? `Package (${item.package_items.length} tests)` : 'Single Test'}
                          </div>
                        </td>
                        <td className="px-4 py-3">{item.category_name || 'General'}</td>
                        <td className="px-4 py-3">
                          {item.sample_type} · {item.reporting_time}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-semibold tabular-nums">
                          {formatCurrency(item.discounted_price ?? item.price)}
                          {item.discounted_price && item.discounted_price < item.price && (
                            <div className="text-[11px] font-normal text-slate-400 line-through">{formatCurrency(item.price)}</div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex gap-1.5">
                            <button
                              type="button"
                              onClick={() => openEditTest(item)}
                              className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                            >
                              <Edit3 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteTest(item.id)}
                              className="rounded border border-red-200 p-1.5 text-red-700 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* BOOKINGS MANAGEMENT */}
          {tab === 'bookings' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900">
                    {(['all', 'live', 'demo'] as const).map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setDatasetFilter(f)}
                        className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize ${
                          datasetFilter === f ? 'bg-blue-700 text-white' : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {f === 'all' ? 'All' : f === 'live' ? 'Live Patients' : 'Demo Sample'}
                      </button>
                    ))}
                  </div>
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-900"
                  >
                    <option value="all">All Statuses</option>
                    <option value="pending">Pending</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="sample_collected">Sample Collected</option>
                    <option value="report_ready">Report Ready</option>
                    <option value="completed">Completed</option>
                    <option value="cancelled">Cancelled</option>
                    <option value="rejected">Rejected</option>
                  </select>
                  <select
                    value={collectionFilter}
                    onChange={(e) => setCollectionFilter(e.target.value as 'all' | 'home_collection' | 'lab_visit')}
                    className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-900"
                  >
                    <option value="all">All Collection Modes</option>
                    <option value="home_collection">Home Sample Collection</option>
                    <option value="lab_visit">Lab Visit Only</option>
                  </select>
                </div>

                <button
                  type="button"
                  onClick={() => exportBookingsToExcel(filteredBookings, `${lab?.slug || 'lab'}-bookings.xlsx`)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  <span>{t('exportExcel')}</span>
                </button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Booking ID</th>
                      <th className="px-4 py-3">Patient</th>
                      <th className="px-4 py-3">Test & Collection</th>
                      <th className="px-4 py-3">Schedule</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3 text-right">Workflow & Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredBookings.map((b) => (
                      <tr key={b.id}>
                        <td className="px-4 py-3 font-mono font-semibold">
                          {b.booking_code}
                          <div className="text-[11px] font-normal text-slate-500">
                            {b.is_demo ? 'Demo Sample' : 'Live Patient'}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium">
                            {b.patient_name} ({b.patient_age}y, {b.patient_gender})
                          </div>
                          <div className="font-mono text-slate-500">{b.patient_mobile}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-medium">{b.test_name}</div>
                          <div className="text-slate-500">
                            {b.collection_type === 'home_collection' ? `Home: ${b.collection_address}` : 'Lab Visit'}
                          </div>
                        </td>
                        <td className="px-4 py-3 font-mono tabular-nums">
                          {b.booking_date}
                          <div className="text-slate-500">{b.time_slot}</div>
                        </td>
                        <td className="px-4 py-3">
                          <StatusIndicator status={b.status} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex items-center gap-1.5">
                            <select
                              value={b.status}
                              onChange={(e) => handleUpdateBookingStatus(b.id, e.target.value)}
                              className="rounded border border-slate-300 bg-white px-2 py-1 text-xs dark:border-slate-700 dark:bg-slate-950"
                            >
                              <option value="pending">Pending</option>
                              <option value="confirmed">Accept / Confirm</option>
                              <option value="sample_collected">Sample Collected</option>
                              <option value="report_ready">Report Ready</option>
                              <option value="completed">Completed</option>
                              <option value="rejected">Reject</option>
                              <option value="cancelled">Cancel</option>
                            </select>
                            <button
                              type="button"
                              onClick={() =>
                                downloadBookingReceiptPdf(b, {
                                  name: lab?.website_name || 'Diagnostic Lab',
                                  address: lab?.address || '',
                                  contact: lab?.contact_number || '',
                                })
                              }
                              title="Download PDF Receipt"
                              className="rounded border border-slate-300 p-1.5 hover:bg-slate-50 dark:border-slate-700"
                            >
                              <Download className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PATIENTS RECORDS */}
          {tab === 'patients' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-base font-semibold">Laboratory Patient Records ({patients.length})</h2>
                <button
                  type="button"
                  onClick={() => exportPatientsToExcel(patients, `${lab?.slug || 'lab'}-patients.xlsx`)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold dark:border-slate-700 dark:bg-slate-900"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  <span>{t('exportExcel')}</span>
                </button>
              </div>
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Patient Name</th>
                      <th className="px-4 py-3">Mobile & Email</th>
                      <th className="px-4 py-3">Age / Gender</th>
                      <th className="px-4 py-3 text-right">Visits</th>
                      <th className="px-4 py-3 text-right">Total Billed</th>
                      <th className="px-4 py-3">Last Visit</th>
                      <th className="px-4 py-3 text-right">History</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {patients.map((p, idx) => (
                      <tr key={idx}>
                        <td className="px-4 py-3 font-medium">
                          {String(p.patient_name)}
                          <div className="text-[11px] text-slate-500">{p.is_demo ? 'Demo Sample' : 'Live Patient'}</div>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-mono">{String(p.patient_mobile)}</div>
                          <div className="text-slate-500">{String(p.patient_email || '—')}</div>
                        </td>
                        <td className="px-4 py-3">
                          {String(p.patient_age)} yrs · {String(p.patient_gender)}
                        </td>
                        <td className="px-4 py-3 text-right font-mono tabular-nums">{String(p.total_bookings)}</td>
                        <td className="px-4 py-3 text-right font-mono font-semibold tabular-nums">
                          {formatCurrency(Number(p.total_spent || 0))}
                        </td>
                        <td className="px-4 py-3 font-mono tabular-nums">{String(p.last_visit)}</td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => setSelectedPatientMobile(String(p.patient_mobile))}
                            className="rounded border border-slate-300 px-2.5 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700"
                          >
                            View History
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* PROFILE & LOGO */}
          {tab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="grid grid-cols-1 gap-6 lg:grid-cols-12">
              <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-8 dark:border-slate-800 dark:bg-slate-900">
                <h2 className="font-display text-base font-semibold">Laboratory Website & Contact Settings</h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">Official Laboratory Name</label>
                    <input
                      type="text"
                      required
                      value={profileForm.name}
                      onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">Website Brand Title</label>
                    <input
                      type="text"
                      required
                      value={profileForm.website_name}
                      onChange={(e) => setProfileForm({ ...profileForm, website_name: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs text-slate-500">Public Tagline</label>
                    <input
                      type="text"
                      value={profileForm.tagline}
                      onChange={(e) => setProfileForm({ ...profileForm, tagline: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">WhatsApp Business Number</label>
                    <input
                      type="tel"
                      required
                      value={profileForm.whatsapp_number}
                      onChange={(e) => setProfileForm({ ...profileForm, whatsapp_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">Owner Alert Email</label>
                    <input
                      type="email"
                      required
                      value={profileForm.owner_email}
                      onChange={(e) => setProfileForm({ ...profileForm, owner_email: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">Reception Contact Number</label>
                    <input
                      type="tel"
                      required
                      value={profileForm.contact_number}
                      onChange={(e) => setProfileForm({ ...profileForm, contact_number: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-slate-500">City</label>
                    <input
                      type="text"
                      required
                      value={profileForm.city}
                      onChange={(e) => setProfileForm({ ...profileForm, city: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs text-slate-500">Full Clinic Address</label>
                    <input
                      type="text"
                      required
                      value={profileForm.address}
                      onChange={(e) => setProfileForm({ ...profileForm, address: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="mb-1 block text-xs text-slate-500">Custom Domain (Future DNS Mapping)</label>
                    <input
                      type="text"
                      value={profileForm.custom_domain}
                      onChange={(e) => setProfileForm({ ...profileForm, custom_domain: e.target.value })}
                      placeholder="diagnostics.yourlab.in"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                </div>
                <div className="pt-2">
                  <button type="submit" className="rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800">
                    Save Laboratory Profile
                  </button>
                </div>
              </div>

              <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-4 dark:border-slate-800 dark:bg-slate-900">
                <h3 className="font-display text-sm font-semibold">Laboratory Logo Upload</h3>
                <div className="flex h-32 items-center justify-center rounded-lg border border-dashed border-slate-300 bg-slate-50 dark:border-slate-700 dark:bg-slate-950">
                  {profileForm.logo_url ? (
                    <img src={profileForm.logo_url} alt="Lab logo" className="max-h-24 max-w-full rounded object-contain" />
                  ) : (
                    <span className="text-xs text-slate-400">No logo uploaded</span>
                  )}
                </div>
                <input type="file" accept="image/*" onChange={handleLogoUpload} className="w-full text-xs" />

                <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
                  <h3 className="font-display text-sm font-semibold">Laboratory Website Banner</h3>
                  <div className="mt-2 flex h-24 items-center justify-center overflow-hidden rounded-lg border border-dashed border-slate-300 bg-slate-50 dark:border-slate-700 dark:bg-slate-950">
                    {profileForm.banner_url ? (
                      <img src={profileForm.banner_url} alt="Lab banner" className="h-full w-full object-cover" />
                    ) : (
                      <span className="text-xs text-slate-400">Default clinical image</span>
                    )}
                  </div>
                  <input type="file" accept="image/*" onChange={handleBannerUpload} className="mt-2 w-full text-xs" />
                </div>

                <div className="border-t border-slate-200 pt-4 dark:border-slate-800">
                  <div className="text-xs text-slate-500">Your Independent Public URL</div>
                  <div className="mt-1 truncate font-mono text-xs text-blue-700 dark:text-blue-400">{liveSiteUrl}</div>
                  <button
                    type="button"
                    onClick={() => setQrOpen(true)}
                    className="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-slate-300 py-2 text-xs font-semibold dark:border-slate-700"
                  >
                    <QrCode className="h-4 w-4" />
                    <span>Open QR Code Poster</span>
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* DELIVERY LOGS */}
          {tab === 'logs' && (
            <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
              <div className="border-b border-slate-200 px-5 py-3.5 text-sm font-semibold dark:border-slate-800">
                Email & WhatsApp Delivery Logs (This Lab Only)
              </div>
              <table className="w-full text-left text-xs">
                <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                  <tr>
                    <th className="px-4 py-3">Time</th>
                    <th className="px-4 py-3">Channel & Event</th>
                    <th className="px-4 py-3">Recipient</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {logs.map((l) => (
                    <tr key={l.id}>
                      <td className="px-4 py-3 font-mono tabular-nums">{new Date(l.created_at).toLocaleString()}</td>
                      <td className="px-4 py-3">
                        <span className="font-semibold uppercase">{l.channel}</span> · {l.event_type}
                      </td>
                      <td className="px-4 py-3 font-mono">{l.recipient}</td>
                      <td className="px-4 py-3">
                        <StatusIndicator status={l.status} />
                      </td>
                      <td className="px-4 py-3 text-slate-500">{l.error_message || l.provider_response || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </main>
      </div>

      {/* Add / Edit Test Modal */}
      {testModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="my-8 w-full max-w-xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <h3 className="font-display text-lg font-bold">{editingTest ? 'Edit Diagnostic Test' : 'Add New Diagnostic Test'}</h3>
              <button type="button" onClick={() => setTestModalOpen(false)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handleSaveTest} className="mt-4 space-y-3 text-sm">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Test Name (English) *</label>
                  <input
                    type="text"
                    required
                    value={testForm.name}
                    onChange={(e) => setTestForm({ ...testForm, name: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Test Name (Hindi Optional)</label>
                  <input
                    type="text"
                    value={testForm.name_hi}
                    onChange={(e) => setTestForm({ ...testForm, name_hi: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Category</label>
                  <select
                    value={testForm.category_id}
                    onChange={(e) => setTestForm({ ...testForm, category_id: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  >
                    <option value="">Uncategorized</option>
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Test Code</label>
                  <input
                    type="text"
                    value={testForm.code}
                    onChange={(e) => setTestForm({ ...testForm, code: e.target.value })}
                    placeholder="e.g. LFT-202"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">MRP Price (INR) *</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={testForm.price}
                    onChange={(e) => setTestForm({ ...testForm, price: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Discounted Offer Price (INR)</label>
                  <input
                    type="number"
                    min={0}
                    value={testForm.discounted_price}
                    onChange={(e) => setTestForm({ ...testForm, discounted_price: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Sample Type</label>
                  <select
                    value={testForm.sample_type}
                    onChange={(e) => setTestForm({ ...testForm, sample_type: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  >
                    <option value="Blood">Blood</option>
                    <option value="Urine">Urine</option>
                    <option value="Swab">Swab</option>
                    <option value="Saliva">Saliva</option>
                    <option value="Stool">Stool</option>
                    <option value="Imaging">Imaging</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Reporting Time</label>
                  <input
                    type="text"
                    value={testForm.reporting_time}
                    onChange={(e) => setTestForm({ ...testForm, reporting_time: e.target.value })}
                    placeholder="e.g. 6 Hours"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1 block text-xs text-slate-500">Description *</label>
                <textarea
                  rows={2}
                  required
                  value={testForm.description}
                  onChange={(e) => setTestForm({ ...testForm, description: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-slate-500">Preparation Instructions *</label>
                <textarea
                  rows={2}
                  required
                  value={testForm.preparation}
                  onChange={(e) => setTestForm({ ...testForm, preparation: e.target.value })}
                  className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-950"
                />
              </div>

              <div className="flex flex-wrap gap-4 pt-1 text-xs">
                <label className="inline-flex items-center gap-1.5">
                  <input
                    type="checkbox"
                    checked={testForm.home_collection_available}
                    onChange={(e) => setTestForm({ ...testForm, home_collection_available: e.target.checked })}
                  />
                  <span>Home Sample Collection Available</span>
                </label>
                <label className="inline-flex items-center gap-1.5">
                  <input
                    type="checkbox"
                    checked={testForm.is_package}
                    onChange={(e) => setTestForm({ ...testForm, is_package: e.target.checked })}
                  />
                  <span>This is a Multi-Test Health Package</span>
                </label>
              </div>

              {testForm.is_package && (
                <div>
                  <label className="mb-1 block text-xs text-slate-500">Included Tests (comma separated)</label>
                  <input
                    type="text"
                    value={testForm.package_items_text}
                    onChange={(e) => setTestForm({ ...testForm, package_items_text: e.target.value })}
                    placeholder="CBC, Liver Function, Kidney Function, Thyroid"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
              )}

              <div className="flex justify-end gap-2 border-t border-slate-200 pt-4 dark:border-slate-800">
                <button type="button" onClick={() => setTestModalOpen(false)} className="rounded-lg border border-slate-300 px-4 py-2 text-xs dark:border-slate-700">
                  Cancel
                </button>
                <button type="submit" className="rounded-lg bg-blue-700 px-5 py-2 text-xs font-semibold text-white">
                  {editingTest ? 'Save Changes' : 'Publish Test'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Patient Booking History Modal */}
      {selectedPatientMobile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <div>
                <h3 className="font-display text-base font-bold">Patient Booking History</h3>
                <p className="font-mono text-xs text-slate-500">{selectedPatientMobile}</p>
              </div>
              <button type="button" onClick={() => setSelectedPatientMobile(null)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-4 max-h-96 space-y-2 overflow-y-auto">
              {bookings
                .filter((b) => b.patient_mobile === selectedPatientMobile)
                .map((b) => (
                  <div key={b.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 p-3 text-xs dark:border-slate-800">
                    <div>
                      <div className="font-mono font-semibold">{b.booking_code} · {b.test_name}</div>
                      <div className="text-slate-500">{b.booking_date} · {b.time_slot} · {formatCurrency(b.price)}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <StatusIndicator status={b.status} />
                      <button
                        type="button"
                        onClick={() =>
                          downloadBookingReceiptPdf(b, {
                            name: lab?.website_name || 'Diagnostic Lab',
                            address: lab?.address || '',
                            contact: lab?.contact_number || '',
                          })
                        }
                        className="rounded border border-slate-300 px-2 py-1 text-xs dark:border-slate-700"
                      >
                        PDF
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      <QrCodeModal
        open={qrOpen}
        onClose={() => setQrOpen(false)}
        labName={lab?.website_name || ''}
        url={liveSiteUrl}
        customDomain={lab?.custom_domain}
      />
    </div>
  );
};
