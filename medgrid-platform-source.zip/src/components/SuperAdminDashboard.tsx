import React, { useCallback, useEffect, useState } from 'react';
import {
  Activity,
  Ban,
  Building2,
  CheckCircle2,
  CreditCard,
  DatabaseBackup,
  Download,
  Edit3,
  ExternalLink,
  FileSpreadsheet,
  FileText,
  KeyRound,
  LogOut,
  Mail,
  MessageCircle,
  PauseCircle,
  Plus,
  QrCode,
  RefreshCw,
  Send,
  ShieldAlert,
  Trash2,
  X,
} from 'lucide-react';
import {
  apiFetch,
  formatCurrency,
  type AuditLogRecord,
  type BookingRecord,
  type LabPaymentRecord,
  type LabRecord,
  type NotificationLogRecord,
  type UserProfile,
} from '../lib/api';
import { PLATFORM_IMAGES } from '../lib/assets';
import { downloadLabInvoicePdf, exportBookingsToExcel, exportSalesToExcel } from '../lib/exports';
import { useAppSettings } from '../lib/i18n';
import { QrCodeModal } from './QrCodeModal';
import { StatusIndicator } from './StatusBadge';
import { ThemeLangToolbar } from './ThemeLangToolbar';

interface SuperAdminDashboardProps {
  user: UserProfile;
  onLogout: () => void;
  onNavigate: (path: string) => void;
}

type TabKey = 'overview' | 'labs' | 'bookings' | 'sales' | 'notifications' | 'audit';

const ALL_PERMISSIONS = [
  { id: 'manage_tests', label: 'Manage Tests & Prices' },
  { id: 'manage_packages', label: 'Manage Packages' },
  { id: 'manage_bookings', label: 'Accept / Reject Bookings' },
  { id: 'manage_profile', label: 'Edit Lab Profile & Logo' },
  { id: 'export_reports', label: 'Export PDF & Excel' },
];

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({ user, onLogout, onNavigate }) => {
  const { t } = useAppSettings();
  const [tab, setTab] = useState<TabKey>('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [bannerMsg, setBannerMsg] = useState('');

  // Data
  const [metrics, setMetrics] = useState({
    totalLabsSold: 0,
    activeLabs: 0,
    suspendedLabs: 0,
    totalRevenue: 0,
    pendingPayments: 0,
    totalContractValue: 0,
    totalBookings: 0,
    liveBookings: 0,
    demoBookings: 0,
  });
  const [monthlyRevenue, setMonthlyRevenue] = useState<Array<{ month: string; revenue: number }>>([]);
  const [labs, setLabs] = useState<LabRecord[]>([]);
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [payments, setPayments] = useState<LabPaymentRecord[]>([]);
  const [notifLogs, setNotifLogs] = useState<NotificationLogRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);

  // Filters
  const [datasetFilter, setDatasetFilter] = useState<'all' | 'live' | 'demo'>('all');
  const [labSearch, setLabSearch] = useState('');

  // Create / Edit Lab Modal
  const [createOpen, setCreateOpen] = useState(false);
  const [editingLab, setEditingLab] = useState<LabRecord | null>(null);
  const [labForm, setLabForm] = useState({
    name: '',
    website_name: '',
    slug: '',
    custom_domain: '',
    address: '',
    city: '',
    contact_number: '',
    whatsapp_number: '',
    owner_name: '',
    owner_email: '',
    logo_url: '',
    tagline: '',
    subscription_plan: 'Growth Annual',
    selling_price: '24000',
    amount_paid: '24000',
    subscription_expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
    auto_suspend_on_expiry: true,
    permissions: ALL_PERMISSIONS.map((p) => p.id),
  });
  const [savingLab, setSavingLab] = useState(false);
  const [createdProvisionInfo, setCreatedProvisionInfo] = useState<{
    lab: LabRecord;
    credentials: { email: string; tempPassword: string; inviteLink: string; labUrl: string };
    notifications: Record<string, { status: string; error?: string; providerResponse?: string }>;
  } | null>(null);

  // Payment Modal
  const [paymentLab, setPaymentLab] = useState<LabRecord | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payType, setPayType] = useState<'partial_payment' | 'subscription_renewal'>('partial_payment');
  const [payMethod, setPayMethod] = useState('UPI / Bank Transfer');
  const [extendMonths, setExtendMonths] = useState('0');
  const [payNotes, setPayNotes] = useState('');

  // QR Modal
  const [qrLab, setQrLab] = useState<LabRecord | null>(null);

  // Notification Provider Settings
  const [smtpForm, setSmtpForm] = useState({
    host: '',
    port: 587,
    secure: false,
    user: '',
    pass: '',
    pass_masked: '',
    from_name: 'MedGrid Diagnostics',
    from_email: '',
  });
  const [waForm, setWaForm] = useState({
    provider: 'meta_cloud_api' as 'meta_cloud_api' | 'twilio',
    phone_number_id: '',
    access_token: '',
    access_token_masked: '',
    business_account_id: '',
    api_version: 'v21.0',
    twilio_sid: '',
    twilio_token: '',
    twilio_token_masked: '',
    twilio_from: '',
  });
  const [templatesForm, setTemplatesForm] = useState<Record<string, string>>({});
  const [testEmailAddr, setTestEmailAddr] = useState('');
  const [testWaPhone, setTestWaPhone] = useState('');
  const [providerTestResult, setProviderTestResult] = useState('');

  const loadAllData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const [ov, lb, bk, py, nt, au, st] = await Promise.all([
        apiFetch<{ metrics: typeof metrics; monthlyRevenue: Array<{ month: string; revenue: number }> }>('/api/super-admin/overview'),
        apiFetch<{ labs: LabRecord[] }>('/api/super-admin/labs'),
        apiFetch<{ bookings: BookingRecord[] }>('/api/super-admin/bookings'),
        apiFetch<{ payments: LabPaymentRecord[] }>('/api/super-admin/payments'),
        apiFetch<{ logs: NotificationLogRecord[] }>('/api/super-admin/notifications'),
        apiFetch<{ logs: AuditLogRecord[] }>('/api/super-admin/audit-logs'),
        apiFetch<{ smtp: typeof smtpForm; whatsapp: typeof waForm; templates: Record<string, string> }>('/api/super-admin/settings'),
      ]);
      setMetrics(ov.metrics);
      setMonthlyRevenue(ov.monthlyRevenue || []);
      setLabs(lb.labs || []);
      setBookings(bk.bookings || []);
      setPayments(py.payments || []);
      setNotifLogs(nt.logs || []);
      setAuditLogs(au.logs || []);
      setSmtpForm({ ...st.smtp, pass: '' });
      setWaForm({ ...st.whatsapp, access_token: '', twilio_token: '' });
      setTemplatesForm(st.templates || {});
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
    const timer = setInterval(() => {
      apiFetch<{ metrics: typeof metrics }>('/api/super-admin/overview')
        .then((res) => {
          setMetrics((prev) => {
            if (prev.totalBookings > 0 && res.metrics.totalBookings > prev.totalBookings) {
              setBannerMsg(`New patient booking received across platform (${res.metrics.totalBookings} total).`);
            }
            return res.metrics;
          });
        })
        .catch(() => {});
    }, 20000);
    return () => clearInterval(timer);
  }, [loadAllData]);

  const handleLabLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) {
      setError('Logo image must be under 1 MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setLabForm((prev) => ({ ...prev, logo_url: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const openCreateModal = () => {
    setEditingLab(null);
    setLabForm({
      name: '',
      website_name: '',
      slug: '',
      custom_domain: '',
      address: '',
      city: '',
      contact_number: '',
      whatsapp_number: '',
      owner_name: '',
      owner_email: '',
      logo_url: '',
      tagline: '',
      subscription_plan: 'Growth Annual',
      selling_price: '24000',
      amount_paid: '24000',
      subscription_expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
      auto_suspend_on_expiry: true,
      permissions: ALL_PERMISSIONS.map((p) => p.id),
    });
    setCreateOpen(true);
  };

  const openEditModal = (lab: LabRecord) => {
    setEditingLab(lab);
    setLabForm({
      name: lab.name,
      website_name: lab.website_name,
      slug: lab.slug,
      custom_domain: lab.custom_domain || '',
      address: lab.address,
      city: lab.city,
      contact_number: lab.contact_number,
      whatsapp_number: lab.whatsapp_number,
      owner_name: lab.owner_name,
      owner_email: lab.owner_email,
      logo_url: lab.logo_url || '',
      tagline: lab.tagline || '',
      subscription_plan: lab.subscription_plan,
      selling_price: String(lab.selling_price),
      amount_paid: String(lab.amount_paid),
      subscription_expiry: lab.subscription_expiry,
      auto_suspend_on_expiry: Boolean(lab.auto_suspend_on_expiry),
      permissions: lab.permissions || ALL_PERMISSIONS.map((p) => p.id),
    });
    setCreateOpen(true);
  };

  const handleSaveLab = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingLab(true);
    setError('');
    try {
      if (editingLab) {
        await apiFetch(`/api/super-admin/labs/${editingLab.id}`, {
          method: 'PATCH',
          body: JSON.stringify({
            ...labForm,
            selling_price: Number(labForm.selling_price),
          }),
        });
        setCreateOpen(false);
        setBannerMsg(`Updated ${labForm.website_name || labForm.name} successfully.`);
      } else {
        const res = await apiFetch<{
          lab: LabRecord;
          credentials: { email: string; tempPassword: string; inviteLink: string; labUrl: string };
          notifications: Record<string, { status: string; error?: string; providerResponse?: string }>;
        }>('/api/super-admin/labs', {
          method: 'POST',
          body: JSON.stringify({
            ...labForm,
            selling_price: Number(labForm.selling_price),
            amount_paid: Number(labForm.amount_paid),
          }),
        });
        setCreateOpen(false);
        setCreatedProvisionInfo(res);
      }
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save laboratory');
    } finally {
      setSavingLab(false);
    }
  };

  const handleStatusChange = async (lab: LabRecord, status: 'active' | 'suspended' | 'deactivated') => {
    try {
      await apiFetch(`/api/super-admin/labs/${lab.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      setBannerMsg(`${lab.website_name} is now ${status}.`);
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Status update failed');
    }
  };

  const handleDeleteLab = async (lab: LabRecord) => {
    try {
      await apiFetch(`/api/super-admin/labs/${lab.id}`, { method: 'DELETE' });
      setBannerMsg(`Deleted ${lab.website_name}.`);
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Delete failed');
    }
  };

  const handleResendInvite = async (lab: LabRecord) => {
    try {
      const res = await apiFetch<{
        inviteLink: string;
        notifications: { email: { status: string; error?: string }; whatsapp: { status: string; error?: string } };
      }>(`/api/super-admin/labs/${lab.id}/resend-invite`, { method: 'POST' });
      setBannerMsg(
        `New invite generated (${res.inviteLink}). Email: ${res.notifications.email.status} · WhatsApp: ${res.notifications.whatsapp.status}`
      );
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to resend invite');
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentLab) return;
    try {
      const res = await apiFetch<{ invoiceNumber: string }>(`/api/super-admin/labs/${paymentLab.id}/payments`, {
        method: 'POST',
        body: JSON.stringify({
          amount: Number(payAmount),
          payment_type: payType,
          payment_method: payMethod,
          extend_months: Number(extendMonths),
          notes: payNotes,
        }),
      });
      setPaymentLab(null);
      setPayAmount('');
      setPayNotes('');
      setBannerMsg(`Payment recorded (${res.invoiceNumber}).`);
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Payment recording failed');
    }
  };

  const handleEnforceSubscriptions = async () => {
    try {
      const res = await apiFetch<{ suspendedCount: number }>('/api/super-admin/enforce-subscriptions', { method: 'POST' });
      setBannerMsg(`Subscription check complete: ${res.suspendedCount} expired lab(s) suspended.`);
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Enforcement failed');
    }
  };

  const handleSendRenewalReminder = async (lab: LabRecord) => {
    try {
      const res = await apiFetch<{
        notifications: { email: { status: string; error?: string }; whatsapp: { status: string; error?: string } };
      }>(`/api/super-admin/labs/${lab.id}/send-renewal-reminder`, { method: 'POST' });
      setBannerMsg(
        `Renewal reminder dispatched for ${lab.website_name}. Email: ${res.notifications.email.status} · WhatsApp: ${res.notifications.whatsapp.status}`
      );
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Reminder failed');
    }
  };

  const handleSaveProviderSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setProviderTestResult('');
    try {
      await apiFetch('/api/super-admin/settings', {
        method: 'PUT',
        body: JSON.stringify({
          smtp: smtpForm,
          whatsapp: waForm,
          templates: templatesForm,
        }),
      });
      setBannerMsg('Provider credentials and notification templates saved securely.');
      await loadAllData();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to save settings');
    }
  };

  const handleVerifySmtp = async () => {
    setProviderTestResult('Testing SMTP connection...');
    try {
      const res = await apiFetch<{ ok: boolean; message: string }>('/api/super-admin/settings/verify-smtp', { method: 'POST' });
      setProviderTestResult(res.ok ? `SMTP Verified: ${res.message}` : `SMTP Error: ${res.message}`);
    } catch (err: unknown) {
      setProviderTestResult(err instanceof Error ? err.message : 'Verify failed');
    }
  };

  const handleSendTest = async (channel: 'email' | 'whatsapp') => {
    const recipient = channel === 'email' ? testEmailAddr : testWaPhone;
    if (!recipient.trim()) return;
    setProviderTestResult(`Sending test ${channel}...`);
    try {
      const res = await apiFetch<{ status: string; error?: string; providerResponse?: string }>(
        '/api/super-admin/settings/test-notification',
        {
          method: 'POST',
          body: JSON.stringify({ channel, recipient }),
        }
      );
      setProviderTestResult(
        res.status === 'sent'
          ? `Delivered (${res.providerResponse || 'OK'})`
          : `${res.status.toUpperCase()}: ${res.error || 'Failed'}`
      );
      await loadAllData();
    } catch (err: unknown) {
      setProviderTestResult(err instanceof Error ? err.message : 'Test failed');
    }
  };

  const filteredLabs = labs.filter((l) => {
    if (datasetFilter === 'live' && l.is_demo === 1) return false;
    if (datasetFilter === 'demo' && l.is_demo === 0) return false;
    if (labSearch.trim()) {
      const q = labSearch.toLowerCase();
      return (
        l.name.toLowerCase().includes(q) ||
        l.website_name.toLowerCase().includes(q) ||
        l.owner_email.toLowerCase().includes(q) ||
        l.slug.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const filteredBookings = bookings.filter((b) => {
    if (datasetFilter === 'live' && b.is_demo === 1) return false;
    if (datasetFilter === 'demo' && b.is_demo === 0) return false;
    return true;
  });

  const maxMonthlyRev = Math.max(1, ...monthlyRevenue.map((m) => m.revenue));

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col justify-between border-r border-slate-200 bg-white p-5 lg:flex dark:border-slate-800 dark:bg-slate-900">
        <div>
          <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
            <button type="button" onClick={() => onNavigate('/')} className="font-display text-lg font-bold text-blue-700 dark:text-blue-400">
              MedGrid SaaS
            </button>
            <span className="text-xs font-medium text-slate-500">Super Admin</span>
          </div>

          <nav className="mt-5 space-y-1">
            {(
              [
                ['overview', t('overview'), Activity],
                ['labs', t('laboratories'), Building2],
                ['bookings', t('bookings'), FileText],
                ['sales', t('salesInvoices'), CreditCard],
                ['notifications', t('notificationsApi'), MessageCircle],
                ['audit', t('auditBackups'), DatabaseBackup],
              ] as const
            ).map(([key, label, Icon]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`flex w-full items-center gap-2.5 rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors ${
                  tab === key
                    ? 'bg-blue-700 text-white'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span className="truncate">{label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="space-y-4 border-t border-slate-200 pt-4 dark:border-slate-800">
          <ThemeLangToolbar compact />
          <div className="flex items-center gap-3">
            <img
              src={PLATFORM_IMAGES.avatarSuperAdmin}
              alt={user.name}
              referrerPolicy="no-referrer"
              className="h-9 w-9 rounded-lg object-cover"
            />
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-semibold text-slate-900 dark:text-white">{user.name}</div>
              <div className="truncate text-xs text-slate-500">{user.email}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>{t('signOut')}</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 bg-white px-6 py-4 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <h1 className="font-display text-lg font-bold text-slate-900 dark:text-white">
              Super Admin / <span className="capitalize">{tab}</span>
            </h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* Mobile tab switcher */}
            <select
              value={tab}
              onChange={(e) => setTab(e.target.value as TabKey)}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs lg:hidden dark:border-slate-700 dark:bg-slate-950"
            >
              <option value="overview">Overview</option>
              <option value="labs">Laboratories</option>
              <option value="bookings">Bookings</option>
              <option value="sales">Sales & Invoices</option>
              <option value="notifications">Notifications & API</option>
              <option value="audit">Audit & Backups</option>
            </select>
            <button
              type="button"
              onClick={openCreateModal}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-700 px-3.5 py-2 text-xs font-semibold text-white whitespace-nowrap hover:bg-blue-800"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>{t('createLab')}</span>
            </button>
          </div>
        </header>

        <main className="flex-1 space-y-6 p-6">
          {error && (
            <div className="flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
              <span>{error}</span>
              <button type="button" onClick={() => setError('')}>
                <X className="h-4 w-4" />
              </button>
            </div>
          )}
          {bannerMsg && (
            <div className="flex items-center justify-between rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-800 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-200">
              <span>{bannerMsg}</span>
              <button type="button" onClick={() => setBannerMsg('')}>
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* OVERVIEW TAB */}
          {tab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Total Labs Sold</div>
                  <div className="mt-2 font-mono text-3xl font-bold tabular-nums">{metrics.totalLabsSold}</div>
                  <div className="mt-1 text-xs text-slate-500">
                    {metrics.activeLabs} active · {metrics.suspendedLabs} suspended
                  </div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Collected Revenue</div>
                  <div className="mt-2 font-mono text-3xl font-bold text-emerald-700 tabular-nums dark:text-emerald-400">
                    {formatCurrency(metrics.totalRevenue)}
                  </div>
                  <div className="mt-1 font-mono text-xs text-slate-500 tabular-nums">
                    Contract value: {formatCurrency(metrics.totalContractValue)}
                  </div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Pending Payments</div>
                  <div className="mt-2 font-mono text-3xl font-bold text-amber-700 tabular-nums dark:text-amber-400">
                    {formatCurrency(metrics.pendingPayments)}
                  </div>
                  <div className="mt-1 text-xs text-slate-500">Receivable across active plans</div>
                </div>
                <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                  <div className="text-xs font-medium text-slate-500">Platform Patient Bookings</div>
                  <div className="mt-2 font-mono text-3xl font-bold tabular-nums">{metrics.totalBookings}</div>
                  <div className="mt-1 text-xs text-slate-500">
                    {metrics.liveBookings} live · {metrics.demoBookings} demo sample
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
                <div className="rounded-xl border border-slate-200 bg-white p-6 lg:col-span-6 dark:border-slate-800 dark:bg-slate-900">
                  <h2 className="font-display text-base font-semibold">Monthly SaaS Revenue</h2>
                  <p className="mt-1 text-xs text-slate-500">Recorded website sales and subscription renewals</p>
                  <div className="mt-6 space-y-3">
                    {monthlyRevenue.length === 0 ? (
                      <p className="text-sm text-slate-500">No payments recorded yet.</p>
                    ) : (
                      monthlyRevenue.map((item) => (
                        <div key={item.month} className="space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-mono text-slate-600 dark:text-slate-400">{item.month}</span>
                            <span className="font-mono font-semibold tabular-nums">{formatCurrency(item.revenue)}</span>
                          </div>
                          <div className="h-2.5 w-full overflow-hidden rounded bg-slate-100 dark:bg-slate-800">
                            <div
                              className="h-full rounded bg-blue-700 dark:bg-blue-500"
                              style={{ width: `${Math.max(6, (item.revenue / maxMonthlyRev) * 100)}%` }}
                            />
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                <div className="rounded-xl border border-slate-200 bg-white p-6 lg:col-span-6 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-base font-semibold">Recent Notification Delivery</h2>
                    <button
                      type="button"
                      onClick={() => setTab('notifications')}
                      className="text-xs font-medium text-blue-700 hover:underline dark:text-blue-400"
                    >
                      Configure Providers
                    </button>
                  </div>
                  <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                    {notifLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="flex items-center justify-between gap-3 py-2.5 text-xs">
                        <div className="min-w-0">
                          <div className="truncate font-medium text-slate-900 dark:text-slate-100">
                            {log.channel.toUpperCase()} · {log.recipient}
                          </div>
                          <div className="truncate text-slate-500">{log.error_message || log.provider_response || log.event_type}</div>
                        </div>
                        <StatusIndicator status={log.status} />
                      </div>
                    ))}
                    {notifLogs.length === 0 && (
                      <p className="py-6 text-sm text-slate-500">No emails or WhatsApp messages dispatched yet.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* LABORATORIES TAB */}
          {tab === 'labs' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900">
                  {(['all', 'live', 'demo'] as const).map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setDatasetFilter(f)}
                      className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize ${
                        datasetFilter === f
                          ? 'bg-blue-700 text-white'
                          : 'text-slate-600 hover:text-slate-900 dark:text-slate-400'
                      }`}
                    >
                      {f === 'all' ? 'All Labs' : f === 'live' ? 'Live Sold Labs' : 'Demo Sample'}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={labSearch}
                  onChange={(e) => setLabSearch(e.target.value)}
                  placeholder="Filter by lab name, email, or slug..."
                  className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm sm:w-72 dark:border-slate-700 dark:bg-slate-900"
                />
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Laboratory & URL</th>
                      <th className="px-4 py-3">Owner Contact</th>
                      <th className="px-4 py-3">Plan & Expiry</th>
                      <th className="px-4 py-3 text-right">Paid / Pending</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredLabs.map((lab) => {
                      const labUrl = `${window.location.origin}/lab/${lab.slug}`;
                      return (
                        <tr key={lab.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                          <td className="px-4 py-3.5">
                            <div className="font-semibold text-slate-900 dark:text-white">{lab.website_name}</div>
                            <div className="mt-0.5 flex items-center gap-2 text-xs text-slate-500">
                              <a href={`/lab/${lab.slug}`} target="_blank" rel="noreferrer" className="font-mono text-blue-700 hover:underline dark:text-blue-400">
                                /lab/{lab.slug}
                              </a>
                              <span>·</span>
                              <span>{lab.is_demo ? 'Demo' : 'Live'}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-xs">
                            <div className="font-medium text-slate-900 dark:text-slate-100">{lab.owner_name}</div>
                            <div className="text-slate-500">{lab.owner_email}</div>
                            <div className="font-mono text-slate-500">WA: {lab.whatsapp_number}</div>
                          </td>
                          <td className="px-4 py-3.5 text-xs">
                            <div className="font-medium">{lab.subscription_plan}</div>
                            <div className="font-mono text-slate-500 tabular-nums">Exp: {lab.subscription_expiry}</div>
                          </td>
                          <td className="px-4 py-3.5 text-right font-mono text-xs tabular-nums">
                            <div className="font-semibold text-emerald-700 dark:text-emerald-400">{formatCurrency(lab.amount_paid)}</div>
                            {lab.pending_amount > 0 && (
                              <div className="text-amber-700 dark:text-amber-400">Due: {formatCurrency(lab.pending_amount)}</div>
                            )}
                          </td>
                          <td className="px-4 py-3.5">
                            <StatusIndicator status={lab.status} />
                          </td>
                          <td className="px-4 py-3.5">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => setQrLab(lab)}
                                title="View QR Code"
                                className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                              >
                                <QrCode className="h-3.5 w-3.5" />
                              </button>
                              <a
                                href={labUrl}
                                target="_blank"
                                rel="noreferrer"
                                title="Open Lab Website"
                                className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                              >
                                <ExternalLink className="h-3.5 w-3.5" />
                              </a>
                              <button
                                type="button"
                                onClick={() => openEditModal(lab)}
                                title="Edit Laboratory"
                                className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                              >
                                <Edit3 className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setPaymentLab(lab);
                                  setPayAmount(String(lab.pending_amount > 0 ? lab.pending_amount : 5000));
                                }}
                                title="Record Payment"
                                className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                              >
                                <CreditCard className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleResendInvite(lab)}
                                title="Resend Owner Invite"
                                className="rounded border border-slate-200 p-1.5 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300"
                              >
                                <KeyRound className="h-3.5 w-3.5" />
                              </button>
                              {lab.status === 'active' ? (
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(lab, 'suspended')}
                                  title="Suspend Lab"
                                  className="rounded border border-amber-200 p-1.5 text-amber-700 hover:bg-amber-50 dark:border-amber-900/50 dark:text-amber-400"
                                >
                                  <PauseCircle className="h-3.5 w-3.5" />
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(lab, 'active')}
                                  title="Activate Lab"
                                  className="rounded border border-emerald-200 p-1.5 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-900/50 dark:text-emerald-400"
                                >
                                  <CheckCircle2 className="h-3.5 w-3.5" />
                                </button>
                              )}
                              {lab.status !== 'deactivated' && (
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(lab, 'deactivated')}
                                  title="Deactivate Lab"
                                  className="rounded border border-red-200 p-1.5 text-red-700 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400"
                                >
                                  <Ban className="h-3.5 w-3.5" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => handleDeleteLab(lab)}
                                title="Delete Lab"
                                className="rounded border border-red-200 p-1.5 text-red-700 hover:bg-red-50 dark:border-red-900/50 dark:text-red-400"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ALL BOOKINGS TAB */}
          {tab === 'bookings' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-1 rounded-lg border border-slate-200 bg-white p-1 dark:border-slate-800 dark:bg-slate-900">
                  {(['all', 'live', 'demo'] as const).map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => setDatasetFilter(f)}
                      className={`rounded-md px-3 py-1.5 text-xs font-medium capitalize ${
                        datasetFilter === f ? 'bg-blue-700 text-white' : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {f === 'all' ? 'All Bookings' : f === 'live' ? 'Live Patient Records' : 'Demo Sample'}
                    </button>
                  ))}
                </div>
                <button
                  type="button"
                  onClick={() => exportBookingsToExcel(filteredBookings, 'platform-all-bookings.xlsx')}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                >
                  <FileSpreadsheet className="h-3.5 w-3.5" />
                  <span>{t('exportExcel')}</span>
                </button>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Booking ID</th>
                      <th className="px-4 py-3">Laboratory</th>
                      <th className="px-4 py-3">Patient</th>
                      <th className="px-4 py-3">Test</th>
                      <th className="px-4 py-3">Schedule</th>
                      <th className="px-4 py-3 text-right">Amount</th>
                      <th className="px-4 py-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {filteredBookings.map((b) => (
                      <tr key={b.id}>
                        <td className="px-4 py-3 font-mono text-xs font-semibold">
                          {b.booking_code}
                          <div className="text-[11px] font-normal text-slate-500">
                            {b.is_demo ? 'Demo Sample' : 'Live Patient'}
                          </div>
                        </td>
                        <td className="px-4 py-3 text-xs font-medium">{b.website_name || b.lab_name}</td>
                        <td className="px-4 py-3 text-xs">
                          <div className="font-medium">{b.patient_name}</div>
                          <div className="font-mono text-slate-500">{b.patient_mobile}</div>
                        </td>
                        <td className="px-4 py-3 text-xs">{b.test_name}</td>
                        <td className="px-4 py-3 font-mono text-xs tabular-nums">
                          {b.booking_date} · {b.time_slot}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs font-semibold tabular-nums">
                          {formatCurrency(b.price)}
                        </td>
                        <td className="px-4 py-3">
                          <StatusIndicator status={b.status} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SALES & INVOICES TAB */}
          {tab === 'sales' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <div>
                  <h2 className="font-display text-base font-semibold">Subscription Enforcement & Renewal Reminders</h2>
                  <p className="mt-1 text-xs text-slate-500">
                    Automatically suspend laboratories whose expiry date has passed, or dispatch payment reminders.
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => exportSalesToExcel(labs, 'platform-sales-revenue.xlsx')}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950"
                  >
                    <FileSpreadsheet className="h-3.5 w-3.5" />
                    <span>Export Sales Excel</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleEnforceSubscriptions}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3.5 py-2 text-xs font-semibold text-amber-800 hover:bg-amber-100 dark:border-amber-900/50 dark:bg-amber-950/40 dark:text-amber-300"
                  >
                    <ShieldAlert className="h-3.5 w-3.5" />
                    <span>Enforce Expired Subscriptions</span>
                  </button>
                </div>
              </div>

              {/* Lab Billing Summary */}
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="border-b border-slate-200 px-5 py-3.5 text-sm font-semibold dark:border-slate-800">
                  Subscription Plans & Pending Balances
                </div>
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Laboratory</th>
                      <th className="px-4 py-3">Plan</th>
                      <th className="px-4 py-3">Expiry</th>
                      <th className="px-4 py-3 text-right">Selling Price</th>
                      <th className="px-4 py-3 text-right">Paid</th>
                      <th className="px-4 py-3 text-right">Pending</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {labs.map((lab) => (
                      <tr key={lab.id}>
                        <td className="px-4 py-3 text-xs font-semibold">{lab.website_name}</td>
                        <td className="px-4 py-3 text-xs">{lab.subscription_plan}</td>
                        <td className="px-4 py-3 font-mono text-xs tabular-nums">{lab.subscription_expiry}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs tabular-nums">{formatCurrency(lab.selling_price)}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-emerald-700 tabular-nums dark:text-emerald-400">
                          {formatCurrency(lab.amount_paid)}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-xs text-amber-700 tabular-nums dark:text-amber-400">
                          {formatCurrency(lab.pending_amount)}
                        </td>
                        <td className="px-4 py-3 text-right">
                          <div className="inline-flex gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                setPaymentLab(lab);
                                setPayAmount(String(lab.pending_amount > 0 ? lab.pending_amount : 5000));
                              }}
                              className="rounded border border-slate-300 px-2.5 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700"
                            >
                              Record Payment
                            </button>
                            <button
                              type="button"
                              onClick={() => handleSendRenewalReminder(lab)}
                              className="rounded border border-blue-200 bg-blue-50 px-2.5 py-1 text-xs font-medium text-blue-700 hover:bg-blue-100 dark:border-blue-900/50 dark:bg-blue-950/30 dark:text-blue-400"
                            >
                              Send Reminder
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Invoices Ledger */}
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="border-b border-slate-200 px-5 py-3.5 text-sm font-semibold dark:border-slate-800">
                  Generated Invoices & Payments
                </div>
                <table className="w-full text-left text-sm">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Invoice #</th>
                      <th className="px-4 py-3">Laboratory</th>
                      <th className="px-4 py-3">Type</th>
                      <th className="px-4 py-3 text-right">Amount</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3 text-right">PDF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {payments.map((p) => (
                      <tr key={p.id}>
                        <td className="px-4 py-3 font-mono text-xs font-semibold">{p.invoice_number}</td>
                        <td className="px-4 py-3 text-xs">{p.lab_name}</td>
                        <td className="px-4 py-3 text-xs capitalize">{p.payment_type.replace('_', ' ')}</td>
                        <td className="px-4 py-3 text-right font-mono text-xs font-semibold tabular-nums">
                          {formatCurrency(p.amount)}
                        </td>
                        <td className="px-4 py-3">
                          <StatusIndicator status={p.status} />
                        </td>
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={() => downloadLabInvoicePdf(p)}
                            className="inline-flex items-center gap-1 rounded border border-slate-300 px-2.5 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700"
                          >
                            <Download className="h-3 w-3" />
                            <span>Invoice PDF</span>
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* NOTIFICATIONS & PROVIDER CREDENTIALS TAB */}
          {tab === 'notifications' && (
            <div className="space-y-6">
              <form onSubmit={handleSaveProviderSettings} className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                {/* SMTP Configuration */}
                <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                      <h2 className="font-display text-base font-semibold">SMTP Email Provider</h2>
                    </div>
                    <button
                      type="button"
                      onClick={handleVerifySmtp}
                      className="rounded-lg border border-slate-300 px-3 py-1 text-xs font-medium hover:bg-slate-50 dark:border-slate-700"
                    >
                      Verify SMTP
                    </button>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="mb-1 block text-xs text-slate-500">SMTP Host</label>
                      <input
                        type="text"
                        value={smtpForm.host}
                        onChange={(e) => setSmtpForm({ ...smtpForm, host: e.target.value })}
                        placeholder="smtp.gmail.com or smtp.resend.com"
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <label className="mb-1 block text-xs text-slate-500">Port</label>
                      <input
                        type="number"
                        value={smtpForm.port}
                        onChange={(e) => setSmtpForm({ ...smtpForm, port: Number(e.target.value) })}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">SMTP Username</label>
                      <input
                        type="text"
                        value={smtpForm.user}
                        onChange={(e) => setSmtpForm({ ...smtpForm, user: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">
                        SMTP Password {smtpForm.pass_masked ? `(${smtpForm.pass_masked})` : ''}
                      </label>
                      <input
                        type="password"
                        value={smtpForm.pass}
                        onChange={(e) => setSmtpForm({ ...smtpForm, pass: e.target.value })}
                        placeholder="Leave blank to keep existing"
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">Sender Name</label>
                      <input
                        type="text"
                        value={smtpForm.from_name}
                        onChange={(e) => setSmtpForm({ ...smtpForm, from_name: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs text-slate-500">Sender Email</label>
                      <input
                        type="email"
                        value={smtpForm.from_email}
                        onChange={(e) => setSmtpForm({ ...smtpForm, from_email: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                  </div>
                </div>

                {/* WhatsApp Business Cloud API / Twilio */}
                <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
                    <div className="flex items-center gap-2">
                      <MessageCircle className="h-4 w-4 text-emerald-600" />
                      <h2 className="font-display text-base font-semibold">Official WhatsApp API Provider</h2>
                    </div>
                    <select
                      value={waForm.provider}
                      onChange={(e) => setWaForm({ ...waForm, provider: e.target.value as 'meta_cloud_api' | 'twilio' })}
                      className="rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs dark:border-slate-700 dark:bg-slate-950"
                    >
                      <option value="meta_cloud_api">Meta WhatsApp Cloud API</option>
                      <option value="twilio">Twilio WhatsApp API</option>
                    </select>
                  </div>

                  {waForm.provider === 'meta_cloud_api' ? (
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Phone Number ID</label>
                        <input
                          type="text"
                          value={waForm.phone_number_id}
                          onChange={(e) => setWaForm({ ...waForm, phone_number_id: e.target.value })}
                          placeholder="e.g. 104928374651234"
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Graph API Version</label>
                        <input
                          type="text"
                          value={waForm.api_version}
                          onChange={(e) => setWaForm({ ...waForm, api_version: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="mb-1 block text-xs text-slate-500">
                          Permanent Access Token {waForm.access_token_masked ? `(${waForm.access_token_masked})` : ''}
                        </label>
                        <input
                          type="password"
                          value={waForm.access_token}
                          onChange={(e) => setWaForm({ ...waForm, access_token: e.target.value })}
                          placeholder="EAAG... (leave blank to keep existing)"
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">Twilio Account SID</label>
                        <input
                          type="text"
                          value={waForm.twilio_sid}
                          onChange={(e) => setWaForm({ ...waForm, twilio_sid: e.target.value })}
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs text-slate-500">WhatsApp From Number</label>
                        <input
                          type="text"
                          value={waForm.twilio_from}
                          onChange={(e) => setWaForm({ ...waForm, twilio_from: e.target.value })}
                          placeholder="+14155238886"
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="mb-1 block text-xs text-slate-500">
                          Auth Token {waForm.twilio_token_masked ? `(${waForm.twilio_token_masked})` : ''}
                        </label>
                        <input
                          type="password"
                          value={waForm.twilio_token}
                          onChange={(e) => setWaForm({ ...waForm, twilio_token: e.target.value })}
                          placeholder="Leave blank to keep existing"
                          className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* Templates Editor */}
                <div className="rounded-xl border border-slate-200 bg-white p-6 lg:col-span-2 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-3 dark:border-slate-800">
                    <div>
                      <h2 className="font-display text-base font-semibold">Message Templates</h2>
                      <p className="text-xs text-slate-500">
                        Supported placeholders: {'{{owner_name}}, {{website_name}}, {{lab_url}}, {{invite_link}}, {{booking_code}}, {{patient_name}}, {{test_name}}'}
                      </p>
                    </div>
                    <button
                      type="submit"
                      className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                    >
                      Save Credentials & Templates
                    </button>
                  </div>

                  <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div>
                      <label className="mb-1 block text-xs font-medium text-slate-500">Lab Welcome WhatsApp Template</label>
                      <textarea
                        rows={3}
                        value={templatesForm.lab_welcome_whatsapp || ''}
                        onChange={(e) => setTemplatesForm({ ...templatesForm, lab_welcome_whatsapp: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-slate-500">Booking Owner Alert WhatsApp Template</label>
                      <textarea
                        rows={3}
                        value={templatesForm.booking_owner_whatsapp || ''}
                        onChange={(e) => setTemplatesForm({ ...templatesForm, booking_owner_whatsapp: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-slate-500">Lab Welcome Email Body</label>
                      <textarea
                        rows={4}
                        value={templatesForm.lab_welcome_email_body || ''}
                        onChange={(e) => setTemplatesForm({ ...templatesForm, lab_welcome_email_body: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="mb-1 block text-xs font-medium text-slate-500">Patient Confirmation Email Body</label>
                      <textarea
                        rows={4}
                        value={templatesForm.booking_patient_email_body || ''}
                        onChange={(e) => setTemplatesForm({ ...templatesForm, booking_patient_email_body: e.target.value })}
                        className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                  </div>
                </div>
              </form>

              {/* Live Provider Tester */}
              <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
                <h3 className="text-sm font-semibold">Live Dispatch Test (Real API Call)</h3>
                <div className="mt-3 grid grid-cols-1 gap-3 md:grid-cols-2">
                  <div className="flex gap-2">
                    <input
                      type="email"
                      value={testEmailAddr}
                      onChange={(e) => setTestEmailAddr(e.target.value)}
                      placeholder="Recipient email to test SMTP..."
                      className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                    />
                    <button
                      type="button"
                      onClick={() => handleSendTest('email')}
                      className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-2 text-xs font-medium text-white dark:bg-slate-700"
                    >
                      <Send className="h-3 w-3" />
                      <span>Test Email</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={testWaPhone}
                      onChange={(e) => setTestWaPhone(e.target.value)}
                      placeholder="WhatsApp number with country code..."
                      className="flex-1 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                    />
                    <button
                      type="button"
                      onClick={() => handleSendTest('whatsapp')}
                      className="inline-flex items-center gap-1 rounded-lg bg-emerald-700 px-3 py-2 text-xs font-medium text-white"
                    >
                      <Send className="h-3 w-3" />
                      <span>Test WhatsApp</span>
                    </button>
                  </div>
                </div>
                {providerTestResult && (
                  <div className="mt-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs dark:border-slate-800 dark:bg-slate-950">
                    {providerTestResult}
                  </div>
                )}
              </div>

              {/* Real Delivery Status Logs */}
              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <div className="flex items-center justify-between border-b border-slate-200 px-5 py-3.5 dark:border-slate-800">
                  <h3 className="text-sm font-semibold">Actual Delivery Logs (SMTP & WhatsApp API)</h3>
                  <button
                    type="button"
                    onClick={loadAllData}
                    className="inline-flex items-center gap-1 text-xs font-medium text-blue-700 dark:text-blue-400"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    <span>Refresh</span>
                  </button>
                </div>
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Timestamp</th>
                      <th className="px-4 py-3">Channel & Event</th>
                      <th className="px-4 py-3">Recipient</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Provider Response / Error</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {notifLogs.map((l) => (
                      <tr key={l.id}>
                        <td className="px-4 py-3 font-mono whitespace-nowrap tabular-nums">
                          {new Date(l.created_at).toLocaleString()}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-semibold uppercase">{l.channel}</span> · {l.event_type}
                        </td>
                        <td className="px-4 py-3 font-mono">{l.recipient}</td>
                        <td className="px-4 py-3">
                          <StatusIndicator status={l.status} />
                        </td>
                        <td className="max-w-md px-4 py-3 text-slate-600 dark:text-slate-400">
                          {l.error_message || l.provider_response || '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* AUDIT & BACKUPS TAB */}
          {tab === 'audit' && (
            <div className="space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
                <div>
                  <h2 className="font-display text-base font-semibold">Database Backup, Project Source ZIP & Security Audit</h2>
                  <p className="mt-1 text-xs text-slate-500">
                    Export a complete multi-tenant database snapshot (.json) or download the full deployable platform source archive (.zip).
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  <a
                    href="/api/super-admin/export-project-zip"
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:hover:bg-slate-800"
                  >
                    <Download className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                    <span>Download Source Code (.zip)</span>
                  </a>
                  <a
                    href="/api/super-admin/backup"
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-800"
                  >
                    <DatabaseBackup className="h-4 w-4" />
                    <span>Download Full Backup (.json)</span>
                  </a>
                </div>
              </div>

              <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-200 bg-slate-50 text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <tr>
                      <th className="px-4 py-3">Time</th>
                      <th className="px-4 py-3">Actor</th>
                      <th className="px-4 py-3">Action</th>
                      <th className="px-4 py-3">Details</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {auditLogs.map((a) => (
                      <tr key={a.id}>
                        <td className="px-4 py-3 font-mono whitespace-nowrap tabular-nums">
                          {new Date(a.created_at).toLocaleString()}
                        </td>
                        <td className="px-4 py-3">{a.actor_email || 'System'}</td>
                        <td className="px-4 py-3 font-mono font-medium">{a.action}</td>
                        <td className="px-4 py-3 text-slate-600 dark:text-slate-400">{a.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Create / Edit Lab Modal */}
      {createOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="my-8 w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
              <h3 className="font-display text-lg font-bold">
                {editingLab ? `Edit ${editingLab.website_name}` : 'Create & Sell New Laboratory Website'}
              </h3>
              <button type="button" onClick={() => setCreateOpen(false)} className="rounded-lg p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSaveLab} className="mt-5 space-y-4 text-sm">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Official Lab Name *</label>
                  <input
                    type="text"
                    required
                    value={labForm.name}
                    onChange={(e) => {
                      const val = e.target.value;
                      setLabForm((prev) => ({
                        ...prev,
                        name: val,
                        website_name: prev.website_name || val,
                        slug: editingLab ? prev.slug : val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
                      }));
                    }}
                    placeholder="e.g. Apex Clinical Pathology"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Website Display Name *</label>
                  <input
                    type="text"
                    required
                    value={labForm.website_name}
                    onChange={(e) => setLabForm({ ...labForm, website_name: e.target.value })}
                    placeholder="e.g. Apex Diagnostics"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Unique Website Slug *</label>
                  <div className="flex items-center rounded-lg border border-slate-300 bg-slate-50 px-3 dark:border-slate-700 dark:bg-slate-950">
                    <span className="font-mono text-xs text-slate-400">/lab/</span>
                    <input
                      type="text"
                      required
                      value={labForm.slug}
                      onChange={(e) => setLabForm({ ...labForm, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '') })}
                      className="w-full bg-transparent py-2 pl-1 font-mono text-xs focus:outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Custom Domain (Optional)</label>
                  <input
                    type="text"
                    value={labForm.custom_domain}
                    onChange={(e) => setLabForm({ ...labForm, custom_domain: e.target.value })}
                    placeholder="lab.apexdiagnostics.in"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Lab Owner Name *</label>
                  <input
                    type="text"
                    required
                    value={labForm.owner_name}
                    onChange={(e) => setLabForm({ ...labForm, owner_name: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Lab Owner Email *</label>
                  <input
                    type="email"
                    required
                    value={labForm.owner_email}
                    onChange={(e) => setLabForm({ ...labForm, owner_email: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Owner WhatsApp Number *</label>
                  <input
                    type="tel"
                    required
                    value={labForm.whatsapp_number}
                    onChange={(e) => setLabForm({ ...labForm, whatsapp_number: e.target.value })}
                    placeholder="9198XXXXXXXX"
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Lab Phone Contact *</label>
                  <input
                    type="tel"
                    required
                    value={labForm.contact_number}
                    onChange={(e) => setLabForm({ ...labForm, contact_number: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Address *</label>
                  <input
                    type="text"
                    required
                    value={labForm.address}
                    onChange={(e) => setLabForm({ ...labForm, address: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">City *</label>
                  <input
                    type="text"
                    required
                    value={labForm.city}
                    onChange={(e) => setLabForm({ ...labForm, city: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Subscription Plan</label>
                  <select
                    value={labForm.subscription_plan}
                    onChange={(e) => setLabForm({ ...labForm, subscription_plan: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  >
                    <option value="Starter Monthly">Starter Monthly</option>
                    <option value="Growth Annual">Growth Annual</option>
                    <option value="Enterprise Custom">Enterprise Custom</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Expiry Date</label>
                  <input
                    type="date"
                    value={labForm.subscription_expiry}
                    onChange={(e) => setLabForm({ ...labForm, subscription_expiry: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Website Selling Price (INR)</label>
                  <input
                    type="number"
                    min={0}
                    value={labForm.selling_price}
                    onChange={(e) => setLabForm({ ...labForm, selling_price: e.target.value })}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                {!editingLab && (
                  <div>
                    <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Initial Amount Paid (INR)</label>
                    <input
                      type="number"
                      min={0}
                      value={labForm.amount_paid}
                      onChange={(e) => setLabForm({ ...labForm, amount_paid: e.target.value })}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                )}
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Website Tagline</label>
                  <input
                    type="text"
                    value={labForm.tagline}
                    onChange={(e) => setLabForm({ ...labForm, tagline: e.target.value })}
                    placeholder="Accurate clinical diagnostics & doorstep home sample collection."
                    className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">Laboratory Logo (Optional)</label>
                  <div className="flex items-center gap-3">
                    {labForm.logo_url && (
                      <img src={labForm.logo_url} alt="Logo preview" className="h-10 w-10 rounded border border-slate-200 object-contain" />
                    )}
                    <input type="file" accept="image/*" onChange={handleLabLogoUpload} className="text-xs" />
                  </div>
                </div>
              </div>

              <div>
                <div className="mb-1.5 text-xs font-medium text-slate-600 dark:text-slate-400">Lab Owner Permissions</div>
                <div className="flex flex-wrap gap-3">
                  {ALL_PERMISSIONS.map((perm) => {
                    const checked = labForm.permissions.includes(perm.id);
                    return (
                      <label key={perm.id} className="inline-flex items-center gap-1.5 text-xs">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setLabForm((prev) => ({
                              ...prev,
                              permissions: checked
                                ? prev.permissions.filter((p) => p !== perm.id)
                                : [...prev.permissions, perm.id],
                            }))
                          }
                        />
                        <span>{perm.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateOpen(false)}
                  className="rounded-lg border border-slate-300 px-4 py-2 text-xs font-semibold dark:border-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingLab}
                  className="rounded-lg bg-blue-700 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
                >
                  {savingLab ? 'Provisioning...' : editingLab ? 'Save Changes' : 'Create Lab Website & Send Invite'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Newly Created Lab Provisioning Summary Modal */}
      {createdProvisionInfo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <h3 className="font-display text-lg font-bold text-emerald-700 dark:text-emerald-400">
                  Laboratory Website Provisioned
                </h3>
                <p className="text-xs text-slate-500">{createdProvisionInfo.lab.website_name}</p>
              </div>
              <button type="button" onClick={() => setCreatedProvisionInfo(null)}>
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
                <div className="text-slate-500">Public Lab Website URL</div>
                <a href={createdProvisionInfo.credentials.labUrl} target="_blank" rel="noreferrer" className="font-mono font-semibold text-blue-700 hover:underline dark:text-blue-400">
                  {createdProvisionInfo.credentials.labUrl}
                </a>
              </div>
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
                <div className="text-slate-500">Secure Owner Invitation Link</div>
                <div className="mt-0.5 break-all font-mono text-slate-900 dark:text-slate-100">
                  {createdProvisionInfo.credentials.inviteLink}
                </div>
                <div className="mt-2 text-slate-500">
                  Owner Email: <span className="font-mono">{createdProvisionInfo.credentials.email}</span> · Temp Password:{' '}
                  <span className="font-mono font-semibold">{createdProvisionInfo.credentials.tempPassword}</span>
                </div>
              </div>

              <div className="rounded-lg border border-slate-200 p-3 dark:border-slate-800">
                <div className="font-semibold">Actual Notification Delivery Status</div>
                <div className="mt-2 space-y-1.5">
                  {Object.entries(createdProvisionInfo.notifications).map(([ch, res]) => (
                    <div key={ch} className="flex items-center justify-between gap-2">
                      <span className="capitalize">{ch}</span>
                      <div className="flex items-center gap-2">
                        <StatusIndicator status={res.status} />
                        {res.error && <span className="max-w-[220px] truncate text-slate-500" title={res.error}>{res.error}</span>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => {
                  setQrLab(createdProvisionInfo.lab);
                  setCreatedProvisionInfo(null);
                }}
                className="rounded-lg border border-slate-300 px-3.5 py-2 text-xs font-semibold dark:border-slate-700"
              >
                View QR Code
              </button>
              <button
                type="button"
                onClick={() => setCreatedProvisionInfo(null)}
                className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Record Payment Modal */}
      {paymentLab && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3 dark:border-slate-800">
              <h3 className="font-display text-base font-bold">Record Payment — {paymentLab.website_name}</h3>
              <button type="button" onClick={() => setPaymentLab(null)}>
                <X className="h-5 w-5" />
              </button>
            </div>
            <form onSubmit={handleRecordPayment} className="mt-4 space-y-3 text-sm">
              <div>
                <label className="mb-1 block text-xs text-slate-500">Amount Received (INR)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={payAmount}
                  onChange={(e) => setPayAmount(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-sm dark:border-slate-700 dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-slate-500">Payment Type</label>
                <select
                  value={payType}
                  onChange={(e) => setPayType(e.target.value as 'partial_payment' | 'subscription_renewal')}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                >
                  <option value="partial_payment">Balance / Installment Payment</option>
                  <option value="subscription_renewal">Subscription Renewal</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-slate-500">Extend Subscription (Months)</label>
                <input
                  type="number"
                  min={0}
                  max={36}
                  value={extendMonths}
                  onChange={(e) => setExtendMonths(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-slate-500">Method & Reference Notes</label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  placeholder="UTR / UPI Ref / Bank Transfer"
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setPaymentLab(null)} className="rounded-lg border border-slate-300 px-3 py-2 text-xs dark:border-slate-700">
                  Cancel
                </button>
                <button type="submit" className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white">
                  Save & Generate Invoice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <QrCodeModal
        open={Boolean(qrLab)}
        onClose={() => setQrLab(null)}
        labName={qrLab?.website_name || ''}
        url={qrLab ? `${window.location.origin}/lab/${qrLab.slug}` : ''}
        customDomain={qrLab?.custom_domain}
      />

      {loading && (
        <div className="pointer-events-none fixed right-6 bottom-6 rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs shadow dark:border-slate-700 dark:bg-slate-900">
          Syncing platform metrics...
        </div>
      )}
    </div>
  );
};
