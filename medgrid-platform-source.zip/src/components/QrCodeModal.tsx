import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { Copy, Check, Download, ExternalLink, X } from 'lucide-react';

interface QrCodeModalProps {
  open: boolean;
  onClose: () => void;
  labName: string;
  url: string;
  customDomain?: string;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ open, onClose, labName, url, customDomain }) => {
  const [dataUrl, setDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open || !url) return;
    QRCode.toDataURL(url, {
      width: 320,
      margin: 2,
      color: { dark: '#0F172A', light: '#FFFFFF' },
    })
      .then(setDataUrl)
      .catch((err) => console.error('QR generation error:', err));
  }, [open, url]);

  if (!open) return null;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard restrictions
    }
  };

  const downloadQr = () => {
    if (!dataUrl) return;
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = `${labName.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-qr.png`;
    link.click();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
          <div>
            <h3 className="text-lg font-semibold text-slate-900 dark:text-slate-100">{labName}</h3>
            <p className="mt-0.5 text-sm text-slate-500 dark:text-slate-400">
              Scannable Patient Booking QR Code
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-6 flex flex-col items-center">
          <div className="rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700">
            {dataUrl ? (
              <img src={dataUrl} alt={`QR code for ${labName}`} className="h-56 w-56" />
            ) : (
              <div className="flex h-56 w-56 items-center justify-center text-sm text-slate-400">
                Generating QR...
              </div>
            )}
          </div>

          <div className="mt-4 w-full rounded-lg border border-slate-200 bg-slate-50 p-3 dark:border-slate-800 dark:bg-slate-950">
            <div className="text-xs font-medium text-slate-500 dark:text-slate-400">Public Website URL</div>
            <div className="mt-1 truncate font-mono text-xs text-slate-900 dark:text-slate-100">{url}</div>
            {customDomain && (
              <div className="mt-1.5 text-xs text-blue-700 dark:text-blue-400">
                Custom domain mapped: <span className="font-mono">{customDomain}</span>
              </div>
            )}
          </div>

          <div className="mt-5 grid w-full grid-cols-3 gap-2">
            <button
              type="button"
              onClick={copyLink}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
              <span>{copied ? 'Copied' : 'Copy URL'}</span>
            </button>
            <button
              type="button"
              onClick={downloadQr}
              className="flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Save PNG</span>
            </button>
            <a
              href={url}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-1.5 rounded-lg bg-blue-700 px-3 py-2 text-xs font-medium text-white transition-colors hover:bg-blue-800"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span>Open Site</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
