import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Clock,
  Download,
  FlaskConical,
  Home,
  Info,
  MapPin,
  MessageCircle,
  Phone,
  Search,
  X,
} from 'lucide-react';
import { apiFetch, formatCurrency, type BookingRecord, type DiagnosticTest, type LabRecord, type TestCategory } from '../lib/api';
import { useAppSettings } from '../lib/i18n';
import { PLATFORM_IMAGES, resolveLabBanner } from '../lib/assets';
import { downloadBookingReceiptPdf } from '../lib/exports';
import { ThemeLangToolbar } from './ThemeLangToolbar';
import { StatusIndicator } from './StatusBadge';

interface PublicLabWebsiteProps {
  slug: string;
  onNavigate: (path: string) => void;
}

const TIME_SLOTS = [
  '07:00 AM - 08:00 AM',
  '08:00 AM - 09:00 AM',
  '09:00 AM - 10:00 AM',
  '10:00 AM - 11:00 AM',
  '11:00 AM - 12:00 PM',
  '04:00 PM - 05:00 PM',
  '05:00 PM - 06:00 PM',
];

export const PublicLabWebsite: React.FC<PublicLabWebsiteProps> = ({ slug, onNavigate }) => {
  const { lang, t } = useAppSettings();
  const [lab, setLab] = useState<LabRecord | null>(null);
  const [categories, setCategories] = useState<TestCategory[]>([]);
  const [tests, setTests] = useState<DiagnosticTest[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filtering
  const [search, setSearch] = useState(() => new URLSearchParams(window.location.search).get('q') || '');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [onlyPackages, setOnlyPackages] = useState(false);

  // Test detail modal
  const [detailTest, setDetailTest] = useState<DiagnosticTest | null>(null);

  // Booking wizard modal
  const [bookingTest, setBookingTest] = useState<DiagnosticTest | null>(null);
  const [bookingDate, setBookingDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [timeSlot, setTimeSlot] = useState(TIME_SLOTS[1]);
  const [collectionType, setCollectionType] = useState<'home_collection' | 'lab_visit'>('home_collection');
  const [collectionAddress, setCollectionAddress] = useState('');
  const [patientName, setPatientName] = useState('');
  const [patientMobile, setPatientMobile] = useState('');
  const [patientEmail, setPatientEmail] = useState('');
  const [patientAge, setPatientAge] = useState('32');
  const [patientGender, setPatientGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [submitting, setSubmitting] = useState(false);
  const [bookingError, setBookingError] = useState('');
  const [confirmedResult, setConfirmedResult] = useState<{
    booking: BookingRecord;
    notifications: Record<string, { status?: string; error?: string; providerResponse?: string } | null>;
  } | null>(null);

  // Status check & cancellation
  const [trackCode, setTrackCode] = useState('');
  const [trackMobile, setTrackMobile] = useState('');
  const [tracked, setTracked] = useState<BookingRecord | null>(null);
  const [trackErr, setTrackErr] = useState('');
  const [cancelMsg, setCancelMsg] = useState('');

  useEffect(() => {
    setLoading(true);
    setError('');
    apiFetch<{ lab: LabRecord; categories: TestCategory[]; tests: DiagnosticTest[] }>(`/api/public/labs/${slug}`)
      .then((res) => {
        setLab(res.lab);
        setCategories(res.categories);
        setTests(res.tests);
      })
      .catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false));
  }, [slug]);

  useEffect(() => {
    if (!lab) return;
    const title = `${lab.website_name} — Book Diagnostic Tests Online | ${lab.city}`;
    const desc = `${lab.tagline} Book blood tests, pathology & health packages online with home sample collection at ${lab.website_name}, ${lab.city}.`.slice(0, 160);
    document.title = title;

    const setMeta = (selector: string, content: string) => {
      const el = document.querySelector(selector);
      if (el) el.setAttribute('content', content);
    };
    setMeta('meta[name="description"]', desc);
    setMeta('meta[property="og:title"]', title);
    setMeta('meta[property="og:description"]', desc);
    setMeta('meta[name="twitter:title"]', title);
    setMeta('meta[name="twitter:description"]', desc);

    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = `${window.location.origin}/lab/${lab.slug}`;

    let ld = document.getElementById('lab-jsonld') as HTMLScriptElement | null;
    if (!ld) {
      ld = document.createElement('script');
      ld.id = 'lab-jsonld';
      ld.type = 'application/ld+json';
      document.head.appendChild(ld);
    }
    ld.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'DiagnosticLab',
      name: lab.website_name,
      description: lab.tagline,
      url: `${window.location.origin}/lab/${lab.slug}`,
      telephone: lab.contact_number,
      address: {
        '@type': 'PostalAddress',
        streetAddress: lab.address,
        addressLocality: lab.city,
        addressCountry: 'IN',
      },
    });
  }, [lab]);

  const filteredTests = tests.filter((item) => {
    if (selectedCat !== 'all' && item.category_id !== selectedCat) return false;
    if (onlyPackages && !item.is_package) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        item.name.toLowerCase().includes(q) ||
        (item.name_hi || '').toLowerCase().includes(q) ||
        (item.code || '').toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const openBookingFor = (test: DiagnosticTest) => {
    setConfirmedResult(null);
    setBookingError('');
    setCollectionType(test.home_collection_available ? 'home_collection' : 'lab_visit');
    setBookingTest(test);
  };

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bookingTest || !lab) return;
    setSubmitting(true);
    setBookingError('');
    try {
      const res = await apiFetch<{
        booking: BookingRecord;
        notifications: Record<string, { status?: string; error?: string; providerResponse?: string } | null>;
      }>(`/api/public/labs/${lab.slug}/bookings`, {
        method: 'POST',
        body: JSON.stringify({
          test_id: bookingTest.id,
          patient_name: patientName,
          patient_mobile: patientMobile,
          patient_email: patientEmail,
          patient_age: Number(patientAge),
          patient_gender: patientGender,
          collection_type: collectionType,
          collection_address: collectionType === 'home_collection' ? collectionAddress : lab.address,
          booking_date: bookingDate,
          time_slot: timeSlot,
        }),
      });
      setConfirmedResult(res);
      setTrackCode(res.booking.booking_code);
    } catch (err: unknown) {
      setBookingError(err instanceof Error ? err.message : 'Failed to submit booking');
    } finally {
      setSubmitting(false);
    }
  };

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackCode.trim()) return;
    setTrackErr('');
    setCancelMsg('');
    setTracked(null);
    try {
      const qs = new URLSearchParams({ code: trackCode.trim() });
      if (trackMobile.trim()) qs.set('mobile', trackMobile.trim());
      const res = await apiFetch<{ booking: BookingRecord }>(`/api/public/bookings/track?${qs.toString()}`);
      setTracked(res.booking);
    } catch (err: unknown) {
      setTrackErr(err instanceof Error ? err.message : 'Booking not found');
    }
  };

  const handleCancelBooking = async () => {
    if (!tracked || !lab) return;
    try {
      await apiFetch(`/api/public/labs/${lab.slug}/bookings/${tracked.booking_code}/cancel`, {
        method: 'POST',
        body: JSON.stringify({ mobile: trackMobile || tracked.patient_mobile }),
      });
      setTracked({ ...tracked, status: 'cancelled' });
      setCancelMsg('Booking cancelled and laboratory owner notified.');
    } catch (err: unknown) {
      setTrackErr(err instanceof Error ? err.message : 'Failed to cancel booking');
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white dark:bg-slate-950">
        <div className="text-sm text-slate-500">Loading diagnostic laboratory portal...</div>
      </div>
    );
  }

  if (error || !lab) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 px-6 text-center dark:bg-slate-950">
        <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">Laboratory Portal Unavailable</h1>
        <p className="mt-2 max-w-md text-sm text-slate-600 dark:text-slate-400">
          {error || 'The diagnostic laboratory website you requested could not be found.'}
        </p>
        <button
          type="button"
          onClick={() => onNavigate('/')}
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2 text-sm font-semibold text-white"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to MedGrid Directory</span>
        </button>
      </div>
    );
  }

  const whatsappDigits = lab.whatsapp_number.replace(/[^\d]/g, '');
  const whatsappDirectUrl = `https://wa.me/${whatsappDigits}?text=${encodeURIComponent(
    `Hello ${lab.website_name}, I would like to book a diagnostic test.`
  )}`;

  return (
    <div className="min-h-screen bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Strict 3-Zone Top Bar */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-950/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-4">
          <a
            href={`/lab/${lab.slug}`}
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 dark:text-white"
          >
            {lab.logo_url && (
              <img src={lab.logo_url} alt={lab.website_name} className="h-7 w-7 rounded object-cover" />
            )}
            <span>{lab.website_name}</span>
          </a>

          <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex dark:text-slate-300">
            <a href="#tests" className="whitespace-nowrap shrink-0 hover:text-blue-700 dark:hover:text-blue-400">
              Diagnostic Tests
            </a>
            <a href="#home-collection" className="whitespace-nowrap shrink-0 hover:text-blue-700 dark:hover:text-blue-400">
              Home Collection
            </a>
            <a href="#track-status" className="whitespace-nowrap shrink-0 hover:text-blue-700 dark:hover:text-blue-400">
              {t('navTrack')}
            </a>
            <button
              type="button"
              onClick={() => onNavigate('/')}
              className="whitespace-nowrap shrink-0 hover:text-blue-700 dark:hover:text-blue-400"
            >
              Platform Home
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => {
                if (tests[0]) openBookingFor(tests[0]);
              }}
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
            >
              {t('bookTest')}
            </button>
          </div>
        </div>
      </header>

      {/* Lab Hero */}
      <section className="border-b border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto max-w-7xl px-6 py-10 lg:py-14">
          <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <MapPin className="h-3.5 w-3.5 text-blue-700 dark:text-blue-400" />
              <span>{lab.address}, {lab.city}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{lab.contact_number}</span>
            </div>
            <ThemeLangToolbar />
          </div>

          <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
            <div className="flex flex-col justify-between lg:col-span-6">
              <div>
                <h1 className="font-display text-3xl font-bold tracking-tight text-slate-900 text-balance sm:text-5xl dark:text-white">
                  {lab.name}
                </h1>
                <p className="mt-4 max-w-xl text-base leading-relaxed text-slate-600 dark:text-slate-300">
                  {lab.tagline}
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <a
                    href="#tests"
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-5 py-3 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
                  >
                    <FlaskConical className="h-4 w-4" />
                    <span>Browse {tests.length} Tests & Packages</span>
                  </a>
                  <a
                    href={whatsappDirectUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-lg border border-emerald-600 bg-emerald-600 px-5 py-3 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-emerald-700"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>{t('whatsappContact')}</span>
                  </a>
                </div>
              </div>

              <div className="mt-8 grid grid-cols-3 gap-4 border-t border-slate-200 pt-5 dark:border-slate-800">
                <div>
                  <div className="font-mono text-lg font-semibold tabular-nums">{tests.length}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Available Tests</div>
                </div>
                <div>
                  <div className="font-mono text-lg font-semibold tabular-nums">6–24h</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Digital Reports</div>
                </div>
                <div>
                  <div className="font-mono text-lg font-semibold tabular-nums">Home / Lab</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">Flexible Collection</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="h-full min-h-[260px] overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-900">
                <img
                  src={resolveLabBanner(lab.banner_url, lab.slug)}
                  alt={lab.name}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover lg:h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Search & Diagnostic Tests */}
      <section id="tests" className="mx-auto max-w-7xl px-6 py-14">
        <div className="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
          <div>
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Diagnostic Tests & Preventive Packages
            </h2>
            <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">
              Instant online appointment booking with no mandatory patient registration.
            </p>
          </div>
          <div className="relative w-full lg:w-80">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t('searchTestsPlaceholder')}
              className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pr-3 pl-9 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => {
              setSelectedCat('all');
              setOnlyPackages(false);
            }}
            className={`rounded-lg px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
              selectedCat === 'all' && !onlyPackages
                ? 'bg-blue-700 text-white'
                : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            {t('allCategories')}
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => {
                setSelectedCat(cat.id);
                setOnlyPackages(false);
              }}
              className={`rounded-lg px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
                selectedCat === cat.id && !onlyPackages
                  ? 'bg-blue-700 text-white'
                  : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300'
              }`}
            >
              {lang === 'hi' && cat.name_hi ? cat.name_hi : cat.name}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setOnlyPackages((p) => !p)}
            className={`rounded-lg px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
              onlyPackages
                ? 'bg-blue-700 text-white'
                : 'border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-300'
            }`}
          >
            {t('packagesOnly')}
          </button>
        </div>

        {filteredTests.length === 0 ? (
          <div className="mt-8 rounded-xl border border-slate-200 p-10 text-center dark:border-slate-800">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              No diagnostic tests matched your filter criteria.
            </p>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredTests.map((test) => {
              const displayPrice = test.discounted_price ?? test.price;
              const hasDiscount = Boolean(test.discounted_price && test.discounted_price < test.price);
              return (
                <article
                  key={test.id}
                  className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 transition-colors hover:border-blue-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-blue-700"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span>{lang === 'hi' && test.category_name_hi ? test.category_name_hi : test.category_name || 'Diagnostic'}</span>
                      {test.code && <span className="font-mono">{test.code}</span>}
                    </div>
                    <h3 className="mt-2 font-display text-lg font-semibold text-slate-900 dark:text-white">
                      {lang === 'hi' && test.name_hi ? test.name_hi : test.name}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-sm text-slate-600 dark:text-slate-300">
                      {test.description}
                    </p>

                    <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                      <span>{t('sampleType')}: {test.sample_type}</span>
                      <span aria-hidden="true">·</span>
                      <span>{t('reportingTime')}: {test.reporting_time}</span>
                      {test.is_package === 1 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-medium text-blue-700 dark:text-blue-400">
                            {test.package_items.length} Included Tests
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-slate-800">
                    <div>
                      <div className="font-mono text-xl font-bold text-slate-900 tabular-nums dark:text-white">
                        {formatCurrency(displayPrice)}
                      </div>
                      {hasDiscount && (
                        <div className="font-mono text-xs text-slate-400 line-through tabular-nums">
                          {formatCurrency(test.price)}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDetailTest(test)}
                        className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                        title="Test Details & Preparation"
                        aria-label={`View details for ${test.name}`}
                      >
                        <Info className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => openBookingFor(test)}
                        className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
                      >
                        {t('bookNow')}
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Home Sample Collection Feature Section */}
      <section id="home-collection" className="border-y border-slate-200 bg-slate-50/70 py-14 dark:border-slate-800 dark:bg-slate-900/30">
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-6 lg:grid-cols-12">
          <div className="overflow-hidden rounded-xl border border-slate-200 lg:col-span-5 dark:border-slate-800">
            <img
              src={PLATFORM_IMAGES.labHomeCollection}
              alt="Certified home sample collection technician"
              referrerPolicy="no-referrer"
              className="h-72 w-full object-cover"
            />
          </div>
          <div className="lg:col-span-7">
            <h2 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Doorstep Home Sample Collection & Priority Lab Visits
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
              Choose your preferred time slot from 7:00 AM to 6:00 PM. Our trained phlebotomists arrive with sealed single-use collection kits, barcoded vials, and cold-chain transport directly to {lab.website_name}.
            </p>
            <div className="mt-6 flex flex-wrap items-center gap-4 text-sm">
              <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                <Phone className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                <span className="font-mono">{lab.contact_number}</span>
              </div>
              <a
                href={whatsappDirectUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 font-semibold text-emerald-700 hover:underline dark:text-emerald-400"
              >
                <MessageCircle className="h-4 w-4" />
                <span>Book via WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Booking Status Lookup */}
      <section id="track-status" className="mx-auto max-w-7xl px-6 py-14">
        <div className="rounded-xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-slate-800 dark:bg-slate-900">
          <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">{t('trackBookingTitle')}</h2>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-400">{t('trackBookingSub')}</p>

          <form onSubmit={handleTrack} className="mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <input
              type="text"
              required
              value={trackCode}
              onChange={(e) => setTrackCode(e.target.value)}
              placeholder={t('bookingIdPlaceholder')}
              className="rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 font-mono text-sm focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950"
            />
            <input
              type="text"
              value={trackMobile}
              onChange={(e) => setTrackMobile(e.target.value)}
              placeholder={t('mobileOptionalPlaceholder')}
              className="rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950"
            />
            <button
              type="submit"
              className="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800"
            >
              {t('checkStatusBtn')}
            </button>
          </form>

          {trackErr && <div className="mt-4 text-sm text-red-600 dark:text-red-400">{trackErr}</div>}
          {cancelMsg && <div className="mt-4 text-sm text-emerald-700 dark:text-emerald-400">{cancelMsg}</div>}

          {tracked && (
            <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="font-mono text-sm font-bold">{tracked.booking_code}</div>
                  <div className="text-xs text-slate-500">
                    {tracked.patient_name} · {tracked.test_name} · {tracked.booking_date} ({tracked.time_slot})
                  </div>
                </div>
                <StatusIndicator status={tracked.status} />
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() =>
                    downloadBookingReceiptPdf(tracked, {
                      name: lab.website_name,
                      address: lab.address,
                      contact: lab.contact_number,
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>{t('downloadReceipt')}</span>
                </button>
                {!['cancelled', 'completed', 'rejected'].includes(tracked.status) && (
                  <button
                    type="button"
                    onClick={handleCancelBooking}
                    className="rounded-lg border border-red-300 bg-white px-3 py-1.5 text-xs font-medium text-red-700 hover:bg-red-50 dark:border-red-900/50 dark:bg-slate-900 dark:text-red-400"
                  >
                    {t('cancelBooking')}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* Floating Prominent WhatsApp Button (compact, respects 15% mobile sticky cap) */}
      <a
        href={whatsappDirectUrl}
        target="_blank"
        rel="noreferrer"
        className="fixed right-5 bottom-5 z-40 inline-flex items-center gap-2 rounded-full bg-emerald-600 px-4 py-3 text-xs font-semibold text-white shadow-lg transition-transform hover:scale-105 hover:bg-emerald-700"
      >
        <MessageCircle className="h-4 w-4" />
        <span>WhatsApp</span>
      </a>

      {/* Test Details Modal */}
      {detailTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="w-full max-w-lg rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <div className="text-xs text-slate-500">{detailTest.category_name}</div>
                <h3 className="mt-1 font-display text-lg font-bold text-slate-900 dark:text-white">
                  {lang === 'hi' && detailTest.name_hi ? detailTest.name_hi : detailTest.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setDetailTest(null)}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-sm">
              <p className="text-slate-600 dark:text-slate-300">{detailTest.description}</p>
              <div className="grid grid-cols-2 gap-3 rounded-lg border border-slate-200 bg-slate-50 p-3.5 dark:border-slate-800 dark:bg-slate-950">
                <div>
                  <div className="text-xs text-slate-500">{t('sampleType')}</div>
                  <div className="font-medium">{detailTest.sample_type}</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">{t('reportingTime')}</div>
                  <div className="font-medium">{detailTest.reporting_time}</div>
                </div>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-500">{t('preparation')}</div>
                <p className="mt-1 text-slate-700 dark:text-slate-300">{detailTest.preparation}</p>
              </div>
              {detailTest.package_items.length > 0 && (
                <div>
                  <div className="text-xs font-semibold text-slate-500">Included Parameters</div>
                  <ul className="mt-1.5 grid grid-cols-1 gap-1 text-xs text-slate-700 sm:grid-cols-2 dark:text-slate-300">
                    {detailTest.package_items.map((pkg, idx) => (
                      <li key={idx} className="flex items-center gap-1.5">
                        <CheckCircle2 className="h-3.5 w-3.5 text-blue-700 dark:text-blue-400" />
                        <span>{pkg}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-slate-200 pt-4 dark:border-slate-800">
              <div className="font-mono text-xl font-bold tabular-nums">
                {formatCurrency(detailTest.discounted_price ?? detailTest.price)}
              </div>
              <button
                type="button"
                onClick={() => {
                  const chosen = detailTest;
                  setDetailTest(null);
                  openBookingFor(chosen);
                }}
                className="rounded-lg bg-blue-700 px-5 py-2.5 text-sm font-semibold text-white hover:bg-blue-800"
              >
                {t('bookNow')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Patient Booking Modal */}
      {bookingTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/60 p-4 backdrop-blur-xs">
          <div className="my-8 w-full max-w-2xl rounded-xl border border-slate-200 bg-white p-6 shadow-xl dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-slate-800">
              <div>
                <div className="text-xs font-medium text-blue-700 dark:text-blue-400">{lab.website_name}</div>
                <h3 className="mt-0.5 font-display text-xl font-bold text-slate-900 dark:text-white">
                  {confirmedResult ? t('bookingConfirmedTitle') : bookingTest.name}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setBookingTest(null)}
                className="rounded-lg p-1.5 text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {confirmedResult ? (
              <div className="mt-5 space-y-5">
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-5 dark:border-emerald-900/50 dark:bg-emerald-950/20">
                  <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400">
                    <CheckCircle2 className="h-5 w-5" />
                    <span className="font-semibold">Appointment Reserved Successfully</span>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-xs text-slate-500">Unique Booking ID</div>
                      <div className="font-mono text-lg font-bold text-slate-900 dark:text-white">
                        {confirmedResult.booking.booking_code}
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-slate-500">Schedule</div>
                      <div className="font-mono text-xs font-medium text-slate-800 dark:text-slate-200">
                        {confirmedResult.booking.booking_date} · {confirmedResult.booking.time_slot}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Real Delivery Status Report (Never simulated) */}
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-800 dark:bg-slate-950">
                  <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Notification Dispatch Status (Real Provider Output)
                  </div>
                  <div className="mt-2.5 space-y-2 text-xs">
                    {Object.entries(confirmedResult.notifications).map(([key, res]) => {
                      if (!res) return null;
                      return (
                        <div key={key} className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-1.5 last:border-0 dark:border-slate-800">
                          <span className="font-medium capitalize text-slate-700 dark:text-slate-300">
                            {key.replace(/([A-Z])/g, ' $1')}
                          </span>
                          <div className="flex items-center gap-2">
                            <StatusIndicator status={res.status || 'failed'} />
                            {res.error && <span className="max-w-xs truncate text-slate-500" title={res.error}>{res.error}</span>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      downloadBookingReceiptPdf(confirmedResult.booking, {
                        name: lab.website_name,
                        address: lab.address,
                        contact: lab.contact_number,
                      })
                    }
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white hover:bg-blue-800"
                  >
                    <Download className="h-4 w-4" />
                    <span>{t('downloadReceipt')}</span>
                  </button>
                  <a
                    href={`https://wa.me/${whatsappDigits}?text=${encodeURIComponent(
                      `Hello ${lab.website_name}, I have booked ${confirmedResult.booking.test_name} (Booking ID: ${confirmedResult.booking.booking_code}) for ${confirmedResult.booking.booking_date} at ${confirmedResult.booking.time_slot}.`
                    )}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 rounded-lg border border-emerald-600 px-4 py-2.5 text-sm font-semibold text-emerald-700 hover:bg-emerald-50 dark:text-emerald-400"
                  >
                    <MessageCircle className="h-4 w-4" />
                    <span>Send Details on WhatsApp</span>
                  </a>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmitBooking} className="mt-5 space-y-4">
                {bookingError && (
                  <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
                    {bookingError}
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('selectDate')} *
                    </label>
                    <div className="relative">
                      <Calendar className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <input
                        type="date"
                        required
                        min={new Date().toISOString().slice(0, 10)}
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-9 text-sm dark:border-slate-700 dark:bg-slate-950"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('selectSlot')} *
                    </label>
                    <div className="relative">
                      <Clock className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <select
                        value={timeSlot}
                        onChange={(e) => setTimeSlot(e.target.value)}
                        className="w-full rounded-lg border border-slate-300 bg-white py-2 pr-3 pl-9 text-sm dark:border-slate-700 dark:bg-slate-950"
                      >
                        {TIME_SLOTS.map((slot) => (
                          <option key={slot} value={slot}>
                            {slot}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                    {t('collectionMode')} *
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      disabled={!bookingTest.home_collection_available}
                      onClick={() => setCollectionType('home_collection')}
                      className={`flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium transition-colors ${
                        collectionType === 'home_collection'
                          ? 'border-blue-700 bg-blue-50 text-blue-800 dark:border-blue-500 dark:bg-blue-950/50 dark:text-blue-300'
                          : 'border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                      } disabled:opacity-40`}
                    >
                      <Home className="h-4 w-4" />
                      <span>{t('homeCollection')}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCollectionType('lab_visit')}
                      className={`flex items-center justify-center gap-2 rounded-lg border px-3 py-2.5 text-sm font-medium transition-colors ${
                        collectionType === 'lab_visit'
                          ? 'border-blue-700 bg-blue-50 text-blue-800 dark:border-blue-500 dark:bg-blue-950/50 dark:text-blue-300'
                          : 'border-slate-200 text-slate-700 dark:border-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <FlaskConical className="h-4 w-4" />
                      <span>{t('labVisit')}</span>
                    </button>
                  </div>
                </div>

                {collectionType === 'home_collection' && (
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('collectionAddress')} *
                    </label>
                    <input
                      type="text"
                      required
                      value={collectionAddress}
                      onChange={(e) => setCollectionAddress(e.target.value)}
                      placeholder="House/Flat No, Street, Landmark, Pincode"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                )}

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('patientName')} *
                    </label>
                    <input
                      type="text"
                      required
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      placeholder="e.g. Rohan Sharma"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('mobileNumber')} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={patientMobile}
                      onChange={(e) => setPatientMobile(e.target.value)}
                      placeholder="+91 98XXXXXXXX"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('emailOptional')}
                    </label>
                    <input
                      type="email"
                      value={patientEmail}
                      onChange={(e) => setPatientEmail(e.target.value)}
                      placeholder="patient@example.com"
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('age')} *
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={120}
                      value={patientAge}
                      onChange={(e) => setPatientAge(e.target.value)}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-xs font-medium text-slate-700 dark:text-slate-300">
                      {t('gender')} *
                    </label>
                    <select
                      value={patientGender}
                      onChange={(e) => setPatientGender(e.target.value as 'Male' | 'Female' | 'Other')}
                      className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm dark:border-slate-700 dark:bg-slate-950"
                    >
                      <option value="Male">{t('male')}</option>
                      <option value="Female">{t('female')}</option>
                      <option value="Other">{t('other')}</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-slate-200 pt-4 dark:border-slate-800">
                  <div>
                    <div className="text-xs text-slate-500">Payable at Sample Collection</div>
                    <div className="font-mono text-xl font-bold tabular-nums">
                      {formatCurrency(bookingTest.discounted_price ?? bookingTest.price)}
                    </div>
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="rounded-lg bg-blue-700 px-6 py-2.5 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
                  >
                    {submitting ? 'Confirming...' : t('confirmBooking')}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
