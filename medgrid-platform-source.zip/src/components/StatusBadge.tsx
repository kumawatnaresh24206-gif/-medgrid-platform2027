import React from 'react';
import { CheckCircle2, Clock, AlertTriangle, XCircle, FileCheck2, FlaskConical } from 'lucide-react';

interface StatusIndicatorProps {
  status: string;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({ status }) => {
  const normalized = status.toLowerCase();

  const map: Record<string, { label: string; colorClass: string; Icon: React.FC<{ className?: string }> }> = {
    active: { label: 'Active', colorClass: 'text-emerald-700 dark:text-emerald-400', Icon: CheckCircle2 },
    sent: { label: 'Delivered', colorClass: 'text-emerald-700 dark:text-emerald-400', Icon: CheckCircle2 },
    paid: { label: 'Paid', colorClass: 'text-emerald-700 dark:text-emerald-400', Icon: CheckCircle2 },
    confirmed: { label: 'Confirmed', colorClass: 'text-blue-700 dark:text-blue-400', Icon: CheckCircle2 },
    completed: { label: 'Completed', colorClass: 'text-emerald-700 dark:text-emerald-400', Icon: FileCheck2 },
    report_ready: { label: 'Report Ready', colorClass: 'text-blue-700 dark:text-blue-400', Icon: FileCheck2 },
    sample_collected: { label: 'Sample Collected', colorClass: 'text-sky-700 dark:text-sky-400', Icon: FlaskConical },
    pending: { label: 'Pending', colorClass: 'text-amber-700 dark:text-amber-400', Icon: Clock },
    partial: { label: 'Partial Paid', colorClass: 'text-amber-700 dark:text-amber-400', Icon: Clock },
    unconfigured: { label: 'Not Configured', colorClass: 'text-amber-700 dark:text-amber-400', Icon: AlertTriangle },
    suspended: { label: 'Suspended', colorClass: 'text-amber-700 dark:text-amber-400', Icon: AlertTriangle },
    deactivated: { label: 'Deactivated', colorClass: 'text-red-700 dark:text-red-400', Icon: XCircle },
    cancelled: { label: 'Cancelled', colorClass: 'text-red-700 dark:text-red-400', Icon: XCircle },
    rejected: { label: 'Rejected', colorClass: 'text-red-700 dark:text-red-400', Icon: XCircle },
    failed: { label: 'Failed', colorClass: 'text-red-700 dark:text-red-400', Icon: XCircle },
    overdue: { label: 'Overdue', colorClass: 'text-red-700 dark:text-red-400', Icon: AlertTriangle },
  };

  const entry = map[normalized] || {
    label: status.replace(/_/g, ' '),
    colorClass: 'text-slate-700 dark:text-slate-300',
    Icon: Clock,
  };
  const IconComp = entry.Icon;

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${entry.colorClass}`}>
      <IconComp className="h-3.5 w-3.5 shrink-0" />
      <span>{entry.label}</span>
    </span>
  );
};
