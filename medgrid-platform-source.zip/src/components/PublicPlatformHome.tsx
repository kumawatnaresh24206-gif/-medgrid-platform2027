import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  Building2,
  CalendarCheck,
  FileText,
  FlaskConical,
  Lock,
  MapPin,
  MessageCircle,
  QrCode,
  Search,
  ShieldCheck,
} from 'lucide-react';
import { apiFetch, formatCurrency, type BookingRecord, type LabRecord } from '../lib/api';
import { useAppSettings } from '../lib/i18n';
import { PLATFORM_IMAGES, resolveLabBanner } from '../lib/assets';
import { downloadBookingReceiptPdf } from '../lib/exports';
import { ThemeLangToolbar } from './ThemeLangToolbar';
import { StatusIndicator } from './StatusBadge';
import { QrCodeModal } from './QrCodeModal';

interface PublicPlatformHomeProps {
  onNavigate: (path: string) => void;
}

interface PublicSearchTestResult {
  id: string;
  lab_id: string;
  name: string;
  name_hi?: string;
  code?: string;
  price: number;
  discounted_price: number | null;
  sample_type: string;
  reporting_time: string;
  is_package: number;
  home_collection_available: number;
  lab_slug: string;
  lab_name: string;
  lab_city: string;
}

export const PublicPlatformHome: React.FC<PublicPlatformHomeProps> = ({ onNavigate }) => {
  const { lang, t } = useAppSettings();
  const [labs, setLabs] = useState<LabRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [testResults, setTestResults] = useState<PublicSearchTestResult[]>([]);
  const [searchingTests, setSearchingTests] = useState(false);

  // Booking tracker state
  const [trackCode, setTrackCode] = useState('');
  const [trackMobile, setTrackMobile] = useState('');
  const [trackingLoading, setTrackingLoading] = useState(false);
  const [trackedBooking, setTrackedBooking] = useState<BookingRecord | null>(null);
  const [trackError, setTrackError] = useState('');

  // QR modal
  const [qrLab, setQrLab] = useState<LabRecord | null>(null);

  useEffect(() => {
    apiFetch<{ labs: LabRecord[] }>('/api/public/labs')
      .then((res) => setLabs(res.labs || []))
      .catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const q = searchQuery.trim();
    if (!q) {
      setTestResults([]);
      setSearchingTests(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setSearchingTests(true);
      apiFetch<{ labs: LabRecord[]; tests: PublicSearchTestResult[] }>(`/api/public/search?q=${encodeURIComponent(q)}`)
        .then((res) => setTestResults(res.tests || []))
        .catch(() => setTestResults([]))
        .finally(() => setSearchingTests(false));
    }, 180);
    return () => window.clearTimeout(timer);
  }, [searchQuery]);

  const handleTrackBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackCode.trim()) return;
    setTrackingLoading(true);
    setTrackError('');
    setTrackedBooking(null);
    try {
      const qs = new URLSearchParams({ code: trackCode.trim() });
      if (trackMobile.trim()) qs.set('mobile', trackMobile.trim());
      const res = await apiFetch<{ booking: BookingRecord }>(`/api/public/bookings/track?${qs.toString()}`);
      setTrackedBooking(res.booking);
    } catch (err: unknown) {
      setTrackError(err instanceof Error ? err.message : 'Unable to locate booking');
    } finally {
      setTrackingLoading(false);
    }
  };

  const filteredLabs = labs.filter(
    (l) =>
      l.website_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.slug.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.tagline.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-950/95">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-8 px-6 py-4">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('/');
            }}
            className="font-display text-xl font-bold tracking-tight text-blue-700 whitespace-nowrap shrink-0 dark:text-blue-400"
          >
            {t('brandName')}
          </a>

          <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex dark:text-slate-300">
            <a href="#directory" className="whitespace-nowrap shrink-0 transition-colors hover:text-blue-700 dark:hover:text-blue-400">
              {t('navDirectory')}
            </a>
            <a href="#capabilities" className="whitespace-nowrap shrink-0 transition-colors hover:text-blue-700 dark:hover:text-blue-400">
              {t('navPlatform')}
            </a>
            <a href="#track" className="whitespace-nowrap shrink-0 transition-colors hover:text-blue-700 dark:hover:text-blue-400">
              {t('navTrack')}
            </a>
            <button
              type="button"
              onClick={() => onNavigate('/lab-admin')}
              className="whitespace-nowrap shrink-0 transition-colors hover:text-blue-700 dark:hover:text-blue-400"
            >
              {t('navLabAdmin')}
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('/super-admin')}
              className="rounded-lg bg-blue-700 px-4 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
            >
              {t('navSuperAdmin')}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="border-b border-slate-200 bg-slate-50/70 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="mx-auto max-w-7xl px-6 py-12 lg:py-16">
          <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
            <span className="text-xs font-medium tracking-wide text-blue-700 dark:text-blue-400">
              {t('heroKicker')}
            </span>
            <ThemeLangToolbar />
          </div>

          <div className="grid grid-cols-1 items-stretch gap-10 lg:grid-cols-12">
            <div className="flex flex-col justify-between lg:col-span-6">
              <div>
                <h1 className="font-display text-3xl font-bold tracking-tight text-slate-900 text-balance sm:text-5xl dark:text-white">
                  {t('heroTitle')}
                </h1>
                <p className="mt-5 max-w-xl text-base leading-relaxed text-slate-600 dark:text-slate-300">
                  {t('heroSubtitle')}
                </p>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onNavigate('/super-admin')}
                    className="inline-flex items-center gap-2 rounded-lg bg-blue-700 px-5 py-3 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
                  >
                    <span>{t('heroPrimaryCta')}</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('/lab-admin')}
                    className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-slate-800 whitespace-nowrap transition-colors hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:hover:bg-slate-800"
                  >
                    <span>{t('heroSecondaryCta')}</span>
                  </button>
                </div>
              </div>

              <div className="mt-10 grid grid-cols-3 gap-4 border-t border-slate-200 pt-6 dark:border-slate-800">
                <div>
                  <div className="font-mono text-2xl font-semibold text-slate-900 tabular-nums dark:text-white">
                    {labs.length}
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">Active Lab Websites</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-semibold text-slate-900 tabular-nums dark:text-white">
                    100%
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">Tenant Data Isolation</div>
                </div>
                <div>
                  <div className="font-mono text-2xl font-semibold text-slate-900 tabular-nums dark:text-white">
                    2-Way
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">WhatsApp & SMTP Alerts</div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="relative h-full min-h-[280px] overflow-hidden rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-900">
                <img
                  src={PLATFORM_IMAGES.heroDiagnosticLab}
                  alt="Modern automated diagnostic laboratory interior"
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover lg:h-full"
                />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950/85 via-slate-950/40 to-transparent p-6 text-white">
                  <div className="text-xs font-medium text-blue-200">Independent Tenant Portals</div>
                  <div className="mt-1 font-display text-lg font-semibold">
                    Every lab receives a dedicated /lab/slug website, QR code, and owner console.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Active Laboratories Directory */}
      <section id="directory" className="mx-auto max-w-7xl px-6 py-14">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              {t('activeLabsHeading')}
            </h2>
            <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400">{t('activeLabsSub')}</p>
          </div>
          <div className="relative w-full sm:w-96">
            <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search labs, city, or tests (e.g. CBC, Thyroid, Lipid)..."
              className="w-full rounded-lg border border-slate-300 bg-white py-2.5 pr-3 pl-9 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        {/* Global Cross-Lab Test Search Results */}
        {searchQuery.trim() && (
          <div className="mt-6 rounded-xl border border-blue-200 bg-blue-50/40 p-5 dark:border-blue-900/50 dark:bg-blue-950/20">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 dark:text-white">
                <FlaskConical className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                <span>
                  {searchingTests
                    ? 'Searching diagnostic tests across laboratories...'
                    : `Matching Tests & Health Packages (${testResults.length})`}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="text-xs font-medium text-blue-700 hover:underline dark:text-blue-400"
              >
                Clear search
              </button>
            </div>
            {!searchingTests && testResults.length > 0 && (
              <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                {testResults.map((item) => {
                  const finalPrice = item.discounted_price ?? item.price;
                  return (
                    <div
                      key={item.id}
                      className="flex flex-col justify-between rounded-lg border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div className="font-semibold text-sm text-slate-900 dark:text-white">
                            {lang === 'hi' && item.name_hi ? item.name_hi : item.name}
                          </div>
                          <span className="font-mono text-sm font-bold text-blue-700 tabular-nums dark:text-blue-400">
                            {formatCurrency(finalPrice)}
                          </span>
                        </div>
                        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                          {item.lab_name} · {item.lab_city}
                        </div>
                        <div className="mt-2 text-xs text-slate-600 dark:text-slate-300">
                          {item.sample_type} · Report in {item.reporting_time}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onNavigate(`/lab/${item.lab_slug}?q=${encodeURIComponent(item.name)}`)}
                        className="mt-3 inline-flex items-center justify-center gap-1.5 rounded-lg bg-blue-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-800"
                      >
                        <span>Book at {item.lab_name}</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
            {!searchingTests && testResults.length === 0 && (
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">
                No diagnostic tests matched "{searchQuery}". Try searching "CBC", "Thyroid", "Lipid", or "Full Body".
              </p>
            )}
          </div>
        )}

        {error && (
          <div className="mt-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
            {error}
          </div>
        )}

        {loading ? (
          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-80 animate-pulse rounded-xl border border-slate-200 bg-slate-100 dark:border-slate-800 dark:bg-slate-900" />
            ))}
          </div>
        ) : filteredLabs.length === 0 ? (
          <div className="mt-8 rounded-xl border border-slate-200 p-10 text-center dark:border-slate-800">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              {testResults.length > 0
                ? 'See matching tests above, or clear search to browse all active laboratories.'
                : 'No active laboratories matched your search. Create a new laboratory from the Super Admin dashboard.'}
            </p>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredLabs.map((lab) => {
              const liveUrl = `${window.location.origin}/lab/${lab.slug}`;
              return (
                <article
                  key={lab.id}
                  className="flex flex-col overflow-hidden rounded-xl border border-slate-200 bg-white transition-colors hover:border-blue-300 dark:border-slate-800 dark:bg-slate-900 dark:hover:border-blue-700"
                >
                  <div className="relative h-44 overflow-hidden bg-slate-100 dark:bg-slate-800">
                    <img
                      src={resolveLabBanner(lab.banner_url, lab.slug)}
                      alt={lab.website_name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex flex-1 flex-col justify-between p-6">
                    <div>
                      <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <span className="truncate font-mono">/lab/{lab.slug}</span>
                        <span>{lab.is_demo ? t('demoSampleLabel') : t('liveRecordLabel')}</span>
                      </div>
                      <h3 className="mt-2 font-display text-lg font-semibold text-slate-900 dark:text-white">
                        {lab.website_name}
                      </h3>
                      <p className="mt-1.5 line-clamp-2 text-sm text-slate-600 dark:text-slate-300">
                        {lab.tagline}
                      </p>
                      <div className="mt-4 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                        <MapPin className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">{lab.city}</span>
                        <span aria-hidden="true">·</span>
                        <span className="tabular-nums">{lab.test_count || 0} Tests</span>
                      </div>
                    </div>

                    <div className="mt-6 flex items-center gap-2 border-t border-slate-100 pt-4 dark:border-slate-800">
                      <button
                        type="button"
                        onClick={() => onNavigate(`/lab/${lab.slug}`)}
                        className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-blue-700 px-3 py-2 text-xs font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800"
                      >
                        <span>{t('visitWebsite')}</span>
                        <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setQrLab(lab)}
                        className="inline-flex items-center justify-center rounded-lg border border-slate-200 p-2 text-slate-600 transition-colors hover:bg-slate-50 hover:text-slate-900 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                        title={`QR code for ${liveUrl}`}
                        aria-label={`View QR code for ${lab.website_name}`}
                      >
                        <QrCode className="h-4 w-4" />
                      </button>
                      <a
                        href={`https://wa.me/${lab.whatsapp_number.replace(/[^\d]/g, '')}?text=${encodeURIComponent(
                          `Hello ${lab.website_name}, I would like to inquire about diagnostic test booking.`
                        )}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center justify-center rounded-lg border border-emerald-200 bg-emerald-50 p-2 text-emerald-700 transition-colors hover:bg-emerald-100 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-400"
                        title="Chat on WhatsApp"
                        aria-label={`WhatsApp ${lab.website_name}`}
                      >
                        <MessageCircle className="h-4 w-4" />
                      </a>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Capabilities Section */}
      <section id="capabilities" className="border-y border-slate-200 bg-slate-50/70 py-14 dark:border-slate-800 dark:bg-slate-900/30">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Platform Architecture
          </h2>
          <p className="mt-1.5 max-w-2xl text-sm text-slate-600 dark:text-slate-400">
            Built for diagnostic SaaS operators selling branded websites to pathology and imaging centers.
          </p>

          <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <Building2 className="h-5 w-5 text-blue-700 dark:text-blue-400" />
              <h3 className="mt-4 font-display text-base font-semibold">01. Instant Lab Provisioning</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                Create a laboratory account to launch its public /lab/slug portal, QR code, categories, and invite credentials.
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <ShieldCheck className="h-5 w-5 text-blue-700 dark:text-blue-400" />
              <h3 className="mt-4 font-display text-base font-semibold">02. Strict Tenant Isolation</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                Role-scoped middleware ensures lab owners access only their own tests, patient records, and bookings.
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <MessageCircle className="h-5 w-5 text-blue-700 dark:text-blue-400" />
              <h3 className="mt-4 font-display text-base font-semibold">03. Real SMTP & WhatsApp API</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                Dispatches real Nodemailer emails and Meta WhatsApp Cloud API messages with honest delivery status logs.
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <FileText className="h-5 w-5 text-blue-700 dark:text-blue-400" />
              <h3 className="mt-4 font-display text-base font-semibold">04. PDF Invoices & Excel</h3>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
                Generate client-ready PDF booking receipts, SaaS subscription invoices, and multi-sheet Excel exports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Check Booking Status Section */}
      <section id="track" className="mx-auto max-w-7xl px-6 py-14">
        <div className="grid grid-cols-1 gap-8 rounded-xl border border-slate-200 bg-white p-6 sm:p-10 lg:grid-cols-12 dark:border-slate-800 dark:bg-slate-900">
          <div className="lg:col-span-5">
            <CalendarCheck className="h-6 w-6 text-blue-700 dark:text-blue-400" />
            <h2 className="mt-3 font-display text-2xl font-bold text-slate-900 dark:text-white">
              {t('trackBookingTitle')}
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">{t('trackBookingSub')}</p>
            <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
              Demo IDs to try: <span className="font-mono text-slate-800 dark:text-slate-200">MG-HEAL-1001</span> or{' '}
              <span className="font-mono text-slate-800 dark:text-slate-200">MG-MODE-1001</span>
            </p>
          </div>

          <div className="lg:col-span-7">
            <form onSubmit={handleTrackBooking} className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <input
                type="text"
                required
                value={trackCode}
                onChange={(e) => setTrackCode(e.target.value)}
                placeholder={t('bookingIdPlaceholder')}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 font-mono text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              <input
                type="text"
                value={trackMobile}
                onChange={(e) => setTrackMobile(e.target.value)}
                placeholder={t('mobileOptionalPlaceholder')}
                className="rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900 focus:border-blue-600 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
              <button
                type="submit"
                disabled={trackingLoading}
                className="rounded-lg bg-blue-700 px-4 py-2.5 text-sm font-semibold text-white whitespace-nowrap transition-colors hover:bg-blue-800 disabled:opacity-60"
              >
                {trackingLoading ? 'Checking...' : t('checkStatusBtn')}
              </button>
            </form>

            {trackError && (
              <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700 dark:border-red-900/50 dark:bg-red-950/30 dark:text-red-300">
                {trackError}
              </div>
            )}

            {trackedBooking && (
              <div className="mt-5 rounded-xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-800 dark:bg-slate-950">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3 dark:border-slate-800">
                  <div>
                    <div className="font-mono text-sm font-semibold text-slate-900 dark:text-white">
                      {trackedBooking.booking_code}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {trackedBooking.website_name} · {trackedBooking.is_demo ? 'Demo Sample' : 'Live Patient Booking'}
                    </div>
                  </div>
                  <StatusIndicator status={trackedBooking.status} />
                </div>
                <div className="mt-4 grid grid-cols-2 gap-4 text-sm sm:grid-cols-4">
                  <div>
                    <div className="text-xs text-slate-500">Patient</div>
                    <div className="font-medium">{trackedBooking.patient_name}</div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Test</div>
                    <div className="font-medium">{trackedBooking.test_name}</div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Appointment</div>
                    <div className="font-mono text-xs tabular-nums">
                      {trackedBooking.booking_date} · {trackedBooking.time_slot}
                    </div>
                  </div>
                  <div className="flex items-end justify-end">
                    <button
                      type="button"
                      onClick={() =>
                        downloadBookingReceiptPdf(trackedBooking, {
                          name: trackedBooking.website_name || 'Diagnostic Lab',
                          address: trackedBooking.lab_address || '',
                          contact: trackedBooking.lab_contact || '',
                        })
                      }
                      className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
                    >
                      {t('downloadReceipt')}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 bg-slate-50 py-10 dark:border-slate-800 dark:bg-slate-950">
        <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-6 px-6 sm:flex-row sm:items-center">
          <div>
            <div className="font-display text-base font-bold text-slate-900 dark:text-white">MedGrid Diagnostics SaaS</div>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Multi-tenant laboratory website builder & patient booking infrastructure.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-5 text-xs font-medium text-slate-600 dark:text-slate-400">
            <button type="button" onClick={() => onNavigate('/super-admin')} className="inline-flex items-center gap-1 hover:text-blue-700">
              <Lock className="h-3.5 w-3.5" />
              <span>Super Admin Login</span>
            </button>
            <button type="button" onClick={() => onNavigate('/lab-admin')} className="hover:text-blue-700">
              Lab Owner Login
            </button>
            <a href="#directory" className="hover:text-blue-700">
              Public Labs
            </a>
          </div>
        </div>
      </footer>

      <QrCodeModal
        open={Boolean(qrLab)}
        onClose={() => setQrLab(null)}
        labName={qrLab?.website_name || ''}
        url={qrLab ? `${window.location.origin}/lab/${qrLab.slug}` : ''}
        customDomain={qrLab?.custom_domain}
      />
    </div>
  );
};
