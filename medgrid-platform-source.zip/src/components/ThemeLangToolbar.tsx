import React from 'react';
import { Globe, Moon, Sun } from 'lucide-react';
import { useAppSettings } from '../lib/i18n';

interface ThemeLangToolbarProps {
  compact?: boolean;
}

export const ThemeLangToolbar: React.FC<ThemeLangToolbarProps> = ({ compact = false }) => {
  const { lang, setLang, theme, toggleTheme } = useAppSettings();

  return (
    <div className="inline-flex items-center gap-2">
      <div className="inline-flex items-center rounded-lg border border-slate-200 bg-white p-0.5 dark:border-slate-800 dark:bg-slate-900">
        <button
          type="button"
          onClick={() => setLang('en')}
          className={`flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap transition-colors ${
            lang === 'en'
              ? 'bg-blue-700 text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
        >
          {!compact && <Globe className="h-3.5 w-3.5" />}
          <span>EN</span>
        </button>
        <button
          type="button"
          onClick={() => setLang('hi')}
          className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap transition-colors ${
            lang === 'hi'
              ? 'bg-blue-700 text-white'
              : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100'
          }`}
        >
          हिन्दी
        </button>
      </div>

      <button
        type="button"
        onClick={toggleTheme}
        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 whitespace-nowrap transition-colors hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
        aria-label="Toggle color theme"
      >
        {theme === 'light' ? <Moon className="h-3.5 w-3.5" /> : <Sun className="h-3.5 w-3.5" />}
        {!compact && <span>{theme === 'light' ? 'Dark' : 'Light'}</span>}
      </button>
    </div>
  );
};
