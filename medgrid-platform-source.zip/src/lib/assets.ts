import heroDiagnosticLab from '../assets/images/hero_diagnostic_lab_1794644019030.jpg';
import labHomeCollection from '../assets/images/lab_home_collection_1794644020012.jpg';
import labPathologyMicroscope from '../assets/images/lab_pathology_microscope_1794644019999.jpg';
import avatarSuperAdmin from '../assets/images/avatar_super_admin_1794644020363.jpg';

export const PLATFORM_IMAGES = {
  heroDiagnosticLab,
  labHomeCollection,
  labPathologyMicroscope,
  avatarSuperAdmin,
};

export function resolveLabBanner(bannerUrl?: string, slug?: string): string {
  if (bannerUrl && !bannerUrl.startsWith('/src/assets/')) {
    return bannerUrl;
  }
  if (slug === 'modern-diagnostics') return labPathologyMicroscope;
  if (slug === 'care-lab') return labHomeCollection;
  return heroDiagnosticLab;
}
