import { jsPDF } from 'jspdf';
import * as XLSX from 'xlsx';
import type { BookingRecord, LabPaymentRecord, DiagnosticTest } from './api';

export function downloadBookingReceiptPdf(booking: BookingRecord, labInfo: { name: string; address: string; contact: string }) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  doc.setFillColor(29, 78, 216);
  doc.rect(0, 0, 595, 92, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.text(labInfo.name || 'Diagnostic Laboratory', 40, 44);
  doc.setFontSize(10);
  doc.text(`${labInfo.address} | Contact: ${labInfo.contact}`, 40, 66);

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(15);
  doc.text('DIAGNOSTIC TEST BOOKING RECEIPT', 40, 130);

  doc.setDrawColor(226, 232, 240);
  doc.line(40, 144, 555, 144);

  const rows: Array<[string, string]> = [
    ['Booking ID', booking.booking_code],
    ['Status', booking.status.replace('_', ' ').toUpperCase()],
    ['Patient Name', `${booking.patient_name} (${booking.patient_age} yrs, ${booking.patient_gender})`],
    ['Mobile Number', booking.patient_mobile],
    ['Email', booking.patient_email || 'Not provided'],
    ['Diagnostic Test', booking.test_name],
    ['Appointment Date', booking.booking_date],
    ['Time Slot', booking.time_slot],
    ['Collection Mode', booking.collection_type === 'home_collection' ? 'Home Sample Collection' : 'Laboratory Visit'],
    ['Collection Address', booking.collection_address || labInfo.address],
    ['Total Amount', `INR ${Number(booking.price).toLocaleString('en-IN')}`],
    ['Record Type', booking.is_demo ? 'Demonstration Sample' : 'Verified Patient Booking'],
  ];

  let y = 174;
  rows.forEach(([label, value]) => {
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(label, 40, y);
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(11);
    const wrapped = doc.splitTextToSize(String(value), 330);
    doc.text(wrapped, 200, y);
    y += Math.max(24, wrapped.length * 16);
  });

  doc.setDrawColor(226, 232, 240);
  doc.line(40, y + 10, 555, y + 10);
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(`Generated on ${new Date().toLocaleString()} via MedGrid Diagnostics Platform`, 40, y + 32);

  doc.save(`${booking.booking_code}-receipt.pdf`);
}

export function downloadLabInvoicePdf(payment: LabPaymentRecord) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 595, 92, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(20);
  doc.text('MedGrid SaaS Platform', 40, 44);
  doc.setFontSize(10);
  doc.text('Commercial Laboratory Website & Subscription Invoice', 40, 66);

  doc.setTextColor(15, 23, 42);
  doc.setFontSize(16);
  doc.text(`INVOICE #${payment.invoice_number}`, 40, 134);

  const lines: Array<[string, string]> = [
    ['Billed Laboratory', payment.lab_name || payment.lab_id],
    ['Lab Owner', `${payment.owner_name || ''} (${payment.owner_email || ''})`],
    ['Location', payment.city || 'India'],
    ['Subscription Plan', payment.subscription_plan || 'Standard'],
    ['Payment Type', payment.payment_type.replace('_', ' ').toUpperCase()],
    ['Payment Method', payment.payment_method],
    ['Payment Status', payment.status.toUpperCase()],
    ['Amount Paid', `INR ${Number(payment.amount).toLocaleString('en-IN')}`],
    ['Date', payment.paid_at ? new Date(payment.paid_at).toLocaleDateString() : new Date(payment.created_at).toLocaleDateString()],
    ['Notes', payment.notes || 'Platform license & onboarding'],
  ];

  let y = 175;
  lines.forEach(([k, v]) => {
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(k, 40, y);
    doc.setFontSize(11);
    doc.setTextColor(15, 23, 42);
    doc.text(String(v), 200, y);
    y += 26;
  });

  doc.save(`${payment.invoice_number}.pdf`);
}

export function exportBookingsToExcel(bookings: BookingRecord[], fileName = 'bookings-report.xlsx') {
  const rows = bookings.map((b) => ({
    'Booking ID': b.booking_code,
    'Lab': b.website_name || b.lab_name || '',
    'Test Name': b.test_name,
    'Patient Name': b.patient_name,
    'Mobile': b.patient_mobile,
    'Email': b.patient_email || '',
    'Age': b.patient_age,
    'Gender': b.patient_gender,
    'Collection Mode': b.collection_type === 'home_collection' ? 'Home Collection' : 'Lab Visit',
    'Address': b.collection_address || '',
    'Date': b.booking_date,
    'Time Slot': b.time_slot,
    'Price (INR)': b.price,
    'Status': b.status,
    'Dataset': b.is_demo ? 'Demo Sample' : 'Live Patient',
    'Created At': b.created_at,
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Bookings');
  XLSX.writeFile(wb, fileName);
}

export function exportTestsToExcel(tests: DiagnosticTest[], fileName = 'tests-catalog.xlsx') {
  const rows = tests.map((t) => ({
    'Code': t.code || '',
    'Test Name': t.name,
    'Category': t.category_name || '',
    'Price (INR)': t.price,
    'Offer Price (INR)': t.discounted_price || t.price,
    'Sample Type': t.sample_type,
    'Reporting Time': t.reporting_time,
    'Package': t.is_package ? 'Yes' : 'No',
    'Preparation': t.preparation,
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Diagnostic Tests');
  XLSX.writeFile(wb, fileName);
}

export function exportPatientsToExcel(
  patients: Array<Record<string, unknown>>,
  fileName = 'patients-directory.xlsx'
) {
  const ws = XLSX.utils.json_to_sheet(patients);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Patients');
  XLSX.writeFile(wb, fileName);
}

export function exportSalesToExcel(
  labs: Array<{
    website_name: string;
    owner_name: string;
    owner_email: string;
    subscription_plan: string;
    subscription_expiry: string;
    selling_price: number;
    amount_paid: number;
    pending_amount: number;
    status: string;
  }>,
  fileName = 'platform-sales-revenue.xlsx'
) {
  const rows = labs.map((l) => ({
    'Laboratory': l.website_name,
    'Owner Name': l.owner_name,
    'Owner Email': l.owner_email,
    'Plan': l.subscription_plan,
    'Expiry Date': l.subscription_expiry,
    'Selling Price (INR)': l.selling_price,
    'Amount Paid (INR)': l.amount_paid,
    'Pending Balance (INR)': l.pending_amount,
    'Account Status': l.status,
  }));
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Lab Sales');
  XLSX.writeFile(wb, fileName);
}

