import React, { createContext, useContext, useEffect, useState } from 'react';

export type Language = 'en' | 'hi';
export type ThemeMode = 'light' | 'dark';

const translations: Record<Language, Record<string, string>> = {
  en: {
    brandName: 'MedGrid',
    navDirectory: 'Laboratories',
    navPlatform: 'Capabilities',
    navTrack: 'Track Booking',
    navLabAdmin: 'Lab Owner',
    navSuperAdmin: 'Super Admin',
    heroKicker: 'Multi-Tenant Diagnostic Laboratory SaaS',
    heroTitle: 'Launch and manage independent diagnostic laboratory websites.',
    heroSubtitle:
      'Provision branded patient booking portals, isolated test catalogs, WhatsApp and email alerts, and SaaS billing from a single multi-lab console.',
    heroPrimaryCta: 'Open Super Admin',
    heroSecondaryCta: 'Lab Owner Portal',
    activeLabsHeading: 'Active Diagnostic Laboratories',
    activeLabsSub: 'Each laboratory runs an isolated website, test catalog, and booking workflow.',
    visitWebsite: 'Open Website',
    bookTest: 'Book Test',
    searchTestsPlaceholder: 'Search tests, packages, or codes...',
    allCategories: 'All Categories',
    packagesOnly: 'Health Packages',
    homeCollection: 'Home Sample Collection',
    labVisit: 'Lab Visit',
    preparation: 'Preparation',
    sampleType: 'Sample',
    reportingTime: 'Report Time',
    bookNow: 'Book Test',
    trackBookingTitle: 'Check Booking Status',
    trackBookingSub: 'Enter your Booking ID to view real-time sample status or download your receipt.',
    bookingIdPlaceholder: 'e.g. MG-HEAL-1001',
    mobileOptionalPlaceholder: 'Registered mobile (optional)',
    checkStatusBtn: 'Check Status',
    whatsappContact: 'WhatsApp Lab',
    patientName: 'Patient Full Name',
    mobileNumber: 'Mobile Number',
    emailOptional: 'Email Address (Optional)',
    age: 'Age',
    gender: 'Gender',
    male: 'Male',
    female: 'Female',
    other: 'Other',
    selectDate: 'Preferred Date',
    selectSlot: 'Available Time Slot',
    collectionMode: 'Sample Collection Mode',
    collectionAddress: 'Home Collection Address',
    confirmBooking: 'Confirm Test Booking',
    bookingConfirmedTitle: 'Booking Confirmed',
    downloadReceipt: 'Download PDF Receipt',
    cancelBooking: 'Cancel Booking',
    demoSampleLabel: 'Demo Sample',
    liveRecordLabel: 'Live Record',
    overview: 'Overview',
    laboratories: 'Laboratories',
    bookings: 'Bookings',
    salesInvoices: 'Sales & Invoices',
    notificationsApi: 'Notifications & API',
    auditBackups: 'Audit & Backups',
    testsPackages: 'Tests & Packages',
    patients: 'Patients',
    labProfile: 'Lab Profile & QR',
    deliveryLogs: 'Delivery Logs',
    signOut: 'Sign Out',
    createLab: 'Create New Lab',
    addTest: 'Add Diagnostic Test',
    exportExcel: 'Export Excel',
  },
  hi: {
    brandName: 'मेडग्रिड',
    navDirectory: 'प्रयोगशालाएं',
    navPlatform: 'सुविधाएं',
    navTrack: 'बुकिंग ट्रैक करें',
    navLabAdmin: 'लैब एडमिन',
    navSuperAdmin: 'सुपर एडमिन',
    heroKicker: 'मल्टी-टेनेंट डायग्नोस्टिक लैब SaaS प्लेटफॉर्म',
    heroTitle: 'स्वतंत्र डायग्नोस्टिक लैब वेबसाइट्स बनाएं और प्रबंधित करें।',
    heroSubtitle:
      'हर लैब के लिए अलग वेबसाइट, टेस्ट कैटलॉग, व्हाट्सएप और ईमेल नोटिफिकेशन, और सब्सक्रिप्शन बिलिंग एक ही सुरक्षित प्लेटफॉर्म से चलाएं।',
    heroPrimaryCta: 'सुपर एडमिन खोलें',
    heroSecondaryCta: 'लैब ओनर पोर्टल',
    activeLabsHeading: 'सक्रिय डायग्नोस्टिक प्रयोगशालाएं',
    activeLabsSub: 'प्रत्येक प्रयोगशाला की अपनी स्वतंत्र वेबसाइट, टेस्ट सूची और बुकिंग प्रणाली है।',
    visitWebsite: 'वेबसाइट खोलें',
    bookTest: 'टेस्ट बुक करें',
    searchTestsPlaceholder: 'टेस्ट, पैकेज या कोड खोजें...',
    allCategories: 'सभी श्रेणियां',
    packagesOnly: 'हेल्थ पैकेज',
    homeCollection: 'होम सैंपल कलेक्शन',
    labVisit: 'लैब विजिट',
    preparation: 'तैयारी निर्देश',
    sampleType: 'सैंपल',
    reportingTime: 'रिपोर्ट समय',
    bookNow: 'टेस्ट बुक करें',
    trackBookingTitle: 'बुकिंग स्थिति जांचें',
    trackBookingSub: 'अपनी बुकिंग आईडी दर्ज करें और रियल-टाइम स्टेटस या पीडीएफ रसीद प्राप्त करें।',
    bookingIdPlaceholder: 'जैसे MG-HEAL-1001',
    mobileOptionalPlaceholder: 'पंजीकृत मोबाइल नंबर (वैकल्पिक)',
    checkStatusBtn: 'स्थिति जांचें',
    whatsappContact: 'व्हाट्सएप संपर्क',
    patientName: 'मरीज का पूरा नाम',
    mobileNumber: 'मोबाइल नंबर',
    emailOptional: 'ईमेल पता (वैकल्पिक)',
    age: 'आयु',
    gender: 'लिंग',
    male: 'पुरुष',
    female: 'महिला',
    other: 'अन्य',
    selectDate: 'दिनांक चुनें',
    selectSlot: 'उपलब्ध समय स्लॉट',
    collectionMode: 'सैंपल संग्रह माध्यम',
    collectionAddress: 'होम कलेक्शन का पूरा पता',
    confirmBooking: 'टेस्ट बुकिंग कन्फर्म करें',
    bookingConfirmedTitle: 'बुकिंग कन्फर्म हो गई',
    downloadReceipt: 'PDF रसीद डाउनलोड करें',
    cancelBooking: 'बुकिंग रद्द करें',
    demoSampleLabel: 'डेमो सैंपल',
    liveRecordLabel: 'लाइव रिकॉर्ड',
    overview: 'डैशबोर्ड',
    laboratories: 'प्रयोगशालाएं',
    bookings: 'बुकिंग्स',
    salesInvoices: 'बिक्री और चालान',
    notificationsApi: 'नोटिफिकेशन और API',
    auditBackups: 'ऑडिट और बैकअप',
    testsPackages: 'टेस्ट और पैकेज',
    patients: 'मरीज रिकॉर्ड',
    labProfile: 'लैब प्रोफाइल और QR',
    deliveryLogs: 'संदेश लॉग',
    signOut: 'लॉग आउट',
    createLab: 'नई लैब बनाएं',
    addTest: 'नया टेस्ट जोड़ें',
    exportExcel: 'Excel निर्यात',
  },
};

interface AppSettingsContextValue {
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: string) => string;
  theme: ThemeMode;
  toggleTheme: () => void;
}

const AppSettingsContext = createContext<AppSettingsContextValue | null>(null);

export const AppSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem('medgrid_lang');
    return saved === 'hi' ? 'hi' : 'en';
  });

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('medgrid_theme');
    return saved === 'dark' ? 'dark' : 'light';
  });

  useEffect(() => {
    localStorage.setItem('medgrid_lang', lang);
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('medgrid_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const setLang = (l: Language) => setLangState(l);
  const toggleTheme = () => setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  const t = (key: string) => translations[lang][key] || translations.en[key] || key;

  return React.createElement(
    AppSettingsContext.Provider,
    { value: { lang, setLang, t, theme, toggleTheme } },
    children
  );
};

export function useAppSettings() {
  const ctx = useContext(AppSettingsContext);
  if (!ctx) throw new Error('useAppSettings must be used inside AppSettingsProvider');
  return ctx;
}
