export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'super_admin' | 'lab_owner';
  labId: string | null;
  permissions: string[];
}

export interface LabRecord {
  id: string;
  slug: string;
  name: string;
  website_name: string;
  custom_domain: string;
  logo_url: string;
  banner_url: string;
  address: string;
  city: string;
  contact_number: string;
  whatsapp_number: string;
  owner_name: string;
  owner_email: string;
  theme_color: string;
  tagline: string;
  status: 'active' | 'suspended' | 'deactivated';
  subscription_plan: string;
  selling_price: number;
  amount_paid: number;
  pending_amount: number;
  subscription_start: string;
  subscription_expiry: string;
  auto_suspend_on_expiry: number;
  is_demo: number;
  created_at: string;
  permissions?: string[];
  invite_pending?: boolean;
  invite_token?: string | null;
  test_count?: number;
  booking_count?: number;
}

export interface TestCategory {
  id: string;
  lab_id: string;
  name: string;
  name_hi?: string;
  description?: string;
  sort_order: number;
}

export interface DiagnosticTest {
  id: string;
  lab_id: string;
  category_id: string | null;
  category_name?: string;
  category_name_hi?: string;
  name: string;
  name_hi?: string;
  code?: string;
  price: number;
  discounted_price?: number | null;
  description: string;
  preparation: string;
  sample_type: string;
  reporting_time: string;
  is_package: number;
  package_items: string[];
  home_collection_available: number;
  is_active: number;
  is_demo: number;
  created_at: string;
}

export interface BookingRecord {
  id: string;
  booking_code: string;
  lab_id: string;
  lab_name?: string;
  lab_slug?: string;
  website_name?: string;
  lab_address?: string;
  lab_contact?: string;
  lab_whatsapp?: string;
  test_id: string | null;
  test_name: string;
  price: number;
  patient_name: string;
  patient_mobile: string;
  patient_email?: string;
  patient_age: number;
  patient_gender: string;
  collection_type: 'home_collection' | 'lab_visit';
  collection_address?: string;
  booking_date: string;
  time_slot: string;
  status: 'pending' | 'confirmed' | 'sample_collected' | 'report_ready' | 'completed' | 'cancelled' | 'rejected';
  notes?: string;
  is_demo: number;
  created_at: string;
  updated_at: string;
}

export interface LabPaymentRecord {
  id: string;
  lab_id: string;
  lab_name?: string;
  owner_name?: string;
  owner_email?: string;
  city?: string;
  subscription_plan?: string;
  invoice_number: string;
  amount: number;
  payment_type: string;
  payment_method: string;
  status: string;
  notes?: string;
  paid_at?: string;
  created_at: string;
}

export interface NotificationLogRecord {
  id: string;
  lab_id: string | null;
  lab_name?: string;
  booking_id: string | null;
  channel: 'email' | 'whatsapp';
  event_type: string;
  recipient: string;
  subject?: string;
  message_preview: string;
  status: 'sent' | 'failed' | 'unconfigured';
  provider_response?: string;
  error_message?: string;
  created_at: string;
}

export interface AuditLogRecord {
  id: string;
  actor_id?: string;
  actor_email?: string;
  actor_role?: string;
  lab_id?: string;
  action: string;
  details?: string;
  ip_address?: string;
  created_at: string;
}

export async function apiFetch<T = unknown>(url: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    ...(options.body ? { 'Content-Type': 'application/json' } : {}),
    ...(options.headers as Record<string, string> | undefined),
  };

  const response = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  const text = await response.text();
  let data: Record<string, unknown> = {};
  try {
    data = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    data = { error: text || 'Unexpected server response' };
  }

  if (!response.ok) {
    throw new Error((data.error as string) || `Request failed with status ${response.status}`);
  }

  return data as T;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(Number(amount || 0));
}
