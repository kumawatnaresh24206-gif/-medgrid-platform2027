import nodemailer from 'nodemailer';
import { db, generateId } from './db.ts';

export interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  from_name: string;
  from_email: string;
}

export interface WhatsAppConfig {
  provider: 'meta_cloud_api' | 'twilio';
  phone_number_id: string;
  access_token: string;
  business_account_id: string;
  api_version: string;
  twilio_sid: string;
  twilio_token: string;
  twilio_from: string;
}

export type NotificationTemplates = Record<string, string>;

export function getSetting<T>(key: string, fallback: T): T {
  const row = db.prepare('SELECT value FROM platform_settings WHERE key = ?').get(key) as { value: string } | undefined;
  if (!row) return fallback;
  try {
    return JSON.parse(row.value) as T;
  } catch {
    return fallback;
  }
}

export function getEffectiveSmtpConfig(): SmtpConfig {
  const saved = getSetting<Partial<SmtpConfig>>('smtp_config', {});
  return {
    host: saved.host || process.env.SMTP_HOST || '',
    port: Number(saved.port || process.env.SMTP_PORT || 587),
    secure: Boolean(saved.secure ?? (process.env.SMTP_SECURE === 'true')),
    user: saved.user || process.env.SMTP_USER || '',
    pass: saved.pass || process.env.SMTP_PASS || '',
    from_name: saved.from_name || process.env.SMTP_FROM_NAME || 'MedGrid Diagnostics',
    from_email: saved.from_email || process.env.SMTP_FROM || saved.user || process.env.SMTP_USER || '',
  };
}

export function getEffectiveWhatsAppConfig(): WhatsAppConfig {
  const saved = getSetting<Partial<WhatsAppConfig>>('whatsapp_config', {});
  return {
    provider: saved.provider || 'meta_cloud_api',
    phone_number_id: saved.phone_number_id || process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    access_token: saved.access_token || process.env.WHATSAPP_ACCESS_TOKEN || '',
    business_account_id: saved.business_account_id || process.env.WHATSAPP_BUSINESS_ACCOUNT_ID || '',
    api_version: saved.api_version || process.env.WHATSAPP_API_VERSION || 'v21.0',
    twilio_sid: saved.twilio_sid || process.env.TWILIO_ACCOUNT_SID || '',
    twilio_token: saved.twilio_token || process.env.TWILIO_AUTH_TOKEN || '',
    twilio_from: saved.twilio_from || process.env.TWILIO_WHATSAPP_FROM || '',
  };
}

export function renderTemplate(template: string, variables: Record<string, string | number | undefined>): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => {
    const val = variables[key];
    return val !== undefined && val !== null ? String(val) : '';
  });
}

function normalizePhoneForWhatsApp(phone: string): string {
  const digits = phone.replace(/[^\d]/g, '');
  if (digits.length === 10) {
    return `91${digits}`;
  }
  return digits;
}

function recordNotificationLog(entry: {
  labId?: string | null;
  bookingId?: string | null;
  channel: 'email' | 'whatsapp';
  eventType: string;
  recipient: string;
  subject?: string;
  messagePreview: string;
  status: 'sent' | 'failed' | 'unconfigured';
  providerResponse?: string;
  errorMessage?: string;
}) {
  const id = generateId('ntf');
  db.prepare(`
    INSERT INTO notification_logs (
      id, lab_id, booking_id, channel, event_type, recipient, subject,
      message_preview, status, provider_response, error_message, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    entry.labId || null,
    entry.bookingId || null,
    entry.channel,
    entry.eventType,
    entry.recipient,
    entry.subject || null,
    entry.messagePreview.slice(0, 500),
    entry.status,
    entry.providerResponse || null,
    entry.errorMessage || null,
    new Date().toISOString()
  );
  return id;
}

export async function sendRealEmail(params: {
  to: string;
  subject: string;
  text: string;
  html?: string;
  labId?: string | null;
  bookingId?: string | null;
  eventType: string;
}) {
  const cfg = getEffectiveSmtpConfig();
  if (!params.to) {
    return { status: 'failed' as const, error: 'Recipient email address is empty.' };
  }

  if (!cfg.host || !cfg.user || !cfg.pass) {
    const errorMessage = 'SMTP credentials not configured. Configure SMTP Host, Username, and Password in Super Admin > Notification Providers.';
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'email',
      eventType: params.eventType,
      recipient: params.to,
      subject: params.subject,
      messagePreview: params.text,
      status: 'unconfigured',
      errorMessage,
    });
    return { status: 'unconfigured' as const, error: errorMessage };
  }

  try {
    const transporter = nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: cfg.secure,
      auth: {
        user: cfg.user,
        pass: cfg.pass,
      },
      connectionTimeout: 10000,
      greetingTimeout: 10000,
    });

    const info = await transporter.sendMail({
      from: `"${cfg.from_name}" <${cfg.from_email || cfg.user}>`,
      to: params.to,
      subject: params.subject,
      text: params.text,
      html: params.html || `<div style="font-family:sans-serif;line-height:1.6;color:#0f172a;white-space:pre-line;">${params.text.replace(/</g, '&lt;')}</div>`,
    });

    const providerResponse = `MessageId: ${info.messageId} | Response: ${info.response}`;
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'email',
      eventType: params.eventType,
      recipient: params.to,
      subject: params.subject,
      messagePreview: params.text,
      status: 'sent',
      providerResponse,
    });

    return { status: 'sent' as const, providerResponse };
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown SMTP transport error';
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'email',
      eventType: params.eventType,
      recipient: params.to,
      subject: params.subject,
      messagePreview: params.text,
      status: 'failed',
      errorMessage,
    });
    return { status: 'failed' as const, error: errorMessage };
  }
}

export async function sendRealWhatsApp(params: {
  to: string;
  message: string;
  labId?: string | null;
  bookingId?: string | null;
  eventType: string;
}) {
  const cfg = getEffectiveWhatsAppConfig();
  const normalizedPhone = normalizePhoneForWhatsApp(params.to);

  if (!normalizedPhone) {
    return { status: 'failed' as const, error: 'Recipient WhatsApp phone number is invalid or empty.' };
  }

  if (cfg.provider === 'twilio') {
    if (!cfg.twilio_sid || !cfg.twilio_token || !cfg.twilio_from) {
      const errorMessage = 'Twilio WhatsApp credentials (Account SID, Auth Token, From Number) are not configured in Super Admin > Notification Providers.';
      recordNotificationLog({
        labId: params.labId,
        bookingId: params.bookingId,
        channel: 'whatsapp',
        eventType: params.eventType,
        recipient: normalizedPhone,
        messagePreview: params.message,
        status: 'unconfigured',
        errorMessage,
      });
      return { status: 'unconfigured' as const, error: errorMessage };
    }

    try {
      const formBody = new URLSearchParams({
        To: `whatsapp:+${normalizedPhone}`,
        From: cfg.twilio_from.startsWith('whatsapp:') ? cfg.twilio_from : `whatsapp:${cfg.twilio_from}`,
        Body: params.message,
      });

      const response = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(cfg.twilio_sid)}/Messages.json`,
        {
          method: 'POST',
          headers: {
            Authorization: `Basic ${Buffer.from(`${cfg.twilio_sid}:${cfg.twilio_token}`).toString('base64')}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: formBody.toString(),
        }
      );

      const data = (await response.json()) as { sid?: string; message?: string; code?: number };
      if (!response.ok) {
        const errMsg = data.message || `Twilio API returned HTTP ${response.status}`;
        recordNotificationLog({
          labId: params.labId,
          bookingId: params.bookingId,
          channel: 'whatsapp',
          eventType: params.eventType,
          recipient: normalizedPhone,
          messagePreview: params.message,
          status: 'failed',
          errorMessage: errMsg,
          providerResponse: JSON.stringify(data),
        });
        return { status: 'failed' as const, error: errMsg };
      }

      const providerResponse = `Twilio SID: ${data.sid}`;
      recordNotificationLog({
        labId: params.labId,
        bookingId: params.bookingId,
        channel: 'whatsapp',
        eventType: params.eventType,
        recipient: normalizedPhone,
        messagePreview: params.message,
        status: 'sent',
        providerResponse,
      });
      return { status: 'sent' as const, providerResponse };
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : 'Twilio request failed';
      recordNotificationLog({
        labId: params.labId,
        bookingId: params.bookingId,
        channel: 'whatsapp',
        eventType: params.eventType,
        recipient: normalizedPhone,
        messagePreview: params.message,
        status: 'failed',
        errorMessage,
      });
      return { status: 'failed' as const, error: errorMessage };
    }
  }

  // Official Meta WhatsApp Business Cloud API
  if (!cfg.phone_number_id || !cfg.access_token) {
    const errorMessage = 'Meta WhatsApp Cloud API credentials (Phone Number ID & Permanent Access Token) are not configured in Super Admin > Notification Providers.';
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'whatsapp',
      eventType: params.eventType,
      recipient: normalizedPhone,
      messagePreview: params.message,
      status: 'unconfigured',
      errorMessage,
    });
    return { status: 'unconfigured' as const, error: errorMessage };
  }

  try {
    const version = cfg.api_version || 'v21.0';
    const endpoint = `https://graph.facebook.com/${version}/${encodeURIComponent(cfg.phone_number_id)}/messages`;
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${cfg.access_token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: normalizedPhone,
        type: 'text',
        text: {
          preview_url: true,
          body: params.message,
        },
      }),
    });

    const data = (await response.json()) as {
      messages?: Array<{ id: string }>;
      error?: { message: string; type?: string; code?: number };
    };

    if (!response.ok || data.error) {
      const errMsg = data.error?.message || `WhatsApp Cloud API HTTP ${response.status}`;
      recordNotificationLog({
        labId: params.labId,
        bookingId: params.bookingId,
        channel: 'whatsapp',
        eventType: params.eventType,
        recipient: normalizedPhone,
        messagePreview: params.message,
        status: 'failed',
        errorMessage: errMsg,
        providerResponse: JSON.stringify(data),
      });
      return { status: 'failed' as const, error: errMsg };
    }

    const msgId = data.messages?.[0]?.id || 'accepted';
    const providerResponse = `WhatsApp Message ID: ${msgId}`;
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'whatsapp',
      eventType: params.eventType,
      recipient: normalizedPhone,
      messagePreview: params.message,
      status: 'sent',
      providerResponse,
    });
    return { status: 'sent' as const, providerResponse };
  } catch (err: unknown) {
    const errorMessage = err instanceof Error ? err.message : 'WhatsApp Cloud API network error';
    recordNotificationLog({
      labId: params.labId,
      bookingId: params.bookingId,
      channel: 'whatsapp',
      eventType: params.eventType,
      recipient: normalizedPhone,
      messagePreview: params.message,
      status: 'failed',
      errorMessage,
    });
    return { status: 'failed' as const, error: errorMessage };
  }
}

export async function verifySmtpConnection(): Promise<{ ok: boolean; message: string }> {
  const cfg = getEffectiveSmtpConfig();
  if (!cfg.host || !cfg.user || !cfg.pass) {
    return { ok: false, message: 'SMTP host, username, and password are required to verify.' };
  }
  try {
    const transporter = nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port,
      secure: cfg.secure,
      auth: { user: cfg.user, pass: cfg.pass },
      connectionTimeout: 8000,
    });
    await transporter.verify();
    return { ok: true, message: `Connected to ${cfg.host}:${cfg.port} as ${cfg.user}` };
  } catch (err: unknown) {
    return { ok: false, message: err instanceof Error ? err.message : 'SMTP verification failed' };
  }
}
