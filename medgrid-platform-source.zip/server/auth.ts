import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { Request, Response, NextFunction } from 'express';
import { db, generateId } from './db.ts';

const dataDir = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), 'data'));
const secretPath = path.join(dataDir, '.jwt_secret');

function getJwtSecret(): string {
  const envSecret = process.env.SESSION_SECRET || process.env.JWT_SECRET;
  if (envSecret && envSecret.length >= 16) {
    return envSecret;
  }
  if (fs.existsSync(secretPath)) {
    return fs.readFileSync(secretPath, 'utf-8').trim();
  }
  const secret = crypto.randomBytes(48).toString('hex');
  fs.mkdirSync(path.dirname(secretPath), { recursive: true });
  fs.writeFileSync(secretPath, secret, { mode: 0o600 });
  return secret;
}

const JWT_SECRET = getJwtSecret();

export interface AuthPayload {
  uid: string;
  email: string;
  name: string;
  role: 'super_admin' | 'lab_owner';
  labId: string | null;
  permissions: string[];
  exp: number;
}

export interface AuthRequest extends Request {
  auth?: AuthPayload;
}

function base64UrlEncode(input: string | Buffer): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
}

function base64UrlDecode(input: string): string {
  const padded = input + '='.repeat((4 - (input.length % 4)) % 4);
  return Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf-8');
}

export function signToken(payload: Omit<AuthPayload, 'exp'>, ttlSeconds = 60 * 60 * 24 * 7): string {
  const header = base64UrlEncode(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = base64UrlEncode(
    JSON.stringify({
      ...payload,
      exp: Math.floor(Date.now() / 1000) + ttlSeconds,
    })
  );
  const signature = crypto
    .createHmac('sha256', JWT_SECRET)
    .update(`${header}.${body}`)
    .digest();
  return `${header}.${body}.${base64UrlEncode(signature)}`;
}

export function verifyToken(token: string): AuthPayload | null {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    const [header, body, sig] = parts;
    const expectedSig = base64UrlEncode(
      crypto.createHmac('sha256', JWT_SECRET).update(`${header}.${body}`).digest()
    );
    const sigBuf = Buffer.from(sig);
    const expectedBuf = Buffer.from(expectedSig);
    if (sigBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(sigBuf, expectedBuf)) {
      return null;
    }
    const decoded = JSON.parse(base64UrlDecode(body)) as AuthPayload;
    if (!decoded.exp || decoded.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export function extractToken(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7).trim();
  }
  const cookieHeader = req.headers.cookie;
  if (cookieHeader) {
    const cookies = cookieHeader.split(';');
    for (const c of cookies) {
      const idx = c.indexOf('=');
      if (idx > -1) {
        const key = c.slice(0, idx).trim();
        const val = c.slice(idx + 1).trim();
        if (key === 'medgrid_token') {
          return decodeURIComponent(val);
        }
      }
    }
  }
  return null;
}

export function setAuthCookie(res: Response, token: string) {
  const isProd = process.env.NODE_ENV === 'production';
  res.cookie('medgrid_token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: isProd,
    maxAge: 1000 * 60 * 60 * 24 * 7,
    path: '/',
  });
}

export function clearAuthCookie(res: Response) {
  res.clearCookie('medgrid_token', { path: '/' });
}

export function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const token = extractToken(req);
  if (!token) {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Session expired or invalid token.' });
  }
  const user = db.prepare('SELECT id, email, name, role, lab_id, permissions, is_active FROM users WHERE id = ?').get(payload.uid) as
    | { id: string; email: string; name: string; role: 'super_admin' | 'lab_owner'; lab_id: string | null; permissions: string; is_active: number }
    | undefined;

  if (!user || !user.is_active) {
    return res.status(403).json({ error: 'Account is disabled or unavailable.' });
  }

  req.auth = {
    uid: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    labId: user.lab_id,
    permissions: JSON.parse(user.permissions || '[]'),
    exp: payload.exp,
  };
  next();
}

export function requireSuperAdmin(req: AuthRequest, res: Response, next: NextFunction) {
  requireAuth(req, res, () => {
    if (req.auth?.role !== 'super_admin') {
      return res.status(403).json({ error: 'Forbidden: Super Admin access required.' });
    }
    next();
  });
}

export function requireLabOwner(permission?: string) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    requireAuth(req, res, () => {
      if (req.auth?.role !== 'lab_owner' || !req.auth.labId) {
        return res.status(403).json({ error: 'Forbidden: Lab Owner access required.' });
      }
      const lab = db.prepare('SELECT id, status FROM labs WHERE id = ?').get(req.auth.labId) as { id: string; status: string } | undefined;
      if (!lab) {
        return res.status(404).json({ error: 'Assigned laboratory not found.' });
      }
      if (lab.status === 'deactivated') {
        return res.status(403).json({ error: 'Laboratory account has been deactivated by platform administrator.' });
      }
      if (lab.status === 'suspended' && req.method !== 'GET') {
        return res.status(403).json({ error: 'Laboratory account is currently suspended. Read-only mode active until subscription renewal.' });
      }
      if (permission && !req.auth.permissions.includes(permission) && !req.auth.permissions.includes('all')) {
        return res.status(403).json({ error: `Missing permission: ${permission}` });
      }
      next();
    });
  };
}

export function logAudit(params: {
  actorId?: string | null;
  actorEmail?: string | null;
  actorRole?: string | null;
  labId?: string | null;
  action: string;
  details?: string;
  ipAddress?: string;
}) {
  try {
    db.prepare(`
      INSERT INTO audit_logs (id, actor_id, actor_email, actor_role, lab_id, action, details, ip_address, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      generateId('aud'),
      params.actorId || null,
      params.actorEmail || null,
      params.actorRole || null,
      params.labId || null,
      params.action,
      params.details || null,
      params.ipAddress || null,
      new Date().toISOString()
    );
  } catch (err) {
    console.error('Audit log insert failed:', err);
  }
}
