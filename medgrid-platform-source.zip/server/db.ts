import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';

const dataDir = path.resolve(process.env.DATA_DIR || path.join(process.cwd(), 'data'));
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'medgrid.sqlite');
export const db = new DatabaseSync(dbPath);

db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA journal_mode = WAL;');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS labs (
      id TEXT PRIMARY KEY,
      slug TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      website_name TEXT NOT NULL,
      custom_domain TEXT,
      logo_url TEXT,
      banner_url TEXT,
      address TEXT NOT NULL,
      city TEXT NOT NULL,
      contact_number TEXT NOT NULL,
      whatsapp_number TEXT NOT NULL,
      owner_name TEXT NOT NULL,
      owner_email TEXT NOT NULL,
      theme_color TEXT NOT NULL DEFAULT '#1D4ED8',
      tagline TEXT,
      status TEXT NOT NULL DEFAULT 'active',
      subscription_plan TEXT NOT NULL DEFAULT 'Growth Annual',
      selling_price REAL NOT NULL DEFAULT 0,
      amount_paid REAL NOT NULL DEFAULT 0,
      pending_amount REAL NOT NULL DEFAULT 0,
      subscription_start TEXT NOT NULL,
      subscription_expiry TEXT NOT NULL,
      auto_suspend_on_expiry INTEGER NOT NULL DEFAULT 1,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL,
      lab_id TEXT REFERENCES labs(id) ON DELETE CASCADE,
      permissions TEXT NOT NULL DEFAULT '[]',
      invite_token TEXT,
      invite_expires_at TEXT,
      must_change_password INTEGER NOT NULL DEFAULT 0,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS lab_payments (
      id TEXT PRIMARY KEY,
      lab_id TEXT NOT NULL REFERENCES labs(id) ON DELETE CASCADE,
      invoice_number TEXT UNIQUE NOT NULL,
      amount REAL NOT NULL,
      payment_type TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      status TEXT NOT NULL,
      notes TEXT,
      paid_at TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS test_categories (
      id TEXT PRIMARY KEY,
      lab_id TEXT NOT NULL REFERENCES labs(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      name_hi TEXT,
      description TEXT,
      sort_order INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS diagnostic_tests (
      id TEXT PRIMARY KEY,
      lab_id TEXT NOT NULL REFERENCES labs(id) ON DELETE CASCADE,
      category_id TEXT REFERENCES test_categories(id) ON DELETE SET NULL,
      name TEXT NOT NULL,
      name_hi TEXT,
      code TEXT,
      price REAL NOT NULL,
      discounted_price REAL,
      description TEXT NOT NULL,
      preparation TEXT NOT NULL,
      sample_type TEXT NOT NULL,
      reporting_time TEXT NOT NULL,
      is_package INTEGER NOT NULL DEFAULT 0,
      package_items TEXT NOT NULL DEFAULT '[]',
      home_collection_available INTEGER NOT NULL DEFAULT 1,
      is_active INTEGER NOT NULL DEFAULT 1,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      booking_code TEXT UNIQUE NOT NULL,
      lab_id TEXT NOT NULL REFERENCES labs(id) ON DELETE CASCADE,
      test_id TEXT REFERENCES diagnostic_tests(id) ON DELETE SET NULL,
      test_name TEXT NOT NULL,
      price REAL NOT NULL,
      patient_name TEXT NOT NULL,
      patient_mobile TEXT NOT NULL,
      patient_email TEXT,
      patient_age INTEGER NOT NULL,
      patient_gender TEXT NOT NULL,
      collection_type TEXT NOT NULL,
      collection_address TEXT,
      booking_date TEXT NOT NULL,
      time_slot TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      notes TEXT,
      is_demo INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS platform_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notification_logs (
      id TEXT PRIMARY KEY,
      lab_id TEXT REFERENCES labs(id) ON DELETE CASCADE,
      booking_id TEXT,
      channel TEXT NOT NULL,
      event_type TEXT NOT NULL,
      recipient TEXT NOT NULL,
      subject TEXT,
      message_preview TEXT NOT NULL,
      status TEXT NOT NULL,
      provider_response TEXT,
      error_message TEXT,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT,
      actor_email TEXT,
      actor_role TEXT,
      lab_id TEXT,
      action TEXT NOT NULL,
      details TEXT,
      ip_address TEXT,
      created_at TEXT NOT NULL
    );
  `);

  seedInitialData();
}

export function generateId(prefix = 'id') {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

function seedInitialData() {
  const existingUsers = db.prepare('SELECT COUNT(*) as count FROM users').get() as { count: number };
  if (existingUsers.count > 0) {
    return;
  }

  const now = new Date().toISOString();
  const superAdminPass = process.env.SUPER_ADMIN_PASSWORD || 'SuperAdmin@2026!';
  const superAdminEmail = process.env.SUPER_ADMIN_EMAIL || 'admin@medgrid.io';

  db.prepare(`
    INSERT INTO users (id, email, password_hash, name, role, lab_id, permissions, must_change_password, is_active, created_at)
    VALUES (?, ?, ?, ?, 'super_admin', NULL, ?, 0, 1, ?)
  `).run(
    generateId('usr'),
    superAdminEmail,
    bcrypt.hashSync(superAdminPass, 10),
    'Naresh Kumawat',
    JSON.stringify(['all']),
    now
  );

  // Default notification templates & empty provider config
  const defaultTemplates = {
    lab_welcome_email_subject: 'Welcome to {{website_name}} — Your Diagnostic Lab Website is Live',
    lab_welcome_email_body: 'Hello {{owner_name}},\n\nYour diagnostic laboratory website "{{website_name}}" is now active.\n\nPublic Website URL: {{lab_url}}\nAdmin Dashboard URL: {{admin_url}}\nLogin Email: {{owner_email}}\nTemporary Password / Invite Link: {{invite_link}}\n\nRegards,\nMedGrid Platform Team',
    lab_welcome_whatsapp: 'Hello {{owner_name}}, your diagnostic lab website "{{website_name}}" is live at {{lab_url}}. Activate your Lab Owner Admin Panel here: {{invite_link}}',
    booking_patient_email_subject: 'Booking Confirmed: {{booking_code}} — {{website_name}}',
    booking_patient_email_body: 'Dear {{patient_name}},\n\nYour test booking for {{test_name}} is confirmed.\nBooking ID: {{booking_code}}\nDate & Slot: {{booking_date}} ({{time_slot}})\nCollection Mode: {{collection_type}}\nAmount: INR {{price}}\n\nTrack your booking anytime at {{lab_url}}',
    booking_patient_whatsapp: 'Booking Confirmed ({{booking_code}}) at {{website_name}}. Test: {{test_name}} on {{booking_date}} at {{time_slot}}. Collection: {{collection_type}}.',
    booking_owner_email_subject: 'New Patient Booking {{booking_code}} — {{test_name}}',
    booking_owner_email_body: 'New booking received for {{website_name}}.\n\nBooking ID: {{booking_code}}\nPatient: {{patient_name}} ({{patient_mobile}})\nTest: {{test_name}}\nDate: {{booking_date}} {{time_slot}}\nMode: {{collection_type}}\nAddress: {{collection_address}}',
    booking_owner_whatsapp: 'New Booking {{booking_code}} at {{website_name}}: {{patient_name}} ({{patient_mobile}}) booked {{test_name}} for {{booking_date}} {{time_slot}} ({{collection_type}}).',
    booking_cancel_owner_whatsapp: 'Booking Cancelled ({{booking_code}}) at {{website_name}}: {{patient_name}} cancelled {{test_name}} scheduled for {{booking_date}}.',
    renewal_reminder_email_subject: 'Subscription Renewal Reminder — {{website_name}}',
    renewal_reminder_email_body: 'Dear {{owner_name}},\n\nYour {{subscription_plan}} plan for {{website_name}} expires on {{subscription_expiry}}. Please settle any pending balance of INR {{pending_amount}} to avoid service interruption.'
  };

  db.prepare(`INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)`).run(
    'notification_templates',
    JSON.stringify(defaultTemplates)
  );
  db.prepare(`INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)`).run(
    'smtp_config',
    JSON.stringify({ host: '', port: 587, secure: false, user: '', pass: '', from_name: 'MedGrid Diagnostics', from_email: '' })
  );
  db.prepare(`INSERT OR IGNORE INTO platform_settings (key, value) VALUES (?, ?)`).run(
    'whatsapp_config',
    JSON.stringify({ provider: 'meta_cloud_api', phone_number_id: '', access_token: '', business_account_id: '', api_version: 'v21.0', twilio_sid: '', twilio_token: '', twilio_from: '' })
  );

  // Seed 3 realistic demonstration laboratories clearly flagged is_demo = 1
  const demoLabs = [
    {
      id: 'lab_healthcare',
      slug: 'healthcare',
      name: 'HealthCare Diagnostics & Pathology',
      website_name: 'HealthCare Diagnostics',
      custom_domain: 'diagnostics.healthcare-demo.in',
      logo_url: '',
      banner_url: '/src/assets/images/hero_diagnostic_lab_1794644019030.jpg',
      address: '42 Station Road, Civil Lines',
      city: 'Jaipur, Rajasthan',
      contact_number: '+91 141 238 4410',
      whatsapp_number: '919829011223',
      owner_name: 'Dr. Rajesh Sharma',
      owner_email: 'rajesh@healthcare-demo.in',
      theme_color: '#1D4ED8',
      tagline: 'NABL-aligned clinical pathology, preventive health packages & 6-hour digital reports.',
      status: 'active',
      subscription_plan: 'Growth Annual',
      selling_price: 24000,
      amount_paid: 24000,
      pending_amount: 0,
      subscription_start: '2026-01-15',
      subscription_expiry: '2027-01-15',
      categories: [
        { name: 'Complete Blood & Hematology', name_hi: 'रक्त एवं हेमेटोलॉजी जांच' },
        { name: 'Diabetes & Metabolic', name_hi: 'मधुमेह एवं मेटाबॉलिक जांच' },
        { name: 'Thyroid & Hormones', name_hi: 'थायरॉइड एवं हार्मोन जांच' },
        { name: 'Preventive Health Packages', name_hi: 'संपूर्ण स्वास्थ्य पैकेज' },
      ],
    },
    {
      id: 'lab_modern',
      slug: 'modern-diagnostics',
      name: 'Modern Diagnostics & Imaging Center',
      website_name: 'Modern Diagnostics',
      custom_domain: 'moderndiagnostics-demo.in',
      logo_url: '',
      banner_url: '/src/assets/images/lab_pathology_microscope_1794644019999.jpg',
      address: '108 Indiranagar 100 Feet Road',
      city: 'Bengaluru, Karnataka',
      contact_number: '+91 80 4120 8890',
      whatsapp_number: '919845022334',
      owner_name: 'Anita Verma',
      owner_email: 'anita@modern-demo.in',
      theme_color: '#0284C7',
      tagline: 'Automated molecular diagnostics, cardiac markers & doorstep phlebotomy across Bengaluru.',
      status: 'active',
      subscription_plan: 'Enterprise Custom',
      selling_price: 42000,
      amount_paid: 30000,
      pending_amount: 12000,
      subscription_start: '2026-03-01',
      subscription_expiry: '2027-03-01',
      categories: [
        { name: 'Lipid & Cardiac Care', name_hi: 'हृदय एवं लिपिड प्रोफाइल' },
        { name: 'Liver & Kidney Function', name_hi: 'लिवर एवं किडनी जांच' },
        { name: 'Vitamins & Bone Health', name_hi: 'विटामिन एवं हड्डी स्वास्थ्य' },
      ],
    },
    {
      id: 'lab_care',
      slug: 'care-lab',
      name: 'Care Lab & Clinical Wellness',
      website_name: 'Care Lab',
      custom_domain: '',
      logo_url: '',
      banner_url: '/src/assets/images/lab_home_collection_1794644020012.jpg',
      address: '19 FC Road, Shivajinagar',
      city: 'Pune, Maharashtra',
      contact_number: '+91 20 2553 6721',
      whatsapp_number: '919765033445',
      owner_name: 'Vikram Patel',
      owner_email: 'vikram@carelab-demo.in',
      theme_color: '#0F766E',
      tagline: 'Trusted neighborhood pathology & rapid home sample collection within 45 minutes.',
      status: 'active',
      subscription_plan: 'Starter Monthly',
      selling_price: 15000,
      amount_paid: 10000,
      pending_amount: 5000,
      subscription_start: '2026-09-01',
      subscription_expiry: '2026-12-01',
      categories: [
        { name: 'Fever & Infection Panel', name_hi: 'बुखार एवं संक्रमण जांच' },
        { name: 'Routine Blood Chemistry', name_hi: 'सामान्य रक्त जांच' },
      ],
    },
  ];

  const defaultOwnerPassHash = bcrypt.hashSync('LabOwner@2026!', 10);

  for (const lab of demoLabs) {
    db.prepare(`
      INSERT INTO labs (
        id, slug, name, website_name, custom_domain, logo_url, banner_url,
        address, city, contact_number, whatsapp_number, owner_name, owner_email,
        theme_color, tagline, status, subscription_plan, selling_price,
        amount_paid, pending_amount, subscription_start, subscription_expiry,
        auto_suspend_on_expiry, is_demo, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?)
    `).run(
      lab.id, lab.slug, lab.name, lab.website_name, lab.custom_domain, lab.logo_url, lab.banner_url,
      lab.address, lab.city, lab.contact_number, lab.whatsapp_number, lab.owner_name, lab.owner_email,
      lab.theme_color, lab.tagline, lab.status, lab.subscription_plan, lab.selling_price,
      lab.amount_paid, lab.pending_amount, lab.subscription_start, lab.subscription_expiry, now
    );

    db.prepare(`
      INSERT INTO users (id, email, password_hash, name, role, lab_id, permissions, must_change_password, is_active, created_at)
      VALUES (?, ?, ?, ?, 'lab_owner', ?, ?, 0, 1, ?)
    `).run(
      generateId('usr'),
      lab.owner_email,
      defaultOwnerPassHash,
      lab.owner_name,
      lab.id,
      JSON.stringify(['manage_tests', 'manage_bookings', 'manage_profile', 'export_reports', 'manage_packages']),
      now
    );

    db.prepare(`
      INSERT INTO lab_payments (id, lab_id, invoice_number, amount, payment_type, payment_method, status, notes, paid_at, created_at)
      VALUES (?, ?, ?, ?, 'website_sale', 'UPI / Bank Transfer', ?, ?, ?, ?)
    `).run(
      generateId('pay'),
      lab.id,
      `INV-2026-${lab.slug.slice(0, 4).toUpperCase()}`,
      lab.amount_paid,
      lab.pending_amount > 0 ? 'partial' : 'paid',
      `Initial ${lab.subscription_plan} website onboarding`,
      now,
      now
    );

    const catIds: string[] = [];
    lab.categories.forEach((cat, idx) => {
      const catId = generateId('cat');
      catIds.push(catId);
      db.prepare(`
        INSERT INTO test_categories (id, lab_id, name, name_hi, description, sort_order)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(catId, lab.id, cat.name, cat.name_hi, '', idx);
    });

    const sampleTests = [
      {
        catIdx: 0,
        name: 'Complete Blood Count (CBC)',
        name_hi: 'संपूर्ण रक्त गणना (सीबीसी)',
        code: 'HEM-101',
        price: 450,
        discounted_price: 350,
        description: 'Evaluates red blood cells, white blood cells, hemoglobin, hematocrit, and platelet counts.',
        preparation: 'No fasting required. Drink plenty of water before sample draw.',
        sample_type: 'Blood',
        reporting_time: '6 Hours',
        is_package: 0,
        package_items: [],
      },
      {
        catIdx: Math.min(1, catIds.length - 1),
        name: 'HbA1c (Glycated Hemoglobin)',
        name_hi: 'एचबीए1सी (शुगर 3 महीने की जांच)',
        code: 'DIA-204',
        price: 600,
        discounted_price: 499,
        description: 'Measures average blood glucose levels over the past 2 to 3 months for diabetes screening.',
        preparation: 'No special fasting required. Can be taken any time of day.',
        sample_type: 'Blood',
        reporting_time: '8 Hours',
        is_package: 0,
        package_items: [],
      },
      {
        catIdx: Math.min(2, catIds.length - 1),
        name: 'Thyroid Profile Total (T3, T4, TSH)',
        name_hi: 'थायरॉइड प्रोफाइल (टी3, टी4, टीएसएच)',
        code: 'THY-301',
        price: 750,
        discounted_price: 599,
        description: 'Comprehensive assessment of thyroid gland hormones to detect hypothyroidism or hyperthyroidism.',
        preparation: 'Morning sample preferred before taking thyroid medication.',
        sample_type: 'Blood',
        reporting_time: '12 Hours',
        is_package: 0,
        package_items: [],
      },
      {
        catIdx: catIds.length - 1,
        name: 'Executive Full Body Checkup (72 Parameters)',
        name_hi: 'संपूर्ण बॉडी हेल्थ पैकेज (72 जांच)',
        code: 'PKG-900',
        price: 2999,
        discounted_price: 1799,
        description: 'Complete preventive screening covering CBC, Lipid, Liver, Kidney, Thyroid, Fasting Sugar & Urine routine.',
        preparation: '10–12 hours overnight fasting mandatory. Plain water allowed.',
        sample_type: 'Blood',
        reporting_time: '24 Hours',
        is_package: 1,
        package_items: ['CBC (24 Parameters)', 'Liver Function Test (LFT)', 'Kidney Function Test (KFT)', 'Thyroid Profile (T3, T4, TSH)', 'Lipid Profile', 'HbA1c & Fasting Glucose', 'Urine Routine'],
      },
    ];

    const createdTestIds: Array<{ id: string; name: string; price: number }> = [];
    for (const t of sampleTests) {
      const testId = generateId('tst');
      const finalPrice = t.discounted_price ?? t.price;
      createdTestIds.push({ id: testId, name: t.name, price: finalPrice });
      db.prepare(`
        INSERT INTO diagnostic_tests (
          id, lab_id, category_id, name, name_hi, code, price, discounted_price,
          description, preparation, sample_type, reporting_time, is_package,
          package_items, home_collection_available, is_active, is_demo, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 1, ?)
      `).run(
        testId, lab.id, catIds[t.catIdx], t.name, t.name_hi, t.code, t.price, t.discounted_price,
        t.description, t.preparation, t.sample_type, t.reporting_time, t.is_package,
        JSON.stringify(t.package_items), now
      );
    }

    // Seed 2 demo bookings per lab (is_demo = 1)
    const today = new Date().toISOString().slice(0, 10);
    const demoBookings = [
      {
        code: `MG-${lab.slug.slice(0, 4).toUpperCase()}-1001`,
        test: createdTestIds[0],
        patient_name: 'Aarav Mehta',
        patient_mobile: '+91 98111 22334',
        patient_email: 'aarav.mehta@example.com',
        patient_age: 34,
        patient_gender: 'Male',
        collection_type: 'home_collection',
        collection_address: 'B-14 Shanti Nagar, Near Central Park',
        booking_date: today,
        time_slot: '08:00 AM - 09:00 AM',
        status: 'confirmed',
      },
      {
        code: `MG-${lab.slug.slice(0, 4).toUpperCase()}-1002`,
        test: createdTestIds[3],
        patient_name: 'Priya Nair',
        patient_mobile: '+91 98222 33445',
        patient_email: 'priya.nair@example.com',
        patient_age: 29,
        patient_gender: 'Female',
        collection_type: 'lab_visit',
        collection_address: '',
        booking_date: today,
        time_slot: '10:00 AM - 11:00 AM',
        status: 'pending',
      },
    ];

    for (const b of demoBookings) {
      db.prepare(`
        INSERT INTO bookings (
          id, booking_code, lab_id, test_id, test_name, price,
          patient_name, patient_mobile, patient_email, patient_age, patient_gender,
          collection_type, collection_address, booking_date, time_slot,
          status, notes, is_demo, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', 1, ?, ?)
      `).run(
        generateId('bkg'), b.code, lab.id, b.test.id, b.test.name, b.test.price,
        b.patient_name, b.patient_mobile, b.patient_email, b.patient_age, b.patient_gender,
        b.collection_type, b.collection_address, b.booking_date, b.time_slot,
        b.status, now, now
      );
    }
  }
}
